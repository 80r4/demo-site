cff-version: 1.2.0
message: "If you use this software, please cite it as below."
type: software
title: "TrueOccupancy: A Multi-Source Housing Data Framework for Cities"
authors:
  - family-names: "Dündar"
    given-names: "Bora"
    affiliation: "MBDesign — Design Innovation and Technology"
version: "1.0.0"
date-released: "2026-06-01"
license: MIT
repository-code: "https://github.com/YOURUSERNAME/trueoccupancy"
keywords: [housing, algorithmic-regulation, GDPR, privacy-by-design, urban-informatics, Barcelona]
