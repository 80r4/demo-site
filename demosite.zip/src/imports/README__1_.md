*.db
*.sqlite
__pycache__/
.DS_Store
.vscode/
.idea/
