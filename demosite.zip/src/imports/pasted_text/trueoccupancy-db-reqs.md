Scope and purpose of this document
This document lists the essential requirements for the TrueOccupancy database and
inspector dashboard, derived directly from the thesis specification. Requirements are
categorised as MUST (the system cannot function without it), SHOULD (important
but not blocking for the prototype), or COULD (stretch goal for future work). The
system has two separable components: the Database & Pipeline (data storage,
ingestion, linking, classification, privacy enforcement) and the Dashboard /
Inspector Interface (the front-end that city housing officers use to query results
and log decisions). Requirements are listed separately for each.
1. System overview
TrueOccupancy has five functional blocks that must work in sequence. No block can be
bypassed. The privacy guarantee is structural — it is enforced by the architecture, not by policy.
Five blocks — what each does and what it cannot do
Block 1 — Data Ingestion Layer: Pulls from external sources. Writes to staging
area. Has no access to the core database. Block 2 — Data Linker: Performs entity
resolution. Matches records to cadastral references. Writes to the four core tables. Has
no access to inferences or clusters. Block 3 — Classification Engine: Reads from
four core tables. Applies detection model. Writes confidence scores to inferences only.
Cannot expose inferences to users. Block 4 — Privacy and Clustering Layer:
Reads from inferences. Enforces 500-property minimum. Writes to clusters only. This
is the privacy enforcement boundary — it is the only path from individual inferences to
user-visible output. Block 5 — Inspector Interface: Reads from clusters and
audit_logs only. Has no direct access to inferences, utility_percentiles, web_listings,
or cadastre. Writes inspector decisions to audit_logs only.
2. Database requirements
2.1 Schema — seven tables
The database must consist of exactly seven tables. No personal identifiers (owner names, tenant
names, meter IDs, national identity numbers) may be stored anywhere in the schema. The
cadastral_ref field is the sole joining key across all tables.
ID Requirement Source Priority
Table: properties — master property record
DB-
01
properties table must exist with fields:
cadastral_ref (PK, text), address_string
(text), gps_lat (float), gps_lon (float),
building_age (int), floor_area_m2 (float),
zoning_category (enum: residential /
commercial / mixed)
Ch.4.1 MUST
DB-
02
No owner name, tenant name, or personal ID may
appear in the properties table
Ch.4.3 Rule 1 MUST
DB-
03
cadastral_ref must be indexed for fast join
performance across all seven tables
Ch.4.1 MUST
Table: utility_percentiles — normalised consumption signals
DB-
04
utility_percentiles must store:
cadastral_ref (FK), period_month (date, first
of month), water_litres_day (float),
electricity_kwh_day (float), gas_kwh_day
(float, nullable), water_pct_rank (float
0–100), electricity_pct_rank (float 0–100)
Ch.4.1 MUST
DB-
05
Percentile rank must be calculated relative to
properties in the same neighbourhood (same postal
zone), not city-wide
Ch.3.5 MUST
DB-
06
Rolling 90-day average must be computed and stored
as a derived field alongside monthly readings
Ch.3.5 / Ch.6.2 MUST
DB-
07
Raw meter IDs from utility companies must never be
stored — only the cadastral_ref mapping
Ch.4.3 Rule 1 MUST
Table: web_listings — rental platform activity
DB-
08
web_listings must store: cadastral_ref
(FK), platform (enum: airbnb / booking /
other), listing_id_hashed (text, hashed — not
raw platform ID), booking_days_last_90
(int), listing_price_eur (float), first_seen
(date), last_seen (date)
Ch.4.1 MUST
DB-
09
Platform listing IDs must be hashed before storage —
the raw ID must not be stored or recoverable from the
database
Ch.4.3 Rule 1 MUST
DB-
10
Geocoding from listing address/GPS to cadastral_ref
must be performed in the ingestion pipeline before
any listing record enters the database
Ch.4.2 MUST
DB-
11
The system should track multi-platform presence — a
count of distinct platforms listing the same
cadastral_ref in any given 90-day window
Ch.3.5 SHOULD
Table: cadastre — land registry attributes
DB-
12
cadastre must store: cadastral_ref (FK),
ownership_entity_type (enum: individual /
company / trust / unknown), tenure_type
(enum: owned / rented / vacant / unknown),
declared_use (text), floor_count (int),
last_registry_update (date),
transaction_history_count (int)
Ch.4.1 MUST
DB-
13
Owner name must not be stored.
ownership_entity_type (individual/company/trust) is
stored; the identity of the entity is not
Ch.4.3 Rule 1 MUST
DB-
14
The system should flag records where
ownership_entity_type = company and the same
company entity appears against 3 or more
cadastral_ref values — this is the speculative
withholding signal
Ch.3.2 SHOULD
Table: inferences — per-property classification output
DB-
15
inferences must store: cadastral_ref (FK),
misuse_category (enum: structural_vacancy /
speculative_withholding / illegal_tourist /
illegal_office / none), confidence_level
(enum: high / medium / low / watch),
signals_used (JSON array of source names),
classification_date (timestamp),
model_version (text)
Ch.4.1 / Ch.5.4 MUST
DB-
16
The inferences table must NOT be readable by the
inspector interface role. It is readable only by the
Classification Engine (Block 3) and the
Privacy/Clustering Layer (Block 4)
Ch.4.3 Rule 4 / Ch.5.1 MUST
DB-
17
Classification must require at least two consistent
signals from different sources before assigning any
misuse category with high or medium confidence
Ch.3.6 MUST
DB-
18
A property with only one signal must be assigned
confidence_level = watch — never high or medium
Ch.3.4 MUST
Table: clusters — k-anonymous spatial output
DB-
19
clusters must store: cluster_id (UUID, PK),
bounding_box (GeoJSON polygon),
property_count (int),
dominant_misuse_category (enum),
composite_confidence_score (float 0–1),
pct_high_confidence (float), signal_profile
(JSON — aggregate stats only, e.g.
"pct_below_5L_water": 0.72), generated_at
(timestamp)
Ch.4.1 / Ch.5.2 MUST
DB-
20
Any cluster with property_count < 500 must be
suppressed — it must not be written to the clusters
table and must not be returned by any query
Ch.4.3 Rule 2 MUST
DB-
21
The signal_profile JSON field must contain only
aggregate statistics (percentages, medians) — never
any value that could identify a single property within
the cluster
Ch.4.3 Rule 4 MUST
DB-
22
The clusters table is the only table accessible to the
inspector interface (Block 5) for read queries
Ch.5.1 MUST
Table: audit_logs — complete query trail
DB-
23
audit_logs must store: log_id (UUID, PK),
user_id (text, hashed), query_timestamp
(timestamp), query_area (GeoJSON),
query_misuse_type (enum),
query_confidence_threshold (enum),
clusters_returned_count (int),
inspector_decision (enum: referred /
dismissed / pending / null),
decision_timestamp (timestamp, nullable)
Ch.4.1 / Ch.5.3 MUST
DB-
24
Every query made through the inspector interface
must generate an audit_log record, including queries
that return zero results
Ch.4.3 Rule 3 MUST
DB-
25
audit_log records must be retained for exactly 24
months from creation date, then automatically deleted
by the retention job
Ch.4.4 Job 6 MUST
DB-
26
The user_id field must be a one-way hash of the actual
user identifier — the raw username or employee ID
must not be stored in the audit log
Ch.4.3 Rule 3 SHOULD
2.2 Privacy enforcement — hard constraints
These requirements are non-negotiable. If any one of them is violated, the system is not GDPR￾compliant and must not be deployed.
ID Requirement Source Priority
PR-
01
No query from Block 5 (inspector interface) may
access the inferences table directly or indirectly
Privacy Linker Rule 4 MUST
PR-
02
No query may return data below the 500-property
cluster threshold. The database must enforce this at
query layer, not only at application layer
Privacy Linker Rule 2 MUST
PR-
03
The database must operate with role-based access
control. Inspector role: read clusters, read/write
audit_logs only. Pipeline role: read/write all tables.
Admin role: schema changes only, no data read
Privacy Linker Rule 3 MUST
PR-
04
No personal identifier — name, national ID, meter ID,
platform user ID — may appear in any table at any
stage of the pipeline
Privacy Linker Rule 1 MUST
PR-
05
All raw source data (utility readings, scraped listings,
registry records) must be automatically purged after
24 months from ingestion date
Privacy Linker Rule 3 MUST
PR-
06
The database must log any attempt to query the
inferences table by a user with inspector-role
credentials, and this event must trigger an alert to the
Ch.6.3 MUST
system administrator
2.3 Data pipeline — ingestion and scheduling
Six scheduled jobs must run in dependency order. Jobs 4 and 5 must not start until Jobs 1–3
have completed for the current cycle.
ID Requirement Source Priority
Job 1 — Cadastral update (monthly)
PL-
01
Pull latest cadastral records from land registry API.
Update cadastre table. Flag any zoning changes
(residential → other) for human review before next
classification run
Ch.4.4 Job 1 MUST
PL-
02
If the land registry API is unavailable, the job must fail
loudly and block Job 4 from running with stale
cadastral data older than 35 days
Ch.4.4 Job 1 MUST
Job 2 — Utility ingestion (monthly, offset +7 days after billing cycle close)
PL-
03
Ingest utility consumption records. Map meter IDs to
cadastral_ref using the utility–cadastre crosswalk file
(stored separately, never in the database). Discard
meter IDs after mapping — do not store them
Ch.4.4 Job 2 / Rule 1 MUST
PL-
04
Normalise consumption values to litres/day for water,
kWh/day for electricity. Compute neighbourhood
percentile rank. Store in utility_percentiles. Update
the rolling 90-day average
Ch.4.2 / Ch.3.5 MUST
PL-
05
Flag any property where water consumption is below 5
L/day for three or more consecutive months as a
structural vacancy candidate for the classification
engine
Ch.3.5 MUST
Job 3 — Web listing scrape (weekly)
PL-
06
Scrape or pull from platform data agreements.
Geocode listing address/GPS to cadastral_ref. Hash
platform listing ID. Reject any record that cannot be
geocoded to a known cadastral_ref
Ch.4.4 Job 3 MUST
PL-
07
Flag any newly scraped listing where the matched
cadastral_ref has residential zoning — this is the
primary trigger for illegal tourist use classification
Ch.3.3 / Ch.3.5 MUST
PL-
08
Record count of distinct platforms listing the same
cadastral_ref in any rolling 90-day window. Multi￾platform presence (2+ platforms) elevates confidence
level
Ch.3.5 SHOULD
Job 4 — Classification run (monthly, after Jobs 1–3 complete)
PL-
09
Run the classification model across all properties that
have had at least one source updated in the current
cycle. Assign misuse_category and confidence_level.
Write results to inferences table
Ch.4.4 Job 4 MUST
PL-
10
Classification logic must implement the
following threshold rules from the thesis: •
Structural vacancy: water_rolling_90d < 5
Ch.3.5 MUST
L/day AND no active listings AND no
registered residents → confidence HIGH if all
three, MEDIUM if two • Speculative
withholding: irregular consumption pattern
AND multi-property same entity AND listing
price > 3 SD above median → confidence
MEDIUM • Illegal tourist use:
booking_days_last_90 > 17 (≈60/year pro￾rated) AND residential zoning AND multi￾platform = 2+ → confidence HIGH; single
platform → MEDIUM • Illegal office:
electricity consistent 24/7 baseline AND water
~200 L/day AND no residents → confidence
HIGH
PL-
11
A property with only one signal must be assigned
confidence_level = watch — never high or medium
Ch.3.4 MUST
PL-
12
Store model_version with each inference record so
that results from different model versions can be
compared
Ch.5.4 SHOULD
Job 5 — Cluster generation (monthly, after Job 4 complete)
PL-
13
Generate k-anonymous spatial clusters from the
current inferences table. Group contiguous properties
with the same dominant misuse category. Suppress
any cluster with property_count < 500
Ch.4.4 Job 5 MUST
PL-
14
Write cluster aggregate statistics to the clusters table
— percentages and medians only. The signal_profile
field must never contain any value that could identify
a single property
Ch.4.3 Rule 4 MUST
PL-
15
Log the count of suppressed clusters (below 500
threshold) to the system log. This is a monitoring
metric, not a privacy risk
Ch.4.4 SHOULD
Job 6 — Audit log retention and data purge (quarterly)
PL-
16
Delete audit_log records older than 24 months from
creation date
Ch.4.4 Job 6 / Rule 3 MUST
PL-
17
Delete utility_percentiles records older than 24
months from period_month date
Ch.4.4 Job 6 MUST
PL-
18
Delete web_listings records where last_seen is older
than 24 months
Ch.4.4 Job 6 MUST
PL-
19
Generate a retention compliance report after each
purge, recording: counts of records deleted per table,
date of oldest remaining record per table, and
confirmation that no personal identifiers were found
in any deleted record batch
Ch.6.3 / GDPR Art.5 MUST
2.4 Performance and reliability
ID Requirement Source Priority
PE- The database must handle at least 50,000 properties Prototype scope MUST
01 in the properties table without performance
degradation on the monthly classification job
PE-
02
Inspector queries against the clusters table must
return results within 3 seconds for any geographic
bounding box query over the full dataset
Dashboard UX MUST
PE-
03
The pipeline jobs must be idempotent — re-running
any job with the same source data must produce
identical output and must not create duplicate records
Engineering MUST
PE-
04
The system should maintain a job run log with status
(success / failed / running), start time, end time, and
record counts for each job
Ch.4.4 SHOULD
3. Dashboard / Inspector Interface requirements
3.1 Access and authentication
ID Requirement Source Priority
UI-01 All inspector interface users must authenticate before
accessing any part of the dashboard. Unauthenticated
requests must be rejected at the application layer
Privacy Linker Rule 3 MUST
UI-02 User roles must be enforced: inspector role sees only
clusters and audit_log views. No inspector can reach
inferences, utility_percentiles, web_listings, or
cadastre tables
Privacy Linker Rule 3 MUST
UI-03 Every page load and every query must be logged to
audit_logs. Session establishment (login) and
termination (logout) must also be logged
Privacy Linker Rule 3 /
Ch.6.3
MUST
UI-04 Sessions must expire after 60 minutes of inactivity.
The system must not allow session tokens to be shared
between users
Engineering SHOULD
3.2 Screen 1 — Query
The Query screen is the entry point. An inspector specifies what they are looking for. The system
validates that the query will return results at or above the 500-property threshold before
executing.
ID Requirement Source Priority
S1-
01
The inspector must be able to define a geographic area
by: (a) drawing a polygon on a map, or (b) selecting a
named neighbourhood from a dropdown list
Ch.5.3 Screen 1 MUST
S1-
02
The inspector must select a misuse type of interest:
structural vacancy, speculative withholding, illegal
tourist use, illegal office conversion, or "all types"
Ch.5.3 Screen 1 MUST
S1-
03
The inspector must select a minimum confidence
threshold: high, medium, or medium-and-above
Ch.5.3 Screen 1 MUST
S1-
04
Before executing the query, the system must show a
preview count: "X clusters match these criteria" — if
zero clusters match, the inspector sees this before
submitting
Dashboard UX MUST
S1-
05
If a query would return data from the inferences table
directly or bypass the 500-property cluster minimum,
the system must reject the query with an error
message and log the attempt
Privacy Linker Rule 2 /
PR-06
MUST
S1-
06
The query form must not offer a field for searching by
address, owner name, or property identifier of any
kind
Privacy Linker Rule 1 MUST
S1-
07
The inspector should be able to save a query
configuration for reuse, without saving the query
results
Dashboard UX SHOULD
3.3 Screen 2 — Results and clusters
The Results screen shows matching clusters on a map and in a list. No individual property is
ever shown. All data displayed comes from the clusters table only.
ID Requirement Source Priority
S2-
01
Matching clusters must be displayed on an interactive
map as shaded polygons (bounding boxes from the
clusters table). The map must show cluster location
and dominant misuse category by colour
Ch.5.3 Screen 2 MUST
S2-
02
Each cluster in the list view must show: cluster ID,
property count, dominant misuse category, composite
confidence score, and date of last data update. No
individual property data is shown
Ch.5.3 Screen 2 MUST
S2-
03
The aggregate signal profile must be shown as plain￾language statistics: e.g. "72% of properties in this
cluster have water consumption below 5 L/day over
the last 90 days". Never shown as raw values
Ch.5.3 Screen 2 MUST
S2-
04
The system must not allow the inspector to click on or
zoom into an individual property within a cluster. The
smallest visible unit is the cluster itself
Privacy Linker Rule 2 MUST
S2-
05
Clusters must be sortable by: confidence score (high to
low), property count (large to small), and date of last
update (newest first)
Dashboard UX SHOULD
S2-
06
The screen must display the date of the most recent
data update for each source (utility, listings, cadastral)
so the inspector knows how current the signals are
Dashboard UX / Ch.4.4 SHOULD
S2-
07
The inspector should be able to export the cluster list
(IDs, locations, aggregate statistics only) as a CSV. The
export must be logged to audit_logs
Dashboard UX COULD
3.4 Screen 3 — Cluster detail and audit
The Detail screen shows the full evidence picture for one selected cluster and allows the
inspector to log a decision. This is where enforcement decisions are made and recorded.
ID Requirement Source Priority
S3-
01
The detail screen must show the cluster's: composite
confidence score, dominant misuse category, property
count, bounding box on map, aggregate signal profile,
list of data sources contributing to the classification,
and date each source was last updated
Ch.5.3 Screen 3 MUST
S3-
02
The inspector must be able to log a decision for the
cluster: "Referred for physical inspection", "Dismissed
— insufficient evidence", or "Pending — monitoring".
The decision must be recorded in audit_logs with a
timestamp
Ch.5.3 Screen 3 MUST
S3-
03
The inspector must be able to add a free-text note to
the decision (max 500 characters). This note is stored
in audit_logs against the log_id
Ch.5.3 Screen 3 SHOULD
S3- The screen must show the full audit trail for this Ch.5.3 Screen 3 / MUST
04 cluster: every previous query that returned this
cluster, the user who ran it, and any decision logged.
This trail must be visible to all inspector users who
have queried this cluster
Ch.6.3
S3-
05
If a cluster has previously been "Referred for physical
inspection", it must be visually flagged on the Results
screen (Screen 2) with a "referred" badge
Dashboard UX SHOULD
S3-
06
The system must not allow the inspector to view any
data at a finer granularity than the cluster — no matter
how many times they click, zoom, or filter
Privacy Linker Rule 2 MUST
S3-
07
After logging a decision, the inspector must see a
confirmation screen showing what was logged and
that it cannot be edited or deleted
Ch.6.3 / GDPR
accountability
MUST
3.5 Dashboard non-functional requirements
ID Requirement Source Priority
NF-
01
The inspector interface must be browser-based. No
desktop app installation should be required
Accessibility MUST
NF-
02
The map component must load and display clusters
within 5 seconds on a standard office internet
connection
Dashboard UX MUST
NF-
03
The interface must work on a standard laptop screen
(1366×768 minimum resolution)
Accessibility MUST
NF-
04
All text on the interface must be available in at least
English. Spanish should be supported for the
Barcelona pilot
Pilot requirement SHOULD
NF-
05
The interface should display a data freshness warning
if any source has not been updated in more than 35
days
Ch.4.4 SHOULD
NF-
06
The interface must not use cookies or client-side
storage to cache any cluster data or query results
between sessions
Privacy / security MUST
4. Explicitly out of scope for this prototype
These requirements are excluded from the current implementation. They are documented to
prevent scope creep and to guide future development.
Not in scope — prototype boundary
Individual property view: No interface, API endpoint, or database query may
expose data at individual property level. The cluster (500+ properties) is the minimum
unit. Automated enforcement: The system produces cluster flags for human
review only. No fine, no licence revocation, no legal notice may be generated
automatically. Real utility data: The prototype uses synthetic utility data.
Integration with real AMI/smart meter feeds requires a separate city data-sharing
agreement. Population register integration: Connecting to population/address
registers (outside Nordic countries) requires local legal assessment. Not in prototype
scope. Mobility/telecoms data: Supported by the architecture but not
implemented. Requires a commercial telecoms data agreement. Multi-city
deployment: The prototype targets Gràcia (Barcelona) only. Multi-city configuration
is a future extension — the schema is designed to support it via a city_id field, but this
is not implemented.
5. Requirements summary
Category MUST SHOULD COULD Total
Database schema (DB-01 to DB-
26)
17 5 0 22
Privacy enforcement (PR-01 to
PR-06)
6 0 0 6
Pipeline / scheduling (PL-01 to
PL-19)
16 3 0 19
Performance (PE-01 to PE-04) 3 1 0 4
Authentication (UI-01 to UI-04) 3 1 0 4
Screen 1 — Query (S1-01 to S1-
07)
6 1 0 7
Screen 2 — Results (S2-01 to S2-
07)
4 2 1 7
Screen 3 — Detail (S3-01 to S3-
07)
5 2 0 7
Non-functional (NF-01 to NF-
06)
4 2 0 6
TOTAL 64 17 1 82
How to use this document
For implementation: Start with all MUST requirements. The prototype is done
when all 64 MUST requirements pass. Do not implement SHOULD or COULD
requirements until all MUSTs are verified. For testing: Each requirement ID (DB-
01, PR-01, PL-01, etc.) is a testable criterion. Write one test per requirement. Privacy
requirements (PR-01 to PR-06) must be tested with adversarial queries — attempt to
bypass each rule and verify the system rejects it. For the thesis: This document is
the specification that Chapter 5 (Prototype) is implemented against. Validation figures
in Section 5.4 of the thesis correspond to the MUST classification logic requirements
(PL-10, PL-11).