# TrueOccupancy

**A privacy-preserving housing data framework for cities.**
Master's thesis prototype · Bora Dündar · MBDesign — Design Innovation and Technology · 2026

TrueOccupancy links utility consumption, rental listings, and cadastral registers
to detect housing misuse — structural vacancy, speculative withholding, and illegal
tourist use — at neighbourhood scale, without identifying any individual resident or owner.

---

## Run it — two steps, no install

**1. See the interface (no setup at all)**

Open `app/index.html` in any web browser. Double-click the file — that's it.
React is bundled locally, so it works offline with no internet and no build step.

**2. Regenerate the data (optional)**

```bash
cd pipeline
python pipeline.py
```

This rebuilds the 7-table SQLite database and writes fresh cluster data to
`data/synthetic/dashboard_data.json`. Needs only Python 3.8+ — no pip install.

---

## What's inside

```
trueoccupancy/
├── app/                     the inspector interface — open index.html
│   ├── index.html           ← double-click this
│   ├── app.js               the three-screen dashboard (React)
│   └── vendor/              React, bundled locally (works offline)
├── pipeline/
│   ├── pipeline.py          builds the database + cluster data
│   └── requirements.txt
├── data/
│   ├── DATA_SOURCES.md      real vs synthetic data — full transparency
│   └── synthetic/           generated cluster data the interface reads
├── docs/                    thesis reference
├── LICENSE                  MIT (code) · CC BY 4.0 (thesis text)
├── CITATION.cff             cite this repository
└── CHANGELOG.md
```

---

## The three screens

1. **Inspector** — draw an area, pick a misuse type and confidence level, and see
   flagged clusters on the map. Click a cluster for its aggregate signal profile and
   log a decision. No individual property is ever shown.
2. **Audit log** — every query and decision, retained 24 months. Queries below the
   500-property minimum are blocked and flagged automatically.
3. **System** — the six scheduled jobs, model accuracy, and live privacy checks.

---

## Privacy by design — the Privacy Linker Protocol

| Rule | What it does |
|------|--------------|
| 1 | Properties are joined by cadastral reference only — never personal identity |
| 2 | Nothing is shown for groups smaller than 500 properties |
| 3 | All data deleted after 24 months; every query logged |
| 4 | Derived misuse scores are private; only cluster summaries reach the interface |

---

## A note on the data

The cadastral structure, Airbnb listing patterns, and HUTB licence checks are based
on **real public data** (Ajuntament de Barcelona, Inside Airbnb, Generalitat de
Catalunya). The utility consumption data is **synthetic**, clearly labelled everywhere,
and calibrated to Barcelona benchmarks — real meter data requires a city data-sharing
agreement. See `data/DATA_SOURCES.md` for the full breakdown.

The precision figures (0.81 vacancy, 0.77 tourist use) are architecture-performance
indicators on synthetic data, not real-world accuracy claims.

---

## Licence

Code: MIT. Thesis text and figures: CC BY 4.0. See `LICENSE`.
