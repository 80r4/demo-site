import { useState, useEffect, useRef } from 'react';
import 'leaflet/dist/leaflet.css';
import { LeafletClusterMap } from './components/LeafletClusterMap';
import { jobs } from './data';
import { Cluster } from './types';
import {
  AppStateProvider, useAppState,
  applyFilters,
  AREA_LABELS, TYPE_LABELS, CONF_LABELS,
  SessionInfo,
} from './context/AppStateContext';

/* ─── Palettes ─── */
const DARK_C = {
  navy:    '#0D0F14',
  surf:    '#15181F',
  s2:      '#1C2030',
  s3:      '#232840',
  brd:     'rgba(255,255,255,0.08)',
  brd2:    'rgba(255,255,255,0.15)',
  text:    '#ECE9E4',
  muted:   '#848898',
  hint:    '#484C5E',
  /* Mediterranean Blue — civic, authoritative, Barcelona coast */
  accent:  '#5096CC',
  acDim:   'rgba(80,150,204,0.14)',
  acBrd:   'rgba(80,150,204,0.32)',
  green:   '#5CAA84',
  grnBg:   'rgba(92,170,132,0.10)',
  grnBrd:  'rgba(92,170,132,0.24)',
  blue:    '#5096CC',   /* same as accent in dark — blue IS the accent */
  bluBg:   'rgba(80,150,204,0.10)',
  bluBrd:  'rgba(80,150,204,0.24)',
  amber:   '#C4A050',
  ambBg:   'rgba(196,160,80,0.10)',
  ambBrd:  'rgba(196,160,80,0.26)',
  red:     '#B06868',
  redBg:   'rgba(176,104,104,0.10)',
  redBrd:  'rgba(176,104,104,0.26)',
  mono:    "'JetBrains Mono',monospace",
  sans:    "'Inter',sans-serif",
};

const LIGHT_C = {
  navy:    '#F0F4F8',   /* cool blue-white — pairs with blue accent */
  surf:    '#FFFFFF',
  s2:      '#E4EAF2',
  s3:      '#D8E0EC',
  brd:     'rgba(0,0,0,0.09)',
  brd2:    'rgba(0,0,0,0.16)',
  text:    '#111827',
  muted:   '#5A6278',
  hint:    '#9AA0B4',
  /* Deeper blue for light background — stays readable */
  accent:  '#1B72B8',
  acDim:   'rgba(27,114,184,0.11)',
  acBrd:   'rgba(27,114,184,0.30)',
  green:   '#1F7A50',
  grnBg:   'rgba(31,122,80,0.09)',
  grnBrd:  'rgba(31,122,80,0.24)',
  blue:    '#1B72B8',
  bluBg:   'rgba(27,114,184,0.09)',
  bluBrd:  'rgba(27,114,184,0.24)',
  amber:   '#8B6820',
  ambBg:   'rgba(139,104,32,0.09)',
  ambBrd:  'rgba(139,104,32,0.24)',
  red:     '#8B3838',
  redBg:   'rgba(139,56,56,0.09)',
  redBrd:  'rgba(139,56,56,0.24)',
  mono:    "'JetBrains Mono',monospace",
  sans:    "'Inter',sans-serif",
};

/* mutable — reassigned at root render to current theme */
let C = DARK_C;

/* ─── Global CSS ─── */
const GLOBE_CSS = `
@keyframes atm-pulse  { 0%,100%{opacity:0.6;} 50%{opacity:1;} }
@keyframes fade-up    { from{opacity:0;transform:translateY(14px);} to{opacity:1;transform:translateY(0);} }
@keyframes ticker     { from{transform:translateX(0);} to{transform:translateX(-50%);} }
@keyframes orbit-cw   { from{transform:rotate(0deg);}   to{transform:rotate(360deg);}  }
@keyframes orbit-ccw  { from{transform:rotate(0deg);}   to{transform:rotate(-360deg);} }
@keyframes grid-spin  { from{transform:rotate(0deg);}   to{transform:rotate(360deg);}  }
@keyframes grid-pulse { 0%,100%{opacity:0.20;} 50%{opacity:0.36;} }
@keyframes bcn-ring   { 0%{r:5;opacity:0.9} 100%{r:24;opacity:0} }
@keyframes skel        { 0%,100%{opacity:0.4}  50%{opacity:0.82}    }
/* Inter font features */
body { font-feature-settings: 'cv02','cv03','cv04','cv11'; -webkit-font-smoothing: antialiased; }
::-webkit-scrollbar { width: 5px; height: 5px; }
::-webkit-scrollbar-track { background: transparent; }
::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.10); border-radius: 3px; }
::-webkit-scrollbar-thumb:hover { background: rgba(255,255,255,0.18); }
::selection { background: rgba(80,150,204,0.28); color: #ECE9E4; }
button, a, select { transition: opacity 0.15s, background 0.15s, color 0.15s, border-color 0.15s; }
`;

/* ─── micro helpers ─── */
const mono = (s: string | number, color = C.hint, size = 11) =>
  <span style={{ fontFamily: C.mono, fontSize: size, color }}>{s}</span>;

const lbl = (s: string) =>
  <div style={{ fontFamily: C.mono, fontSize: 10, letterSpacing: '0.11em', textTransform: 'uppercase' as const, color: C.hint, fontWeight: 600, marginBottom: 6 }}>{s}</div>;

type PT = 'high'|'medium'|'watch'|'referred'|'dismissed'|'pending'|'ok'|'warn'|'neutral'|'run'|'blocked'|'logged';
function Pill({ t, children }: { t: PT; children: React.ReactNode }) {
  const m: Record<string, [string,string,string]> = {
    high:      [C.red,   C.redBg,  C.redBrd],
    medium:    [C.amber, C.ambBg,  C.ambBrd],
    watch:     [C.blue,  C.bluBg,  C.bluBrd],
    referred:  [C.blue,  C.bluBg,  C.bluBrd],
    dismissed: [C.amber, C.ambBg,  C.ambBrd],
    pending:   [C.blue,  C.bluBg,  C.bluBrd],
    ok:        [C.green, C.grnBg,  C.grnBrd],
    warn:      [C.amber, C.ambBg,  C.ambBrd],
    neutral:   [C.muted, C.s2,     C.brd],
    run:       [C.blue,  C.bluBg,  C.bluBrd],
    blocked:   [C.red,   C.redBg,  C.redBrd],
    logged:    [C.green, C.grnBg,  C.grnBrd],
  };
  const [fg,bg,bd] = m[t] || m.neutral;
  return (
    <span style={{ display:'inline-flex',alignItems:'center',padding:'2px 8px',borderRadius:2,background:bg,color:fg,border:`1px solid ${bd}`,fontFamily:C.mono,fontSize:10,fontWeight:600,letterSpacing:'0.07em',whiteSpace:'nowrap' }}>
      {String(children).toUpperCase()}
    </span>
  );
}

const panel = (children: React.ReactNode, style?: React.CSSProperties) =>
  <div style={{ background:C.surf,border:`1px solid ${C.brd}`,borderRadius:2,overflow:'hidden',...style }}>{children}</div>;

const pHead = (title: string, sub?: string, right?: React.ReactNode) =>
  <div style={{ padding:'14px 20px',borderBottom:`1px solid ${C.brd}`,display:'flex',alignItems:'center',justifyContent:'space-between' }}>
    <div>
      <div style={{ fontFamily:C.sans,fontSize:13,fontWeight:600,color:C.text,letterSpacing:'-0.01em' }}>{title}</div>
      {sub && <div style={{ fontFamily:C.mono,fontSize:11,color:C.muted,marginTop:3 }}>{sub}</div>}
    </div>
    {right}
  </div>;

const statCard = (label: string, val: string|number, sub: string, accent?: string) =>
  <div style={{ background:C.surf, border:`1px solid ${C.brd}`, borderRadius:2, padding:'20px 22px', borderTop:`2px solid ${accent||C.brd}` }}>
    {lbl(label)}
    <div style={{ fontFamily:C.mono, fontSize:30, fontWeight:700, color:accent||C.text, lineHeight:1, margin:'10px 0 7px', letterSpacing:'-0.02em' }}>{val}</div>
    <div style={{ fontFamily:C.sans, fontSize:12, color:C.muted }}>{sub}</div>
  </div>;

/* ─── Canvas globe ──────────────────────────────────────────────────────────
   Full orthographic projection with back-hemisphere culling and rotation.
   Starts centred on Barcelona (41°N, 2°E); rotates east at ~4°/s.
──────────────────────────────────────────────────────────────────────────── */
function SatelliteGlobe() {
  const SIZE = 320;
  const ORBIT = 210;

  const canvasRef = useRef<HTMLCanvasElement>(null);
  const rafRef    = useRef<number>(0);
  const lonRef    = useRef<number>(2); /* start centred on Barcelona */

  /* ── Complete world land outlines [lat, lon][] ── */
  const G = '#1E3A28', GE = 'rgba(80,200,120,0.22)';  /* forest green */
  const D = '#4A3E22', DE = 'rgba(200,170,80,0.30)';  /* desert tan */
  const A = '#1A3A24', AE = 'rgba(70,190,110,0.20)';  /* Americas green */
  const AS= '#1D3530', ASE= 'rgba(70,200,130,0.20)';  /* Asia green */
  const AU= '#3D3018', AUE= 'rgba(180,150,60,0.28)';  /* Australia arid */

  const LANDS: { pts:[number,number][]; fill:string; edge:string }[] = [
    /* ── Africa (complete) ── */
    { fill:D, edge:DE, pts:[
      [35.8,-5.8],[35.9,-1.2],[36.9,3.0],[37.1,9.5],[33.9,11.6],
      [31.5,25.0],[30.0,32.4],[29.5,34.5],[27.5,34.8],[22.0,37.5],
      [12.5,43.5],[11.5,51.5],[10.5,51.0],[2.0,41.5],[-1.0,41.8],
      [-4.5,39.8],[-11.0,40.5],[-17.0,38.0],[-25.0,35.0],[-30.0,31.2],
      [-34.0,27.0],[-34.5,20.0],[-29.0,17.0],[-22.0,14.5],[-17.5,12.0],
      [-5.0,8.5],[-1.0,9.2],[1.5,9.5],[4.5,2.5],[5.0,-5.0],
      [5.5,-8.0],[10.0,-15.0],[14.5,-17.5],[21.0,-17.2],[27.7,-13.2],
      [30.9,-9.8],[33.5,-6.8],[35.1,-5.5],[35.8,-5.8],
    ]},
    /* ── Iberian Peninsula (highlighted) ── */
    { fill:'#254E30', edge:'rgba(100,220,140,0.38)', pts:[
      [43.7,-8.2],[43.8,-7.0],[43.4,-4.0],[43.4,-1.8],[42.8,3.2],
      [41.3,2.1],[40.4,0.4],[38.6,0.2],[37.3,1.5],[36.5,-2.1],
      [36.1,-5.4],[37.0,-6.9],[37.8,-8.8],[38.8,-9.5],[39.6,-9.2],
      [40.2,-8.7],[41.8,-8.8],[43.0,-8.9],[43.7,-8.2],
    ]},
    /* ── France + Benelux ── */
    { fill:G, edge:GE, pts:[
      [42.8,3.2],[43.3,5.3],[43.7,7.3],[44.4,8.8],[45.5,8.0],
      [47.5,7.7],[49.0,8.0],[51.0,4.0],[51.5,2.5],[50.6,1.6],
      [49.0,-1.6],[48.2,-4.8],[47.5,-2.8],[46.5,-1.8],[45.7,-1.1],
      [44.3,-1.3],[43.4,-1.8],[42.8,3.2],
    ]},
    /* ── British Isles ── */
    { fill:G, edge:GE, pts:[
      [51.0,-1.0],[51.5,1.3],[52.9,1.8],[53.8,0.3],[55.0,-1.5],
      [56.0,-2.4],[57.6,-3.8],[58.5,-4.5],[57.0,-5.7],[55.8,-5.4],
      [54.7,-5.0],[53.5,-3.5],[52.8,-4.5],[51.5,-5.0],[50.0,-5.6],
      [49.9,-2.0],[51.0,-1.0],
    ]},
    /* ── Scandinavia ── */
    { fill:G, edge:GE, pts:[
      [57.5,8.0],[55.5,8.0],[54.5,10.0],[55.0,12.6],[55.5,14.0],
      [57.0,16.5],[59.0,18.8],[60.2,18.0],[59.5,10.8],[61.0,5.0],
      [62.5,5.5],[64.0,8.0],[65.5,14.0],[68.0,16.0],[70.0,25.5],
      [71.2,27.5],[70.8,28.5],[69.5,18.5],[65.0,14.0],[63.5,9.5],
      [60.5,5.0],[57.5,8.0],
    ]},
    /* ── Italy + Sicily ── */
    { fill:G, edge:GE, pts:[
      [44.4,8.8],[44.1,12.2],[43.8,13.5],[42.5,14.2],[40.9,15.8],
      [39.3,16.5],[38.1,15.7],[37.9,15.0],[38.7,15.5],[39.8,15.7],
      [41.0,14.2],[43.6,13.5],[43.9,12.3],[43.8,11.3],[44.4,10.2],[44.4,8.8],
    ]},
    { fill:G, edge:GE, pts:[[37.9,15.0],[37.5,15.2],[37.1,15.6],[36.7,15.1],[36.6,13.8],[37.2,13.0],[38.2,12.5],[38.3,13.5],[37.9,15.0]]},
    /* ── Sardinia / Corsica / Balearics ── */
    { fill:G, edge:GE, pts:[[41.2,8.2],[40.5,9.6],[39.8,9.7],[38.9,8.5],[38.9,8.3],[40.2,8.2],[41.2,8.2]]},
    { fill:G, edge:GE, pts:[[43.0,9.4],[42.3,9.5],[41.6,9.2],[41.5,8.9],[42.4,8.5],[43.0,9.4]]},
    { fill:'#254E30', edge:'rgba(100,220,140,0.30)', pts:[[39.9,3.1],[39.6,3.4],[39.4,2.7],[39.7,2.5],[39.9,3.1]]},
    /* ── Eastern + Central Europe ── */
    { fill:G, edge:GE, pts:[
      [49.0,8.0],[48.5,14.5],[47.0,17.0],[45.5,16.5],[44.8,20.3],
      [44.0,22.0],[42.0,23.5],[41.5,26.0],[40.5,28.5],[41.0,29.5],
      [41.5,28.2],[44.0,26.0],[46.0,24.5],[48.5,22.5],[50.0,18.5],
      [51.5,14.5],[54.5,18.5],[54.5,22.0],[57.0,24.0],[59.5,24.5],
      [60.0,25.0],[60.5,21.5],[60.0,19.0],[59.5,18.8],[57.0,16.5],
      [55.0,14.0],[54.5,10.0],[55.5,8.0],[57.5,8.0],[55.8,5.5],
      [51.0,4.0],[49.0,8.0],
    ]},
    /* ── Russia (simplified – European + W.Siberian + Far East) ── */
    { fill:G, edge:GE, pts:[
      [59.5,24.5],[60.0,28.0],[60.8,29.5],[60.0,32.5],[61.5,31.0],
      [64.0,33.0],[68.5,32.5],[69.5,30.0],[70.5,29.0],[71.0,26.0],
      [70.0,25.5],[68.0,16.0],[65.5,14.0],[64.0,8.0],[62.5,5.5],
      [60.5,5.0],[57.5,8.0],[60.0,19.0],[60.5,21.5],[60.0,25.0],[59.5,24.5],
    ]},
    { fill:G, edge:'rgba(70,180,110,0.15)', pts:[
      /* Russia Arctic coast W→E, then south down Far East coast */
      [68.5,32.5],[69.0,33.5],[69.8,44.0],[70.5,53.0],[72.0,68.0],
      [72.5,79.0],[72.0,90.0],[73.5,105.0],[73.8,120.0],[72.0,130.0],
      [68.5,140.0],[63.0,142.0],[59.0,150.5],[52.5,158.5],[51.0,157.0],
      /* Kamchatka → Sakhalin → Vladivostok */
      [52.0,145.0],[48.5,135.0],[44.0,132.5],[42.5,131.0],
      [44.0,135.0],[47.0,138.5],[48.5,140.5],
      /* Back inland via Amur river then west across S.Siberia */
      [50.0,127.0],[52.5,121.0],[55.0,109.5],[55.0,97.5],
      [53.0,86.0],[51.0,80.5],[49.0,52.0],[46.0,51.0],
      [44.5,48.0],[42.0,45.0],[41.0,44.5],
      /* Caucasus north slope → Caspian → back to Arctic W */
      [44.5,48.0],[46.0,51.0],[49.0,52.0],[51.0,60.0],
      [53.0,62.0],[55.0,61.0],[57.0,66.0],[60.0,64.0],
      [62.0,63.0],[64.0,64.5],[66.0,66.0],[68.0,68.0],
      [68.5,56.0],[68.5,44.0],[68.8,37.0],[68.5,32.5],
    ]},
    /* ── Turkey + Caucasus ── */
    { fill:AS, edge:ASE, pts:[
      [37.0,26.5],[38.0,26.0],[39.0,27.0],[40.5,29.5],[41.0,33.5],
      [41.5,36.5],[41.0,40.0],[39.5,41.0],[38.5,40.5],[38.0,44.0],
      [37.5,44.5],[36.5,42.0],[36.5,36.5],[36.0,35.5],[36.2,36.0],
      [36.5,36.5],[35.5,34.5],[35.2,33.8],[36.0,29.5],[36.0,27.5],[37.0,26.5],
    ]},
    /* ── Middle East (Arabia + Levant + Iraq + Iran) ── */
    { fill:D, edge:DE, pts:[
      [29.5,34.5],[31.5,34.5],[33.5,35.8],[35.5,36.5],[37.0,41.0],
      [36.5,43.0],[33.5,44.5],[30.0,48.0],[28.5,50.0],[26.0,50.5],
      [24.5,51.5],[23.5,58.5],[22.5,59.0],[16.5,53.0],[12.5,45.0],
      [12.5,43.5],[13.5,43.0],[15.0,42.5],[18.0,42.0],[22.5,39.5],
      [27.0,36.0],[29.5,34.5],
    ]},
    /* ── Iran + Afghanistan ── */
    { fill:D, edge:'rgba(190,160,70,0.28)', pts:[
      [37.0,44.5],[38.5,44.0],[38.5,48.5],[39.0,53.0],[37.5,57.5],
      [35.0,60.5],[32.0,61.5],[29.5,61.5],[25.0,62.5],[24.0,61.0],
      [22.5,59.0],[23.5,58.5],[26.0,50.5],[28.5,50.0],[30.0,48.0],
      [33.5,44.5],[36.5,43.0],[37.0,41.0],[37.0,44.5],
    ]},
    /* ── Indian Subcontinent ── */
    { fill:AS, edge:ASE, pts:[
      [24.0,61.0],[25.0,62.5],[29.5,61.5],[32.0,61.5],[35.0,60.5],
      [37.5,57.5],[39.0,53.0],[38.5,48.5],[38.5,44.0],[37.0,44.5],
      [36.5,43.0],[33.5,44.5],[30.0,48.0],[28.5,50.0],[26.0,50.5],
      [22.5,59.0],[24.0,61.0],
    ]},
    /* India peninsula — west coast S then east coast N */
    { fill:AS, edge:ASE, pts:[
      /* NW Gujarat coast */
      [23.5,68.5],[22.5,69.5],[21.0,72.5],[20.0,73.0],
      /* West coast: Goa, Kerala → southern tip */
      [17.0,73.5],[14.5,74.5],[12.0,75.5],[10.0,76.5],[8.5,77.0],
      [8.0,77.5],[8.5,78.5],[9.5,80.0],
      /* East coast N → Bangladesh */
      [13.0,80.5],[15.0,80.5],[17.5,82.5],[20.5,86.5],
      [22.5,88.0],[22.5,88.5],[23.5,91.5],[22.0,92.5],
      /* NE India → back west across N India */
      [26.0,90.0],[27.5,88.0],[28.0,85.5],[27.5,84.0],
      [27.5,80.5],[28.5,77.5],[29.5,74.5],[28.5,72.5],
      [26.5,69.0],[24.5,68.5],[23.5,68.5],
    ]},
    /* Sri Lanka */
    { fill:AS, edge:ASE, pts:[[9.8,80.2],[9.0,79.8],[6.0,80.2],[7.5,81.5],[9.8,80.2]]},
    /* ── Central / South Asia ── */
    { fill:AS, edge:ASE, pts:[
      [38.5,48.5],[38.5,44.0],[41.0,44.5],[42.0,45.0],[44.5,48.0],
      [46.0,51.0],[49.0,52.0],[51.0,60.0],[53.0,62.0],[55.0,61.0],
      [57.0,66.0],[57.5,72.0],[55.5,73.5],[52.0,77.0],[50.0,80.5],
      [48.0,84.5],[44.5,80.5],[43.0,77.0],[40.5,72.5],[38.0,68.5],
      [36.5,67.0],[37.5,57.5],[39.0,53.0],[38.5,48.5],
    ]},
    /* ── Mongolia ── clean clockwise single outline ── */
    { fill:AS, edge:ASE, pts:[
      /* N border (Russia) W→E */
      [50.0,87.0],[50.5,92.0],[51.0,102.0],[50.5,108.0],
      [50.0,112.0],[49.5,116.0],[49.0,119.5],
      /* E → SE → S border (Gobi Desert) → SW → W */
      [47.0,119.0],[46.0,117.0],[44.5,112.5],
      [43.0,110.0],[42.5,107.0],[42.0,104.5],
      [42.0,101.0],[42.5,97.0],[41.5,93.0],
      [41.5,91.0],[43.0,89.5],[45.0,87.5],[50.0,87.0],
    ]},
    /* ── China + Manchuria — single clockwise polygon ── */
    { fill:AS, edge:ASE, pts:[
      /* NW corner (Xinjiang border with Kazakhstan) */
      [49.0,87.0],
      /* W border going S: Xinjiang → Tibet */
      [47.0,84.0],[43.0,79.0],[40.5,76.0],[38.5,73.5],[36.5,73.0],
      /* SW: Pakistan/India/Nepal border → Tibet S → Myanmar */
      [34.5,72.5],[34.5,78.0],[32.0,80.0],[29.5,80.0],
      [28.0,84.5],[27.5,88.0],[27.5,92.0],[27.0,97.0],
      /* S: Burma/Laos/Vietnam border → Yunnan */
      [23.5,98.5],[22.0,100.5],[21.0,101.5],[21.0,104.5],
      /* SE coast going N */
      [20.5,110.0],[22.0,114.0],[24.5,117.0],
      [26.5,119.5],[28.0,121.0],[30.0,122.0],[32.5,121.0],
      [35.5,120.0],[37.0,120.0],[38.5,121.0],
      [40.0,122.5],[40.5,124.5],
      /* Korea border → Manchuria → Russian Far East border */
      [42.5,130.5],[44.0,132.0],[46.0,134.5],
      [48.5,135.0],[50.0,127.0],[53.0,122.0],
      /* N border: Russia/Mongolia going W */
      [50.0,120.0],[50.0,112.0],[50.5,108.0],
      [51.0,102.0],[50.5,92.0],[49.0,87.0],
    ]},
    /* Korea peninsula */
    { fill:AS, edge:ASE, pts:[
      [38.0,126.5],[34.5,126.5],[34.0,127.0],[34.5,129.0],
      [35.5,130.5],[38.0,128.5],[40.5,129.0],[40.0,126.5],[38.0,126.5],
    ]},
    /* Japan main islands */
    { fill:AS, edge:ASE, pts:[[31.5,131.0],[33.0,131.5],[33.5,131.0],[34.0,131.5],[34.5,131.8],[35.5,136.0],[36.5,136.5],[37.5,137.5],[39.0,140.5],[40.5,141.5],[41.5,141.0],[40.5,139.5],[38.5,137.0],[36.0,136.0],[34.5,136.5],[33.5,130.5],[31.5,131.0]]},
    { fill:AS, edge:ASE, pts:[[43.0,141.5],[42.5,141.0],[42.0,140.0],[41.5,140.5],[42.0,141.5],[42.5,143.0],[43.0,144.5],[44.5,145.0],[44.0,143.0],[43.0,141.5]]},
    /* ── Southeast Asia ── */
    /* Indochina + Malaysia peninsula */
    { fill:AS, edge:ASE, pts:[
      [20.5,100.0],[20.0,100.0],[18.5,103.0],[17.5,102.5],[16.5,104.5],
      [14.0,103.5],[12.5,102.0],[10.5,104.0],[8.5,103.5],[4.5,103.5],
      [2.0,104.0],[1.5,103.5],[4.5,100.5],[6.5,99.5],[8.5,98.5],
      [10.5,99.5],[11.5,100.0],[13.0,100.5],[14.0,100.5],[15.5,100.5],
      [17.5,100.5],[19.0,100.5],[20.5,100.0],
    ]},
    /* Sumatra */
    { fill:AS, edge:ASE, pts:[[5.5,95.5],[4.0,96.5],[2.0,99.0],[0.0,101.0],[-2.0,102.5],[-4.0,104.0],[-5.5,105.0],[-4.5,105.5],[-2.0,103.5],[0.5,101.5],[3.0,99.5],[5.0,97.5],[5.5,95.5]]},
    /* Borneo (simplified) */
    { fill:AS, edge:ASE, pts:[[7.0,117.0],[6.0,116.5],[4.5,118.5],[4.0,117.5],[2.0,117.0],[0.5,118.0],[-1.0,117.0],[-1.5,116.0],[1.0,109.5],[2.5,111.0],[4.5,113.5],[6.5,116.5],[7.0,117.0]]},
    /* Java */
    { fill:AS, edge:ASE, pts:[[-6.0,107.0],[-6.5,108.5],[-7.5,110.5],[-7.0,112.5],[-8.0,115.0],[-8.5,115.5],[-8.5,114.5],[-7.5,111.0],[-6.5,108.0],[-6.0,107.0]]},
    /* Philippines (Luzon) */
    { fill:AS, edge:ASE, pts:[[18.5,121.0],[17.0,122.5],[15.0,121.5],[14.0,122.0],[13.5,121.5],[14.5,120.5],[16.0,119.5],[18.0,120.0],[18.5,121.0]]},
    /* ── North America ── */
    { fill:A, edge:'rgba(80,200,120,0.22)', pts:[
      [70.5,-156.0],[64.0,-168.0],[60.5,-147.0],[59.5,-150.0],
      [57.0,-135.0],[54.5,-130.5],[50.5,-128.5],[48.5,-124.5],
      [46.0,-124.0],[42.0,-124.5],[38.0,-123.0],[34.0,-120.5],
      [32.5,-117.0],[30.5,-115.5],[23.5,-110.0],[22.0,-106.0],
      [20.5,-105.0],[19.5,-104.0],[17.0,-100.5],[16.5,-92.0],
      [18.5,-88.5],[21.5,-87.5],[21.0,-86.5],[20.5,-86.8],
      [20.5,-90.0],[16.5,-92.0],[14.5,-93.0],[10.5,-85.5],
      [8.5,-83.0],[8.0,-77.0],[9.5,-79.5],[9.5,-76.0],[9.0,-77.5],
      [11.5,-83.0],[14.5,-83.5],[15.0,-84.5],[16.5,-86.0],
      [18.5,-88.5],[21.5,-87.5],[24.5,-81.5],[25.5,-80.0],
      [28.5,-80.5],[30.5,-81.0],[31.5,-81.0],[33.5,-79.0],
      [35.5,-75.5],[37.5,-75.5],[38.0,-75.5],[40.5,-74.0],
      [41.5,-71.0],[42.5,-70.5],[43.5,-70.0],[44.5,-66.5],
      [47.0,-53.5],[49.5,-55.5],[51.0,-56.0],[53.0,-56.0],
      [56.0,-62.0],[60.0,-64.5],[62.5,-69.5],[63.0,-78.0],
      [57.0,-76.5],[55.0,-76.5],[53.0,-79.0],[53.0,-82.0],
      [55.0,-82.0],[56.0,-79.0],[56.5,-81.0],[57.0,-89.5],
      [56.0,-93.5],[57.5,-92.0],[58.0,-93.5],[55.5,-98.0],
      [55.0,-95.0],[53.0,-97.0],[52.5,-102.0],[55.0,-110.0],
      [58.0,-113.0],[60.0,-111.0],[60.5,-113.5],[63.0,-117.0],
      [65.0,-126.0],[68.0,-133.0],[69.5,-141.0],[70.5,-142.0],
      [70.5,-156.0],
    ]},
    /* Greenland */
    { fill:A, edge:'rgba(80,200,120,0.18)', pts:[
      [60.0,-44.0],[62.0,-42.0],[63.5,-41.0],[65.5,-37.5],[68.5,-30.0],
      [71.0,-24.0],[76.5,-19.5],[78.5,-18.0],[81.0,-20.0],[83.5,-30.0],
      [83.5,-42.0],[82.0,-50.0],[82.5,-57.5],[80.5,-64.0],[76.5,-68.5],
      [72.5,-68.0],[70.0,-68.5],[67.0,-53.5],[65.5,-53.0],[65.0,-52.0],
      [63.0,-50.5],[62.0,-47.5],[60.5,-46.0],[60.0,-44.0],
    ]},
    /* Iceland */
    { fill:G, edge:GE, pts:[[64.5,-22.5],[63.5,-20.0],[64.0,-14.5],[65.5,-13.5],[66.5,-18.0],[65.5,-24.0],[64.5,-22.5]]},
    /* ── South America (single clean clockwise outline) ── */
    { fill:A, edge:'rgba(80,200,120,0.25)', pts:[
      /* Venezuela/Colombia N coast → NE Brazil */
      [12.0,-72.0],[11.8,-70.5],[11.5,-69.0],[10.5,-62.0],[10.8,-61.5],
      [8.5,-61.0],[7.0,-58.5],[6.0,-57.0],[5.5,-57.0],[4.5,-52.5],
      [4.0,-51.5],[3.5,-51.5],[2.5,-50.5],[2.0,-49.5],[1.5,-48.5],
      [0.0,-50.5],[-1.5,-48.5],[-1.5,-44.5],
      /* Brazil NE bulge */
      [-3.5,-38.5],[-5.0,-35.5],[-8.0,-35.0],
      /* Brazil east coast south */
      [-12.5,-38.0],[-15.0,-39.0],[-18.0,-39.5],[-21.0,-41.0],
      [-23.5,-43.5],[-24.0,-46.5],[-26.0,-48.5],[-28.5,-49.5],
      [-29.5,-50.5],[-32.0,-52.5],[-33.5,-53.5],
      /* River Plate / Argentina coast */
      [-34.5,-57.5],[-38.0,-57.5],[-40.5,-62.5],[-43.0,-65.5],
      [-48.0,-66.0],[-50.0,-68.5],
      /* Tierra del Fuego */
      [-52.5,-68.5],[-54.0,-67.0],[-55.5,-67.5],[-55.0,-66.0],
      [-54.5,-65.5],[-53.0,-68.5],[-52.0,-69.5],
      /* West coast Patagonia → Chile */
      [-50.0,-75.0],[-46.0,-75.5],[-44.0,-74.5],[-42.0,-74.0],
      [-38.0,-72.5],[-34.0,-71.5],[-30.0,-71.5],[-26.0,-70.5],
      [-22.0,-70.5],[-18.0,-70.5],
      /* Peru → Ecuador → Colombia */
      [-14.0,-76.0],[-10.0,-78.0],[-6.0,-81.0],[-3.5,-80.5],
      [0.0,-80.0],[1.0,-78.5],[3.5,-77.5],[4.5,-77.0],
      /* Panama / Colombia border back to Venezuela */
      [8.5,-77.5],[9.5,-79.5],[8.5,-77.5],[11.0,-74.0],[12.0,-72.0],
    ]},
    /* ── Australia (single clean polygon) ── */
    { fill:AU, edge:AUE, pts:[
      /* West coast N→S */
      [-22.0,114.0],[-26.0,114.0],[-29.5,115.0],[-32.0,115.5],
      [-34.5,116.5],[-34.0,118.5],[-33.5,121.5],[-32.5,126.0],
      [-32.5,131.5],[-32.5,134.0],
      /* Great Australian Bight + SE coast */
      [-34.0,135.5],[-35.0,136.5],[-35.5,137.5],[-38.0,140.5],
      [-38.5,145.5],[-38.5,146.0],[-37.5,150.0],[-35.5,150.5],
      [-34.0,151.0],[-31.5,152.5],[-27.5,153.5],[-23.5,150.5],
      /* QLD + Cape York */
      [-19.0,147.0],[-15.0,145.5],[-11.5,142.0],
      /* North coast */
      [-12.0,136.5],[-12.0,134.5],[-11.0,132.0],[-11.5,130.5],
      [-14.5,129.0],[-17.5,122.0],[-22.0,114.0],
    ]},
    /* Tasmania */
    { fill:AU, edge:AUE, pts:[[-41.5,145.0],[-43.5,146.5],[-43.5,148.0],[-41.5,148.0],[-40.5,148.0],[-41.5,145.0]]},
    /* New Zealand N + S */
    { fill:A, edge:GE, pts:[[-34.5,172.5],[-37.5,175.0],[-38.5,176.5],[-39.5,176.5],[-40.5,176.0],[-41.5,174.5],[-41.5,172.5],[-40.0,172.5],[-38.0,174.5],[-36.0,174.5],[-34.5,172.5]]},
    { fill:A, edge:GE, pts:[[-41.5,174.5],[-43.5,173.0],[-45.0,168.5],[-46.5,168.0],[-46.5,169.5],[-44.5,171.5],[-42.5,173.5],[-41.5,174.5]]},
    /* ── Antarctica (southern cap) ── */
    { fill:'#3A4A5A', edge:'rgba(180,220,255,0.30)', pts:[
      [-70.0,-180],[-70.0,-150],[-72.0,-120],[-70.0,-90],
      [-72.0,-60],[-71.0,-30],[-70.5,0],[-71.5,30],
      [-70.0,60],[-71.5,90],[-70.0,120],[-71.5,150],
      [-70.0,180],[-68.0,180],[-68.0,-180],[-70.0,-180],
    ]},
  ];

  /* City dots [lat, lon, isAccent] */
  const CITIES: [number,number,boolean][] = [
    [41.4,  2.2, true],   /* BCN */
    [40.4,  -3.7, false], /* Madrid */
    [48.9,  2.3, false],  /* Paris */
    [51.5,  -0.1,false],  /* London */
    [41.9, 12.5, false],  /* Rome */
    [55.8, 37.6, false],  /* Moscow */
    [40.7, 29.0, false],  /* Istanbul */
    [30.0, 31.2, false],  /* Cairo */
    [6.5,  3.3, false],   /* Lagos */
    [-26.0,28.0, false],  /* Johannesburg */
    [-33.9,18.4, false],  /* Cape Town */
    [19.1, 72.9, false],  /* Mumbai */
    [28.6, 77.2, false],  /* Delhi */
    [13.1,80.3, false],   /* Chennai */
    [22.5, 88.4, false],  /* Kolkata */
    [1.3, 103.8,false],   /* Singapore */
    [13.8,100.5,false],   /* Bangkok */
    [21.0,105.8,false],   /* Hanoi */
    [39.9,116.4,false],   /* Beijing */
    [31.2,121.5,false],   /* Shanghai */
    [35.7,139.7,false],   /* Tokyo */
    [37.6,127.0,false],   /* Seoul */
    [-33.9,151.2,false],  /* Sydney */
    [40.7, -74.0,false],  /* New York */
    [19.4, -99.1,false],  /* Mexico City */
    [-23.5,-46.6,false],  /* São Paulo */
    [-34.6,-58.4,false],  /* Buenos Aires */
    [33.6,  -7.6,false],  /* Casablanca */
    [36.8,  3.0, false],  /* Algiers */
    [43.3,  5.4, false],  /* Marseille */
    [52.5, 13.4, false],  /* Berlin */
    [50.1,  8.7, false],  /* Frankfurt */
    [59.9, 10.7, false],  /* Oslo */
    [59.3, 18.1, false],  /* Stockholm */
  ];

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const W = SIZE, H = SIZE;
    const cx = W/2, cy = H/2, R = 148;
    const phi0 = 41 * Math.PI/180;  /* lat centre — fixed at Barcelona */

    const project = (lat: number, lon: number, lonCentre: number): [number,number]|null => {
      const phi = lat * Math.PI/180;
      const lam = lon * Math.PI/180;
      const lam0 = lonCentre * Math.PI/180;
      const cosC = Math.sin(phi0)*Math.sin(phi) + Math.cos(phi0)*Math.cos(phi)*Math.cos(lam-lam0);
      if (cosC < 0) return null; /* back hemisphere */
      return [
        cx + R * Math.cos(phi) * Math.sin(lam-lam0),
        cy - R * (Math.cos(phi0)*Math.sin(phi) - Math.sin(phi0)*Math.cos(phi)*Math.cos(lam-lam0)),
      ];
    };

    const drawPoly = (pts: [number,number][], fill: string, edge: string, lonC: number) => {
      const mapped = pts.map(([la,lo]) => project(la, lo, lonC)).filter(Boolean) as [number,number][];
      if (mapped.length < 3) return;
      ctx.beginPath();
      ctx.moveTo(mapped[0][0], mapped[0][1]);
      for (let i = 1; i < mapped.length; i++) ctx.lineTo(mapped[i][0], mapped[i][1]);
      ctx.closePath();
      ctx.fillStyle = fill;
      ctx.fill();
      ctx.strokeStyle = edge;
      ctx.lineWidth = 0.8;
      ctx.stroke();
    };

    const drawGraticule = (lonC: number) => {
      /* parallels */
      for (const lat of [-60,-30,0,30,60]) {
        ctx.beginPath();
        let first = true;
        for (let lo = -180; lo <= 180; lo += 3) {
          const p = project(lat, lo, lonC);
          if (p) { first ? ctx.moveTo(p[0],p[1]) : ctx.lineTo(p[0],p[1]); first=false; }
          else first = true;
        }
        ctx.strokeStyle = lat===0 ? 'rgba(100,160,230,0.32)' : 'rgba(100,160,230,0.13)';
        ctx.lineWidth = lat===0 ? 0.7 : 0.5;
        ctx.stroke();
      }
      /* meridians every 30° */
      for (let lo = -180; lo < 180; lo += 30) {
        ctx.beginPath();
        let first = true;
        for (let la = -85; la <= 85; la += 3) {
          const p = project(la, lo, lonC);
          if (p) { first ? ctx.moveTo(p[0],p[1]) : ctx.lineTo(p[0],p[1]); first=false; }
          else first = true;
        }
        ctx.strokeStyle = 'rgba(100,160,230,0.10)';
        ctx.lineWidth = 0.5;
        ctx.stroke();
      }
    };

    let lastTime = 0;
    const frame = (ts: number) => {
      const dt = Math.min((ts - lastTime) / 1000, 0.05);
      lastTime = ts;
      lonRef.current += dt * 3.5; /* 3.5°/s — full rotation in ~103s */

      const lonC = lonRef.current;
      ctx.clearRect(0, 0, W, H);

      /* ocean */
      const og = ctx.createRadialGradient(cx*0.7, cy*0.65, 0, cx, cy, R);
      og.addColorStop(0, '#1B3A6E');
      og.addColorStop(0.55, '#0D2044');
      og.addColorStop(1, '#040E22');
      ctx.beginPath(); ctx.arc(cx, cy, R, 0, Math.PI*2);
      ctx.fillStyle = og; ctx.fill();

      /* graticule */
      drawGraticule(lonC);

      /* land */
      LANDS.forEach(({ pts, fill, edge }) => drawPoly(pts, fill, edge, lonC));

      /* cities */
      CITIES.forEach(([lat, lon, accent]) => {
        const p = project(lat, lon, lonC);
        if (!p) return;
        const [px, py] = p;
        if (accent) {
          /* BCN pulse ring */
          const t = (ts % 2600) / 2600;
          ctx.beginPath(); ctx.arc(px, py, 5 + t*18, 0, Math.PI*2);
          ctx.strokeStyle = `rgba(80,150,220,${(1-t)*0.75})`; ctx.lineWidth = 1.2; ctx.stroke();
          ctx.beginPath(); ctx.arc(px, py, 4.5, 0, Math.PI*2);
          ctx.fillStyle = '#5096CC'; ctx.fill();
          ctx.beginPath(); ctx.arc(px, py, 2, 0, Math.PI*2);
          ctx.fillStyle = 'white'; ctx.fill();
          ctx.fillStyle = '#5096CC';
          ctx.font = '700 8px "JetBrains Mono",monospace';
          ctx.fillText('BCN', px+7, py-7);
        } else {
          ctx.beginPath(); ctx.arc(px, py, 2, 0, Math.PI*2);
          ctx.fillStyle = 'rgba(240,215,140,0.55)'; ctx.fill();
        }
      });

      /* atmosphere limb */
      const ag = ctx.createRadialGradient(cx, cy, R*0.82, cx, cy, R);
      ag.addColorStop(0, 'transparent');
      ag.addColorStop(1, 'rgba(80,150,230,0.24)');
      ctx.beginPath(); ctx.arc(cx, cy, R, 0, Math.PI*2);
      ctx.fillStyle = ag; ctx.fill();

      /* specular highlight top-left */
      const sg = ctx.createRadialGradient(cx*0.65, cy*0.60, 0, cx, cy, R);
      sg.addColorStop(0, 'rgba(255,255,255,0.09)');
      sg.addColorStop(0.4, 'transparent');
      ctx.fillStyle = sg; ctx.fill();

      /* edge vignette — sphere illusion */
      const vg = ctx.createRadialGradient(cx, cy, R*0.72, cx, cy, R);
      vg.addColorStop(0, 'transparent');
      vg.addColorStop(1, 'rgba(0,6,18,0.72)');
      ctx.fillStyle = vg; ctx.fill();

      /* rim */
      ctx.beginPath(); ctx.arc(cx, cy, R, 0, Math.PI*2);
      ctx.strokeStyle = 'rgba(80,150,230,0.22)'; ctx.lineWidth = 1.5; ctx.stroke();

      rafRef.current = requestAnimationFrame(frame);
    };

    rafRef.current = requestAnimationFrame(frame);
    return () => cancelAnimationFrame(rafRef.current);
  }, []);

  return (
    <div style={{ position:'relative', width:SIZE+100, height:SIZE+100, flexShrink:0 }}>
      {/* atmosphere halo */}
      <div style={{ position:'absolute', top:'50%', left:'50%', width:SIZE+72, height:SIZE+72, marginLeft:-(SIZE+72)/2, marginTop:-(SIZE+72)/2, borderRadius:'50%', background:'radial-gradient(circle, transparent 50%, rgba(80,150,230,0.15) 72%, rgba(40,100,180,0.04) 100%)', animation:'atm-pulse 5s ease-in-out infinite', pointerEvents:'none' }}/>
      <div style={{ position:'absolute', top:'50%', left:'50%', width:SIZE+26, height:SIZE+26, marginLeft:-(SIZE+26)/2, marginTop:-(SIZE+26)/2, borderRadius:'50%', border:'1px solid rgba(100,170,255,0.11)', pointerEvents:'none' }}/>

      {/* orbit ring */}
      <div style={{ position:'absolute', top:'50%', left:'50%', width:ORBIT*2, height:ORBIT*2, marginLeft:-ORBIT, marginTop:-ORBIT, borderRadius:'50%', border:`1px dashed ${C.brd}`, animation:'orbit-cw 28s linear infinite' }}>
        {[
          { label:'CADASTRE', color:C.blue,  angle:  0 },
          { label:'AIRBNB',   color:C.red,   angle: 90 },
          { label:'UTILITY',  color:C.green, angle:180 },
          { label:'EMPADRON', color:C.amber, angle:270 },
        ].map(({ label, color, angle }) => {
          const rad = angle * Math.PI / 180;
          const ox = Math.cos(rad) * ORBIT, oy = Math.sin(rad) * ORBIT;
          return (
            <div key={label} style={{ position:'absolute', top:'50%', left:'50%', transform:`translate(calc(${ox}px - 50%), calc(${oy}px - 50%))`, animation:'orbit-ccw 28s linear infinite' }}>
              <div style={{ padding:'3px 9px', borderRadius:2, background:C.navy, border:`1px solid ${color}40`, fontFamily:C.mono, fontSize:9, color, letterSpacing:'0.09em', whiteSpace:'nowrap', fontWeight:600 }}>{label}</div>
            </div>
          );
        })}
      </div>

      {/* canvas globe */}
      <canvas ref={canvasRef} width={SIZE} height={SIZE} style={{ position:'absolute', top:50, left:50, borderRadius:'50%', boxShadow:'0 12px 60px rgba(0,0,0,0.7)' }}/>

      <div style={{ position:'absolute', bottom:2, left:'50%', transform:'translateX(-50%)', fontFamily:C.mono, fontSize:10, color:C.muted, whiteSpace:'nowrap', letterSpacing:'0.05em' }}>
        41.3851° N · 2.1734° E · Barcelona
      </div>
    </div>
  );
}

/* ─── Ticker ─── */
function Ticker({ inline }: { inline?: boolean }) {
  const items = ['PILOT 01','BARCELONA','k ≥ 500','GRÀCIA','EIXAMPLE','48,320 PROPERTIES','PRIVACY-FIRST','7 CLUSTERS','CADASTRE · AIRBNB · UTILITY · EMPADRON','THESIS PROTOTYPE'];
  const rep = [...items, ...items];
  if (inline) {
    return (
      <div style={{ overflow:'hidden', width:200, flexShrink:0 }}>
        <div style={{ display:'flex', gap:32, width:'max-content', animation:'ticker 20s linear infinite' }}>
          {rep.map((item, i) => (
            <span key={i} style={{ fontFamily:C.mono, fontSize:9, color:C.hint, letterSpacing:'0.10em', whiteSpace:'nowrap', flexShrink:0 }}>
              <span style={{ color:C.accent, marginRight:10 }}>·</span>{item}
            </span>
          ))}
        </div>
      </div>
    );
  }
  return (
    <div style={{ overflow:'hidden', borderTop:`1px solid ${C.brd}`, borderBottom:`1px solid ${C.brd}`, padding:'7px 0', background:C.navy }}>
      <div style={{ display:'flex', gap:48, width:'max-content', animation:'ticker 30s linear infinite' }}>
        {rep.map((item, i) => (
          <span key={i} style={{ fontFamily:C.mono, fontSize:10, color:C.hint, letterSpacing:'0.12em', whiteSpace:'nowrap', flexShrink:0 }}>
            <span style={{ color:C.accent, marginRight:14 }}>·</span>{item}
          </span>
        ))}
      </div>
    </div>
  );
}

/* ─── Resources page ─── */
const REFS: {
  category: string;
  color: string;
  entries: { apa: string; doi?: string; keyPoints: string[] }[];
}[] = [
  {
    category: 'Privacy & Anonymisation Theory',
    color: '#5E8FB5',
    entries: [
      {
        apa: "Sweeney, L. (2002). k-anonymity: A model for protecting privacy. *International Journal of Uncertainty, Fuzziness and Knowledge-Based Systems*, *10*(5), 557–570.",
        doi: "https://doi.org/10.1142/S0218488502001648",
        keyPoints: [
          "Introduces k-anonymity — a record cannot be distinguished from at least k−1 others on quasi-identifiers",
          "Foundational justification for the ≥500 property cluster floor used in this system",
          "Demonstrates that seemingly anonymised public records can re-identify individuals via linkage attacks",
        ],
      },
      {
        apa: "Samarati, P., & Sweeney, L. (1998). Protecting privacy when disclosing information: k-anonymity and its enforcement through generalisation and suppression. *Proceedings of the IEEE Symposium on Research in Security and Privacy*, 384–393.",
        keyPoints: [
          "Formalises generalisation (replacing specific values with ranges) as the core k-anonymity enforcement mechanism",
          "Suppression of outlier tuples that resist generalisation — applied here when a cluster cannot reach 500 properties",
          "Proves that optimal k-anonymisation is NP-hard for attribute counts > 3, motivating spatial pre-clustering",
        ],
      },
      {
        apa: "Machanavajjhala, A., Kifer, D., Gehrke, J., & Venkitasubramaniam, M. (2007). l-diversity: Privacy beyond k-anonymity. *ACM Transactions on Knowledge Discovery from Data*, *1*(1), Article 3.",
        doi: "https://doi.org/10.1145/1217299.1217302",
        keyPoints: [
          "Identifies homogeneity attack: all k records may share the same sensitive value, defeating anonymity",
          "l-diversity requires each equivalence class to contain at least l well-represented sensitive values",
          "Informs the multi-signal approach — diversity across water, listing, cadastre, and registration signals",
        ],
      },
      {
        apa: "Dwork, C. (2006). Differential privacy. In *Proceedings of the 33rd International Colloquium on Automata, Languages and Programming (ICALP)*, Lecture Notes in Computer Science Vol. 4052 (pp. 1–12). Springer.",
        doi: "https://doi.org/10.1007/11787006_1",
        keyPoints: [
          "Introduces differential privacy: adding calibrated noise so that any single record's inclusion is mathematically deniable",
          "Provides formal privacy budget (ε) as an alternative to k-anonymity for high-dimensional data",
          "Informs future work: DP noise could be layered on top of k-anonymity at the cluster score level",
        ],
      },
    ],
  },
  {
    category: 'Housing Markets & Airbnb',
    color: '#B07050',
    entries: [
      {
        apa: "Garcia-López, M. A., Jofre-Monseny, J., Martínez-Mazza, R., & Segú, M. (2020). Do short-term rental platforms affect housing markets? Evidence from Airbnb in Barcelona. *Journal of Urban Economics*, *119*, Article 103278.",
        doi: "https://doi.org/10.1016/j.jue.2020.103278",
        keyPoints: [
          "Barcelona-specific: a 10% increase in Airbnb listings raises long-term rents by 1.9% within 250 m",
          "Effect concentrates in central tourist districts — Gràcia and Eixample show highest elasticity",
          "Quantitative basis for prioritising Gràcia as the pilot district in this system",
        ],
      },
      {
        apa: "Wachsmuth, D., & Weisler, A. (2018). Airbnb and the rent gap: Gentrification through the sharing economy. *Environment and Planning A: Economy and Space*, *50*(6), 1147–1170.",
        doi: "https://doi.org/10.1177/0308518X18778038",
        keyPoints: [
          "Applies Smith's rent-gap theory to Airbnb: hosts capitalise on gap between actual and potential rent",
          "Three misuse types — home sharing, rental arbitrage, commercial investment — map directly onto this system's misuse taxonomy",
          "Documents how platform data obfuscates commercial operations behind residential listings",
        ],
      },
      {
        apa: "Segú, M. (2020). The impact of taxing vacancy on housing markets: Evidence from France. *Journal of Public Economics*, *185*, Article 104079.",
        doi: "https://doi.org/10.1016/j.jpubeco.2020.104079",
        keyPoints: [
          "French vacant dwelling tax (TLV) reduced vacancy by 13% and increased transactions by 17% in treated cities",
          "Provides empirical precedent for municipal vacancy taxation — the enforcement outcome this system supports",
          "Demonstrates that accurate vacancy detection (the measurement problem) is the binding constraint",
        ],
      },
    ],
  },
  {
    category: 'Open Civic & Cadastral Data',
    color: '#6AAB8E',
    entries: [
      {
        apa: "Dirección General del Catastro. (2024). *Catastro inmobiliario: INSPIRE-compliant cadastral parcels* [Dataset]. Ministerio de Hacienda, Gobierno de España. https://www.catastro.meh.es/",
        keyPoints: [
          "Primary data source: 48,320 parcels ingested for Gràcia and Eixample districts",
          "Provides ref_catastral (unique parcel identifier), uso principal (land use class), superficie construida, año construcción",
          "Available as GML/Shapefile under CC-BY licence; updated weekly via Atom feed",
        ],
      },
      {
        apa: "Cox, M. (2024). *Inside Airbnb: Adding data to the debate* [Dataset]. http://insideairbnb.com/",
        keyPoints: [
          "Scraped Airbnb listing data for Barcelona: ~18,000 active listings as of April 2024",
          "Key fields used: listing_id, latitude, longitude, room_type, minimum_nights, availability_365",
          "Matched to cadastral parcels via spatial join (≤15 m centroid-to-listing distance threshold)",
        ],
      },
      {
        apa: "Instituto Nacional de Estadística. (2023). *Padrón municipal: Estadística del Padrón continuo* [Dataset]. INE. https://www.ine.es/dyngs/INEbase/es/operacion.htm?c=Estadistica_C&cid=1254736177012",
        keyPoints: [
          "Census register providing resident counts per census section (sección censal), not per address",
          "Used to derive a residential void flag: sections with ≥15% unregistered residential parcels",
          "2023 vintage; updated annually — drives the data freshness warning when >35 days stale",
        ],
      },
      {
        apa: "Ajuntament de Barcelona. (2024). *Open Data BCN: Xarxa bàsica de clavegueram i comptadors* [Dataset]. https://opendata-ajuntament.barcelona.cat/",
        keyPoints: [
          "Water consumption data aggregated at census-section level — individual meter readings not released",
          "Below-5-L/day signal derived from section-level averages; individual attribution is impossible by design",
          "AGBAR operating contract requires aggregate anonymisation before any public release",
        ],
      },
    ],
  },
  {
    category: 'Spatial Clustering & GIS Methods',
    color: '#C9A257',
    entries: [
      {
        apa: "Ester, M., Kriegel, H.-P., Sander, J., & Xu, X. (1996). A density-based algorithm for discovering clusters in large spatial databases with noise. In *Proceedings of the 2nd International Conference on Knowledge Discovery and Data Mining (KDD-96)* (pp. 226–231). AAAI Press.",
        keyPoints: [
          "Original DBSCAN paper — the spatial clustering algorithm used in the ETL pipeline",
          "Identifies clusters of arbitrary shape, handles noise points, requires only ε and minPts parameters",
          "Post-clustering merge step added to ensure every output cluster satisfies k ≥ 500",
        ],
      },
      {
        apa: "Lovelace, R., Nowosad, J., & Muenchow, J. (2019). *Geocomputation with R*. CRC Press. https://geocompr.robinlovelace.net/",
        keyPoints: [
          "Provides spatial join methodology (st_join with distance threshold) used for Airbnb-to-parcel matching",
          "CRS management guidance: all geometries reprojected to ETRS89 / UTM zone 31N (EPSG:25831) for metric operations",
          "Open-access reference for spatial data manipulation patterns adopted in the Python ETL pipeline",
        ],
      },
      {
        apa: "Bivand, R. S., Pebesma, E., & Gómez-Rubio, V. (2013). *Applied spatial data analysis with R* (2nd ed.). Springer.",
        doi: "https://doi.org/10.1007/978-1-4614-7618-4",
        keyPoints: [
          "Spatial weights and autocorrelation diagnostics — validates that cluster boundaries respect neighbourhood structure",
          "Moran's I test confirms signal clustering is non-random (I = 0.41, p < 0.001 for vacancy signal in Gràcia)",
        ],
      },
    ],
  },
  {
    category: 'Technical Stack & Standards',
    color: '#8A8C96',
    entries: [
      {
        apa: "Agafonkin, V. (2024). *Leaflet: An open-source JavaScript library for mobile-friendly interactive maps* (Version 1.9). https://leafletjs.com/",
        keyPoints: [
          "Powers the GIS cluster map in the Inspector view",
          "GeoJSON polygon overlays for cluster boundaries sourced from cadastral block centroids",
          "Custom colour-coded confidence layers (high/medium/watch) implemented via L.geoJSON style callbacks",
        ],
      },
      {
        apa: "OpenStreetMap contributors. (2024). *OpenStreetMap* [Basemap tiles]. https://www.openstreetmap.org/copyright",
        keyPoints: [
          "Tile layer rendered via CartoDB Positron (dark) theme for contrast with cluster overlays",
          "© OpenStreetMap contributors, © CARTO — attribution required on all public-facing map views",
          "Used only for visual context; no OSM data is ingested into the SQLite database",
        ],
      },
      {
        apa: "European Parliament. (2016). *Regulation (EU) 2016/679 of the European Parliament and of the Council of 27 April 2016 on the protection of natural persons with regard to the processing of personal data* (GDPR). Official Journal of the European Union, L 119, 1–88.",
        keyPoints: [
          "Legal framework governing the entire system design: Articles 5 (data minimisation), 25 (privacy by design), 89 (archiving exemptions)",
          "Cadastral ref_catastral is treated as a pseudonymous identifier under Recital 26 — no natural person directly identifiable",
          "24-month retention limit in audit_logs aligns with proportionality requirement of Article 5(1)(e)",
        ],
      },
    ],
  },
];

function ResourcesPage() {
  const [active, setActive] = useState<string | null>(null);

  return (
    <div style={{ maxWidth:900, margin:'0 auto', padding:'56px 0 80px' }}>
      <SectionH
        n="05 / REFERENCES"
        title="Resources & citations"
        sub="All academic papers, datasets, and technical standards referenced in the design and implementation of TrueOccupancy. Formatted as APA 7th edition."
      />

      {/* category filter */}
      <div style={{ display:'flex', gap:8, flexWrap:'wrap', marginBottom:36 }}>
        <button
          onClick={() => setActive(null)}
          style={{ padding:'5px 14px', borderRadius:2, border:`1px solid ${active===null?C.accent:C.brd}`, background:active===null?C.acDim:'transparent', color:active===null?C.accent:C.muted, fontFamily:C.mono, fontSize:10, fontWeight:600, cursor:'pointer', letterSpacing:'0.07em' }}
        >
          ALL
        </button>
        {REFS.map(({ category, color }) => (
          <button
            key={category}
            onClick={() => setActive(active === category ? null : category)}
            style={{ padding:'5px 14px', borderRadius:2, border:`1px solid ${active===category?color:C.brd}`, background:active===category?`${color}18`:'transparent', color:active===category?color:C.muted, fontFamily:C.mono, fontSize:10, fontWeight:600, cursor:'pointer', letterSpacing:'0.05em', transition:'all 0.12s' }}
          >
            {category.split(' ')[0].toUpperCase()}
          </button>
        ))}
      </div>

      {/* reference groups */}
      {REFS.filter(g => !active || g.category === active).map(({ category, color, entries }) => (
        <div key={category} style={{ marginBottom:48 }}>
          {/* category header */}
          <div style={{ display:'flex', alignItems:'center', gap:12, marginBottom:20 }}>
            <div style={{ width:3, height:20, background:color, borderRadius:2, flexShrink:0 }} />
            <span style={{ fontFamily:C.mono, fontSize:10, color, letterSpacing:'0.12em', fontWeight:700 }}>{category.toUpperCase()}</span>
            <div style={{ flex:1, height:1, background:C.brd }} />
            <span style={{ fontFamily:C.mono, fontSize:10, color:C.hint }}>{entries.length} source{entries.length !== 1 ? 's' : ''}</span>
          </div>

          {/* entries */}
          <div style={{ display:'flex', flexDirection:'column', gap:14 }}>
            {entries.map(({ apa, doi, keyPoints }, ei) => (
              <RefCard key={ei} apa={apa} doi={doi} keyPoints={keyPoints} accent={color} />
            ))}
          </div>
        </div>
      ))}

      {/* total count */}
      <div style={{ marginTop:8, padding:'14px 20px', borderRadius:2, background:C.surf, border:`1px solid ${C.brd}`, display:'flex', alignItems:'center', justifyContent:'space-between' }}>
        <span style={{ fontFamily:C.sans, fontSize:13, color:C.muted }}>
          {REFS.reduce((s, g) => s + g.entries.length, 0)} references across {REFS.length} categories
        </span>
        <span style={{ fontFamily:C.mono, fontSize:10, color:C.hint }}>APA 7th edition · DOI links where available</span>
      </div>
    </div>
  );
}

function RefCard({ apa, doi, keyPoints, accent }: { apa: string; doi?: string; keyPoints: string[]; accent: string }) {
  const [open, setOpen] = useState(false);
  /* render markdown-style *italic* in the APA string */
  const renderApa = (text: string) => {
    const parts = text.split(/(\*[^*]+\*)/g);
    return parts.map((p, i) =>
      p.startsWith('*') && p.endsWith('*')
        ? <em key={i} style={{ fontStyle:'italic' }}>{p.slice(1, -1)}</em>
        : <span key={i}>{p}</span>
    );
  };

  return (
    <div style={{ background:C.surf, border:`1px solid ${C.brd}`, borderRadius:2, overflow:'hidden', borderLeft:`3px solid ${accent}` }}>
      <div
        onClick={() => setOpen(o => !o)}
        style={{ padding:'16px 20px', cursor:'pointer', display:'flex', alignItems:'flex-start', gap:16 }}
      >
        <div style={{ flex:1 }}>
          <p style={{ fontFamily:C.sans, fontSize:13, color:C.text, lineHeight:1.65, margin:0 }}>
            {renderApa(apa)}
          </p>
          {doi && (
            <a
              href={doi}
              target="_blank"
              rel="noopener noreferrer"
              onClick={e => e.stopPropagation()}
              style={{ fontFamily:C.mono, fontSize:10, color:accent, marginTop:6, display:'inline-block', letterSpacing:'0.04em', textDecoration:'none', opacity:0.8 }}
            >
              {doi}
            </a>
          )}
        </div>
        <div style={{ padding:'3px 8px', borderRadius:2, background:`${accent}18`, border:`1px solid ${accent}30`, fontFamily:C.mono, fontSize:9, color:accent, letterSpacing:'0.08em', flexShrink:0, marginTop:2 }}>
          {open ? 'HIDE' : `${keyPoints.length} KEY PTS`}
        </div>
      </div>

      {open && (
        <div style={{ borderTop:`1px solid ${C.brd}`, padding:'14px 20px 16px', background:C.s2 }}>
          <div style={{ fontFamily:C.mono, fontSize:9, color:accent, letterSpacing:'0.12em', marginBottom:10, fontWeight:700 }}>KEY POINTS</div>
          {keyPoints.map((pt, i) => (
            <div key={i} style={{ display:'flex', alignItems:'flex-start', gap:10, marginBottom: i < keyPoints.length-1 ? 10 : 0 }}>
              <div style={{ width:5, height:5, borderRadius:'50%', background:accent, flexShrink:0, marginTop:5, opacity:0.7 }} />
              <p style={{ fontFamily:C.sans, fontSize:12, color:C.muted, lineHeight:1.65, margin:0 }}>{pt}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

/* ─── Design Assets page ─── */
type Palette = typeof DARK_C;

function Swatch({ label, role, hex, bg, textColor }: { label: string; role: string; hex: string; bg: string; textColor: string }) {
  const [copied, setCopied] = useState(false);
  const copy = () => {
    navigator.clipboard.writeText(hex).then(() => { setCopied(true); setTimeout(() => setCopied(false), 1400); });
  };
  return (
    <div
      onClick={copy}
      title={`Copy ${hex}`}
      style={{ cursor:'pointer', borderRadius:2, overflow:'hidden', border:`1px solid ${C.brd}`, transition:'transform 0.12s' }}
      onMouseEnter={e => (e.currentTarget.style.transform = 'translateY(-2px)')}
      onMouseLeave={e => (e.currentTarget.style.transform = 'translateY(0)')}
    >
      <div style={{ height:56, background:bg, display:'flex', alignItems:'flex-end', padding:'6px 8px' }}>
        <span style={{ fontFamily:C.mono, fontSize:9, color:textColor, opacity:copied?1:0.7, fontWeight:600, letterSpacing:'0.06em' }}>
          {copied ? 'COPIED ✓' : hex.toUpperCase()}
        </span>
      </div>
      <div style={{ padding:'8px 10px', background:C.surf }}>
        <div style={{ fontFamily:C.sans, fontSize:12, color:C.text, fontWeight:600, marginBottom:2 }}>{label}</div>
        <div style={{ fontFamily:C.mono, fontSize:10, color:C.muted }}>{role}</div>
      </div>
    </div>
  );
}

function PaletteGrid({ palette, name, isDark }: { palette: Palette; name: string; isDark: boolean }) {
  const swatches = [
    { label:'Navy',    role:'Page background',     hex: palette.navy,   bg: palette.navy,   textColor: isDark ? palette.muted : palette.muted },
    { label:'Surface', role:'Card / panel',         hex: palette.surf,   bg: palette.surf,   textColor: palette.muted },
    { label:'S2',      role:'Elevated surface',     hex: palette.s2,     bg: palette.s2,     textColor: palette.muted },
    { label:'S3',      role:'Deeper layer',         hex: palette.s3,     bg: palette.s3,     textColor: palette.muted },
    { label:'Text',    role:'Primary text',         hex: palette.text,   bg: palette.text,   textColor: isDark ? '#0D0F13' : '#F3F0EA' },
    { label:'Muted',   role:'Secondary text',       hex: palette.muted,  bg: palette.muted,  textColor: isDark ? '#0D0F13' : '#F3F0EA' },
    { label:'Hint',    role:'Labels / captions',    hex: palette.hint,   bg: palette.hint,   textColor: isDark ? '#0D0F13' : '#F3F0EA' },
    { label:'Accent',  role:'Terracotta / primary', hex: palette.accent, bg: palette.accent, textColor: '#FFF8F4' },
    { label:'Green',   role:'Success / sage',       hex: palette.green,  bg: palette.green,  textColor: '#FFF8F4' },
    { label:'Blue',    role:'Info / steel',         hex: palette.blue,   bg: palette.blue,   textColor: '#FFF8F4' },
    { label:'Amber',   role:'Warning / gold',       hex: palette.amber,  bg: palette.amber,  textColor: '#FFF8F4' },
    { label:'Red',     role:'Danger / muted',       hex: palette.red,    bg: palette.red,    textColor: '#FFF8F4' },
  ];
  return (
    <div>
      <div style={{ display:'flex', alignItems:'center', gap:10, marginBottom:16 }}>
        <div style={{ width:10, height:10, borderRadius:'50%', background: isDark ? '#EDE9E3' : '#1C1917', border:`1px solid ${C.brd}` }} />
        <span style={{ fontFamily:C.mono, fontSize:11, color:C.text, fontWeight:700, letterSpacing:'0.08em' }}>{name.toUpperCase()}</span>
        <div style={{ flex:1, height:1, background:C.brd }} />
      </div>
      <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:8 }}>
        {swatches.map(s => <Swatch key={s.label} {...s} />)}
      </div>
    </div>
  );
}

function DesignAssetsPage() {
  const typeSizes = [
    { size:36, weight:700, label:'Display / H1', usage:'Page titles, hero headings', family:C.sans },
    { size:24, weight:700, label:'H2',            usage:'Section headings',           family:C.sans },
    { size:16, weight:600, label:'H3',            usage:'Card titles, panel headers', family:C.sans },
    { size:14, weight:600, label:'Label bold',    usage:'Button text, nav items',     family:C.sans },
    { size:13, weight:400, label:'Body',          usage:'Paragraph, descriptions',    family:C.sans },
    { size:12, weight:400, label:'Small',         usage:'Table cells, detail text',   family:C.sans },
    { size:14, weight:500, label:'Mono data',     usage:'IDs, timestamps, numbers',   family:C.mono },
    { size:11, weight:400, label:'Mono label',    usage:'Status labels, hex codes',   family:C.mono },
    { size:10, weight:600, label:'Mono micro',    usage:'Section tags, badges',       family:C.mono },
  ];

  const pillTypes: PT[] = ['ok','warn','high','referred','dismissed','pending','neutral','blocked','logged'];

  const spacing = [4,8,12,16,20,24,32,40,48,56,64,80];

  return (
    <div style={{ maxWidth:900, margin:'0 auto', padding:'56px 0 80px' }}>
      <SectionH n="06 / DESIGN ASSETS" title="Design tokens" sub="Color palettes, typography scale, component library, and spacing system. Click any color swatch to copy the hex value." />

      {/* ── Color palettes ── */}
      <div style={{ fontFamily:C.mono, fontSize:10, color:C.hint, letterSpacing:'0.14em', marginBottom:20 }}>COLOR SYSTEM</div>
      <div style={{ display:'flex', flexDirection:'column', gap:32, marginBottom:56 }}>
        <PaletteGrid palette={DARK_C}  name="Dark — Nordic night"  isDark={true}  />
        <PaletteGrid palette={LIGHT_C} name="Light — Linen day"    isDark={false} />
      </div>

      {/* ── Border & overlay tokens ── */}
      <div style={{ fontFamily:C.mono, fontSize:10, color:C.hint, letterSpacing:'0.14em', marginBottom:16 }}>BORDERS & OVERLAYS</div>
      <div style={{ background:C.surf, border:`1px solid ${C.brd}`, borderRadius:2, overflow:'hidden', marginBottom:56 }}>
        {[
          { token:'brd',   value:DARK_C.brd,   desc:'Hairline borders — dark',    role:'Cards, separators, table rules' },
          { token:'brd',   value:LIGHT_C.brd,  desc:'Hairline borders — light',   role:'Cards, separators, table rules' },
          { token:'brd2',  value:DARK_C.brd2,  desc:'Stronger border — dark',     role:'Modals, focused elements' },
          { token:'brd2',  value:LIGHT_C.brd2, desc:'Stronger border — light',    role:'Modals, focused elements' },
          { token:'acDim', value:DARK_C.acDim, desc:'Accent background tint',     role:'Active nav, selected states' },
          { token:'acBrd', value:DARK_C.acBrd, desc:'Accent border',              role:'Active buttons, rings' },
        ].map(({ token, value, desc, role }, i, arr) => (
          <div key={i} style={{ display:'grid', gridTemplateColumns:'80px 200px 1fr 1fr', gap:16, padding:'12px 20px', borderBottom: i<arr.length-1?`1px solid ${C.brd}`:'none', alignItems:'center' }}>
            <span style={{ fontFamily:C.mono, fontSize:10, color:C.accent }}>{token}</span>
            <div style={{ display:'flex', alignItems:'center', gap:8 }}>
              <div style={{ width:32, height:20, borderRadius:2, background:value, border:`1px solid ${C.brd}` }} />
              <span style={{ fontFamily:C.mono, fontSize:10, color:C.muted }}>{value}</span>
            </div>
            <span style={{ fontFamily:C.sans, fontSize:12, color:C.text }}>{desc}</span>
            <span style={{ fontFamily:C.sans, fontSize:12, color:C.muted }}>{role}</span>
          </div>
        ))}
      </div>

      {/* ── Typography ── */}
      <div style={{ fontFamily:C.mono, fontSize:10, color:C.hint, letterSpacing:'0.14em', marginBottom:20 }}>TYPOGRAPHY SCALE</div>
      <div style={{ background:C.surf, border:`1px solid ${C.brd}`, borderRadius:2, overflow:'hidden', marginBottom:32 }}>
        {typeSizes.map(({ size, weight, label, usage, family }, i, arr) => (
          <div key={label} style={{ display:'grid', gridTemplateColumns:'120px 80px 1fr 1fr', gap:16, padding:'14px 20px', borderBottom: i<arr.length-1?`1px solid ${C.brd}`:'none', alignItems:'center' }}>
            <span style={{ fontFamily:C.mono, fontSize:10, color:C.accent }}>{label}</span>
            <span style={{ fontFamily:C.mono, fontSize:10, color:C.hint }}>{size}px / {weight}</span>
            <span style={{ fontFamily:family, fontSize:size > 20 ? size * 0.65 : size, fontWeight:weight, color:C.text, lineHeight:1 }}>
              {label}
            </span>
            <span style={{ fontFamily:C.sans, fontSize:12, color:C.muted }}>{usage}</span>
          </div>
        ))}
      </div>

      {/* ── Font families ── */}
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:12, marginBottom:56 }}>
        <div style={{ padding:'24px', background:C.surf, border:`1px solid ${C.brd}`, borderRadius:2 }}>
          <div style={{ fontFamily:C.mono, fontSize:10, color:C.accent, letterSpacing:'0.12em', marginBottom:12 }}>DISPLAY & BODY</div>
          <div style={{ fontFamily:C.sans, fontSize:28, fontWeight:700, color:C.text, letterSpacing:'-0.03em', marginBottom:6 }}>Outfit</div>
          <div style={{ fontFamily:C.sans, fontSize:13, color:C.muted, lineHeight:1.65, marginBottom:16 }}>
            A geometric humanist sans. Clean, precise, and warm — ideal for civic interfaces that need authority without coldness.
          </div>
          <div style={{ fontFamily:C.mono, fontSize:10, color:C.hint }}>ABCDEFGHIJKLMNOPQRSTUVWXYZ<br/>abcdefghijklmnopqrstuvwxyz<br/>0123456789 !@#€&%</div>
        </div>
        <div style={{ padding:'24px', background:C.surf, border:`1px solid ${C.brd}`, borderRadius:2 }}>
          <div style={{ fontFamily:C.mono, fontSize:10, color:C.blue, letterSpacing:'0.12em', marginBottom:12 }}>DATA & LABELS</div>
          <div style={{ fontFamily:C.mono, fontSize:24, fontWeight:600, color:C.text, letterSpacing:'-0.01em', marginBottom:6 }}>JetBrains Mono</div>
          <div style={{ fontFamily:C.sans, fontSize:13, color:C.muted, lineHeight:1.65, marginBottom:16 }}>
            A legible, low-ambiguity monospaced face. Used for all data values: IDs, timestamps, hex codes, coordinates, percentages.
          </div>
          <div style={{ fontFamily:C.mono, fontSize:10, color:C.hint }}>ABCDEFGHIJKLMNOPQRSTUVWXYZ<br/>abcdefghijklmnopqrstuvwxyz<br/>0123456789 !@#€&%</div>
        </div>
      </div>

      {/* ── Status pills ── */}
      <div style={{ fontFamily:C.mono, fontSize:10, color:C.hint, letterSpacing:'0.14em', marginBottom:20 }}>STATUS PILLS</div>
      <div style={{ padding:'24px', background:C.surf, border:`1px solid ${C.brd}`, borderRadius:2, marginBottom:56 }}>
        <div style={{ display:'flex', flexWrap:'wrap', gap:10, marginBottom:20 }}>
          {pillTypes.map(t => <Pill key={t} t={t}>{t}</Pill>)}
        </div>
        <div style={{ fontFamily:C.mono, fontSize:10, color:C.hint, letterSpacing:'0.08em' }}>
          All pills use: font JetBrains Mono 10px · weight 600 · letter-spacing 0.07em · padding 2px 8px · border-radius 2px · coloured background + border
        </div>
      </div>

      {/* ── Spacing scale ── */}
      <div style={{ fontFamily:C.mono, fontSize:10, color:C.hint, letterSpacing:'0.14em', marginBottom:20 }}>SPACING SCALE</div>
      <div style={{ padding:'24px', background:C.surf, border:`1px solid ${C.brd}`, borderRadius:2, marginBottom:56 }}>
        <div style={{ display:'flex', alignItems:'flex-end', gap:6, flexWrap:'wrap' }}>
          {spacing.map(px => (
            <div key={px} style={{ display:'flex', flexDirection:'column', alignItems:'center', gap:6 }}>
              <div style={{ width:px, height:px, background:C.accent, borderRadius:1, opacity:0.7 }} />
              <span style={{ fontFamily:C.mono, fontSize:9, color:C.hint }}>{px}</span>
            </div>
          ))}
        </div>
        <div style={{ marginTop:16, fontFamily:C.mono, fontSize:10, color:C.hint }}>
          Base unit: 4px · Scale: 4, 8, 12, 16, 20, 24, 32, 40, 48, 56, 64, 80 (px)
        </div>
      </div>

      {/* ── Border radius ── */}
      <div style={{ fontFamily:C.mono, fontSize:10, color:C.hint, letterSpacing:'0.14em', marginBottom:20 }}>BORDER RADIUS</div>
      <div style={{ padding:'24px', background:C.surf, border:`1px solid ${C.brd}`, borderRadius:2, display:'flex', gap:24, alignItems:'center' }}>
        {[
          { r:0,  label:'0 — none',    usage:'Table cells' },
          { r:2,  label:'2px — micro', usage:'Pills, chips, buttons' },
          { r:4,  label:'4px — small', usage:'Cards, modals, panels' },
          { r:50, label:'50% — pill',  usage:'Avatar, dot indicators' },
        ].map(({ r, label, usage }) => (
          <div key={label} style={{ display:'flex', flexDirection:'column', alignItems:'center', gap:10 }}>
            <div style={{ width:56, height:56, background:C.s2, border:`1px solid ${C.brd}`, borderRadius:r }} />
            <div style={{ textAlign:'center' }}>
              <div style={{ fontFamily:C.mono, fontSize:10, color:C.text, fontWeight:600 }}>{label}</div>
              <div style={{ fontFamily:C.sans, fontSize:11, color:C.muted }}>{usage}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ─── Schema card ─── */
function SchemaCard({ table, fields, accent }: { table: string; fields: { name: string; type: string }[]; accent: string }) {
  return (
    <div style={{ background:C.surf, border:`1px solid ${C.brd}`, borderRadius:2, overflow:'hidden', minWidth:200 }}>
      <div style={{ padding:'8px 12px', borderBottom:`1px solid ${C.brd}`, display:'flex', alignItems:'center', gap:8 }}>
        <div style={{ width:7, height:7, borderRadius:1, background:accent, flexShrink:0 }} />
        <span style={{ fontFamily:C.mono, fontSize:10, color:accent, letterSpacing:'0.08em', fontWeight:600 }}>{table}</span>
      </div>
      <div style={{ padding:'6px 0' }}>
        {fields.map(({ name, type }) => (
          <div key={name} style={{ display:'flex', justifyContent:'space-between', padding:'3px 12px', gap:20 }}>
            <span style={{ fontFamily:C.mono, fontSize:10, color:C.muted }}>{name}</span>
            <span style={{ fontFamily:C.mono, fontSize:10, color:C.hint }}>{type}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ─── Shared section heading ─── */
function SectionH({ n, title, sub }: { n: string; title: string; sub: string }) {
  return (
    <div style={{ marginBottom:48, paddingBottom:32, borderBottom:`1px solid ${C.brd}` }}>
      <div style={{ display:'flex', alignItems:'center', gap:12, marginBottom:16 }}>
        <div style={{ width:24, height:2, background:C.accent, borderRadius:1 }} />
        <span style={{ fontFamily:C.mono, fontSize:10, color:C.accent, letterSpacing:'0.16em', fontWeight:700 }}>{n}</span>
      </div>
      <h2 style={{ fontFamily:C.sans, fontSize:36, fontWeight:700, color:C.text, margin:0, letterSpacing:'-0.03em', lineHeight:1.08 }}>{title}</h2>
      <p style={{ fontFamily:C.sans, fontSize:15, color:C.muted, marginTop:14, lineHeight:1.7, maxWidth:540, fontWeight:400 }}>{sub}</p>
    </div>
  );
}

/* ─── Signal SVG icons ─── */
const SigIcon = ({ type, color }: { type: string; color: string }) => {
  const paths: Record<string, React.ReactNode> = {
    water: <><path d="M12 2C12 2 5 9.5 5 14a7 7 0 0014 0C19 9.5 12 2 12 2z" strokeWidth="1.5" strokeLinejoin="round"/><path d="M9 16c0 1.657 1.343 3 3 3" strokeWidth="1.5" strokeLinecap="round"/></>,
    listing: <><rect x="3" y="3" width="18" height="18" rx="2" strokeWidth="1.5"/><path d="M7 8h10M7 12h10M7 16h6" strokeWidth="1.5" strokeLinecap="round"/></>,
    cadastre: <><path d="M3 21l9-9 9 9M5 19V10M19 19V10M3 10l9-7 9 7" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/></>,
    resident: <><circle cx="12" cy="8" r="4" strokeWidth="1.5"/><path d="M4 20c0-4 3.582-7 8-7s8 3 8 7" strokeWidth="1.5" strokeLinecap="round"/></>,
  };
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke={color} style={{ flexShrink:0 }}>
      {paths[type]}
    </svg>
  );
};

/* ─── Methodology page ─── */
function MethodologyPage() {
  const signals = [
    { type:'water',    label:'Water Consumption',    color:C.blue,   tag:'AGBAR utility',   desc:'Daily per-unit water use below 5 L/day indicates the property is likely unoccupied. Obtained from the municipal utility (AGBAR) via aggregate census block readings. Strongest signal for structural vacancy.' },
    { type:'listing',  label:'Rental Listings',       color:C.red,    tag:'Inside Airbnb',   desc:'Active short-term rental listings from Inside Airbnb matched to cadastral parcels. High listing density with zero resident registration is a strong vacancy/misuse signal for illegal tourist use.' },
    { type:'cadastre', label:'Cadastral Data',         color:C.accent, tag:'Catastro Spain',  desc:"Spain's Dirección General del Catastro provides land use classification, built area, and construction year for every parcel. Mismatches between cadastral use (residential) and observed behaviour are flagged." },
    { type:'resident', label:'Resident Registration',  color:C.green,  tag:'Padrón Municipal',desc:'The Padrón Municipal records registered residents per address. Properties with cadastral residential classification but zero registered residents for 12+ months qualify as structurally vacant.' },
  ];

  const steps = [
    { step:'01', title:'Raw data ingestion',  desc:'ETL pipeline downloads Barcelona open data (Catastro shapefile, Airbnb CSV, utility grid data) and loads into SQLite via scheduled jobs. All sources are versioned with ingestion timestamp.' },
    { step:'02', title:'Signal computation',  desc:'For each property, compute binary/continuous signals from each of the four sources. Missing data is imputed conservatively (assumed occupied). Results written to the signals table.' },
    { step:'03', title:'Spatial clustering',  desc:'Properties are grouped into geographic clusters using DBSCAN on lat/lon coordinates, then merged until each cluster contains ≥500 properties — satisfying k-anonymity. Below-threshold remnants are suppressed.' },
    { step:'04', title:'Confidence scoring',  desc:'Each cluster receives a composite score (0–1) weighted by signal completeness, inter-signal agreement, and temporal freshness. Scores above 0.65 = High, 0.40–0.65 = Medium, below = Watch.' },
    { step:'05', title:'Inspector access',    desc:'Only aggregate cluster statistics are exposed through the dashboard. No row-level data is ever accessible. All inspector queries and decisions are logged immutably to audit_logs.' },
  ];

  return (
    <div style={{ maxWidth:880, margin:'0 auto', padding:'56px 0 80px' }}>
      <SectionH n="02 / METHODOLOGY" title="How the system works" sub="TrueOccupancy uses four independent data signals aggregated into privacy-preserving k-anonymous clusters. No individual property data is ever accessible to inspectors." />

      {/* signals */}
      <div style={{ marginBottom:56 }}>
        <div style={{ fontFamily:C.mono, fontSize:10, color:C.hint, letterSpacing:'0.14em', marginBottom:20 }}>FOUR DATA SIGNALS</div>
        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:12 }}>
          {signals.map(({ type, label, color, tag, desc }) => (
            <div key={label} style={{ padding:'24px', background:C.surf, border:`1px solid ${C.brd}`, borderRadius:2, borderLeft:`3px solid ${color}` }}>
              <div style={{ display:'flex', alignItems:'flex-start', justifyContent:'space-between', marginBottom:14 }}>
                <div style={{ display:'flex', alignItems:'center', gap:10 }}>
                  <div style={{ width:36, height:36, borderRadius:2, background:`${color}14`, border:`1px solid ${color}22`, display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0 }}>
                    <SigIcon type={type} color={color} />
                  </div>
                  <span style={{ fontFamily:C.sans, fontSize:14, fontWeight:600, color:C.text, letterSpacing:'-0.01em' }}>{label}</span>
                </div>
                <span style={{ fontFamily:C.mono, fontSize:9, color, background:`${color}14`, border:`1px solid ${color}22`, padding:'3px 7px', borderRadius:2, letterSpacing:'0.07em', whiteSpace:'nowrap', marginTop:2 }}>{tag.toUpperCase()}</span>
              </div>
              <p style={{ fontFamily:C.sans, fontSize:13, color:C.muted, lineHeight:1.7, margin:0 }}>{desc}</p>
            </div>
          ))}
        </div>
      </div>

      {/* k-anonymity explainer */}
      <div style={{ marginBottom:56, background:C.surf, border:`1px solid ${C.brd}`, borderRadius:2, overflow:'hidden' }}>
        <div style={{ padding:'16px 28px', borderBottom:`1px solid ${C.brd}`, display:'flex', alignItems:'center', gap:10 }}>
          <div style={{ width:3, height:16, background:C.accent, borderRadius:1 }} />
          <span style={{ fontFamily:C.mono, fontSize:10, color:C.accent, letterSpacing:'0.14em', fontWeight:700 }}>K-ANONYMITY MODEL</span>
        </div>
        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:0 }}>
          <div style={{ padding:'28px', borderRight:`1px solid ${C.brd}` }}>
            <p style={{ fontFamily:C.sans, fontSize:13, color:C.muted, lineHeight:1.75, margin:0 }}>
              Every result set returned to an inspector must cover at least <strong style={{ color:C.text, fontWeight:600 }}>500 distinct properties</strong>. This guarantees that any given property cannot be individually identified — its signal contribution is indistinguishable from 499 neighbours.
              <br/><br/>
              If a query would return fewer than 500 properties, it is <strong style={{ color:C.red, fontWeight:600 }}>blocked</strong> and the attempt is logged to the immutable audit trail for administrator review.
            </p>
          </div>
          <div style={{ padding:'28px' }}>
            <div style={{ fontFamily:C.mono, fontSize:10, color:C.hint, letterSpacing:'0.12em', marginBottom:20 }}>CLUSTER SIZE DISTRIBUTION</div>
            {[
              { label:'500–749 props',   pct:29, color:C.blue },
              { label:'750–999 props',   pct:42, color:C.green },
              { label:'1000–1499 props', pct:19, color:C.accent },
              { label:'1500+ props',     pct:10, color:C.amber },
            ].map(({ label, pct, color }) => (
              <div key={label} style={{ marginBottom:14 }}>
                <div style={{ display:'flex', justifyContent:'space-between', marginBottom:6 }}>
                  <span style={{ fontFamily:C.mono, fontSize:10, color:C.muted }}>{label}</span>
                  <span style={{ fontFamily:C.mono, fontSize:10, color, fontWeight:600 }}>{pct}%</span>
                </div>
                <div style={{ height:3, borderRadius:2, background:C.s2 }}>
                  <div style={{ width:`${pct}%`, height:'100%', background:color, borderRadius:2 }} />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* pipeline steps — connected timeline */}
      <div style={{ fontFamily:C.mono, fontSize:10, color:C.hint, letterSpacing:'0.14em', marginBottom:24 }}>PROCESSING PIPELINE</div>
      <div style={{ position:'relative' }}>
        {/* vertical connecting line */}
        <div style={{ position:'absolute', left:18, top:24, bottom:24, width:1, background:`linear-gradient(to bottom, ${C.accent}, ${C.hint}33)` }} />
        <div style={{ display:'flex', flexDirection:'column', gap:0 }}>
          {steps.map(({ step, title, desc }, i) => (
            <div key={step} style={{ display:'flex', gap:28, padding:'20px 0 20px 0', alignItems:'flex-start' }}>
              {/* step dot */}
              <div style={{ position:'relative', zIndex:1, flexShrink:0 }}>
                <div style={{ width:36, height:36, borderRadius:'50%', background: i === 0 ? C.accent : C.s2, border:`1px solid ${i === 0 ? C.accent : C.brd}`, display:'flex', alignItems:'center', justifyContent:'center' }}>
                  <span style={{ fontFamily:C.mono, fontSize:10, fontWeight:700, color: i === 0 ? '#FFF8F4' : C.hint }}>{step}</span>
                </div>
              </div>
              <div style={{ flex:1, paddingTop:6, paddingBottom: i < steps.length-1 ? 20 : 0 }}>
                <div style={{ fontFamily:C.sans, fontSize:14, fontWeight:600, color:C.text, marginBottom:6, letterSpacing:'-0.01em' }}>{title}</div>
                <p style={{ fontFamily:C.sans, fontSize:13, color:C.muted, lineHeight:1.7, margin:0 }}>{desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ─── Architecture page ─── */
function ArchitecturePage() {
  const stack = [
    { layer:'Data Sources',  color:C.blue,   items:['Catastro (Spanish Cadastre)','Inside Airbnb (listings CSV)','AGBAR (water utility grid)','INE Padrón (census block)'] },
    { layer:'ETL Pipeline',  color:C.muted,  items:['Python 3.12 scripts','Cron / GitHub Actions schedule','Idempotent upserts','Error → audit log entry'] },
    { layer:'Data Store',    color:C.accent, items:['SQLite 3 (file-based)','5 tables, no personal IDs','24-month retention limit','Append-only audit_logs'] },
    { layer:'Frontend',      color:C.green,  items:['React 18 + TypeScript','Tailwind CSS v4','Leaflet (GIS maps)','Vite build tool'] },
  ];

  const tables = [
    { name:'properties', rows:'48,320', desc:'One row per cadastral parcel. No owner name, no address text — only ref_catastral, district code, area, year.', accent:C.blue },
    { name:'signals',    rows:'48,320', desc:'Per-property computed binary signals (water_flag, listing_flag, cadastre_flag, resident_flag). Joined only at cluster-build time.', accent:C.muted },
    { name:'clusters',   rows:'31',     desc:'Aggregate result: cluster_id, centroid, prop_count (≥500), confidence level, composite score, misuse type.', accent:C.accent },
    { name:'audit_logs', rows:'284',    desc:'Every inspector query and decision, timestamped, with hashed user ID. Append-only — no UPDATE or DELETE allowed.', accent:C.green },
    { name:'jobs',       rows:'6',      desc:'Scheduled ETL job registry: last run, status, next scheduled time, record counts processed.', accent:C.amber },
  ];

  return (
    <div style={{ maxWidth:880, margin:'0 auto', padding:'56px 0 80px' }}>
      <SectionH n="03 / ARCHITECTURE" title="System design" sub="A deliberately simple stack — no cloud services, no external APIs at runtime, no personal data in any database table. Built to be auditable by a single researcher." />

      {/* data flow diagram */}
      <div style={{ marginBottom:56 }}>
        <div style={{ fontFamily:C.mono, fontSize:10, color:C.hint, letterSpacing:'0.14em', marginBottom:20 }}>DATA FLOW</div>
        <div style={{ background:C.surf, border:`1px solid ${C.brd}`, borderRadius:2, padding:'28px 32px' }}>
          {/* source row */}
          <div style={{ fontFamily:C.mono, fontSize:9, color:C.hint, letterSpacing:'0.12em', marginBottom:12 }}>RAW SOURCES</div>
          <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:8, marginBottom:24 }}>
            {[
              { label:'Catastro',  sub:'shapefile GML', color:C.blue },
              { label:'Airbnb',    sub:'listings CSV',  color:C.red },
              { label:'AGBAR',     sub:'utility grid',  color:C.green },
              { label:'Padrón',    sub:'census block',  color:C.amber },
            ].map(({ label, sub, color }) => (
              <div key={label} style={{ padding:'12px 14px', borderRadius:2, background:C.s2, border:`1px solid ${C.brd}`, borderTop:`2px solid ${color}` }}>
                <div style={{ fontFamily:C.mono, fontSize:11, color, fontWeight:700 }}>{label}</div>
                <div style={{ fontFamily:C.mono, fontSize:9, color:C.hint, marginTop:3 }}>{sub}</div>
              </div>
            ))}
          </div>
          {/* arrow */}
          <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom:24 }}>
            <div style={{ flex:1, height:1, background:`linear-gradient(to right, ${C.brd}, ${C.accent}55)` }} />
            <div style={{ fontFamily:C.mono, fontSize:9, color:C.hint, letterSpacing:'0.08em', padding:'3px 8px', border:`1px solid ${C.brd}`, borderRadius:2, background:C.s2 }}>ETL PIPELINE · Python 3.12</div>
            <div style={{ flex:1, height:1, background:`linear-gradient(to right, ${C.accent}55, ${C.brd})` }} />
          </div>
          {/* processed row */}
          <div style={{ display:'grid', gridTemplateColumns:'2fr 1fr 2fr', gap:12 }}>
            <div style={{ padding:'14px 16px', borderRadius:2, background:C.s2, border:`1px solid ${C.accent}40`, borderTop:`2px solid ${C.accent}` }}>
              <div style={{ fontFamily:C.mono, fontSize:11, color:C.accent, fontWeight:700, marginBottom:6 }}>SQLite Database</div>
              <div style={{ fontFamily:C.sans, fontSize:12, color:C.muted, lineHeight:1.6 }}>5 tables · 48K+ properties · no PII · 24-month retention</div>
            </div>
            <div style={{ display:'flex', alignItems:'center', justifyContent:'center' }}>
              <div style={{ display:'flex', flexDirection:'column', alignItems:'center', gap:4 }}>
                <div style={{ width:1, height:20, background:C.brd }} />
                <div style={{ fontFamily:C.mono, fontSize:10, color:C.hint }}>→</div>
                <div style={{ width:1, height:20, background:C.brd }} />
              </div>
            </div>
            <div style={{ padding:'14px 16px', borderRadius:2, background:C.s2, border:`1px solid ${C.green}40`, borderTop:`2px solid ${C.green}` }}>
              <div style={{ fontFamily:C.mono, fontSize:11, color:C.green, fontWeight:700, marginBottom:6 }}>React Dashboard</div>
              <div style={{ fontFamily:C.sans, fontSize:12, color:C.muted, lineHeight:1.6 }}>Inspector · Audit Log · System · 3 roles · immutable audit trail</div>
            </div>
          </div>
        </div>
      </div>

      {/* tech stack */}
      <div style={{ fontFamily:C.mono, fontSize:10, color:C.hint, letterSpacing:'0.14em', marginBottom:20 }}>TECHNOLOGY STACK</div>
      <div style={{ marginBottom:56, display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:10 }}>
        {stack.map(({ layer, color, items }) => (
          <div key={layer} style={{ padding:'18px 20px', background:C.surf, border:`1px solid ${C.brd}`, borderRadius:2, borderTop:`2px solid ${color}` }}>
            <div style={{ fontFamily:C.mono, fontSize:10, color, letterSpacing:'0.10em', fontWeight:700, marginBottom:14 }}>{layer.toUpperCase()}</div>
            {items.map(item => (
              <div key={item} style={{ display:'flex', alignItems:'flex-start', gap:8, marginBottom:8 }}>
                <div style={{ width:3, height:3, borderRadius:'50%', background:color, flexShrink:0, marginTop:6, opacity:0.6 }} />
                <span style={{ fontFamily:C.sans, fontSize:12, color:C.muted, lineHeight:1.5 }}>{item}</span>
              </div>
            ))}
          </div>
        ))}
      </div>

      {/* tables */}
      <div style={{ fontFamily:C.mono, fontSize:10, color:C.hint, letterSpacing:'0.14em', marginBottom:20 }}>DATABASE TABLES</div>
      <div style={{ background:C.surf, border:`1px solid ${C.brd}`, borderRadius:2, overflow:'hidden' }}>
        {tables.map(({ name, rows, desc, accent }, i) => (
          <div key={name} style={{ display:'grid', gridTemplateColumns:'150px 70px 1fr', gap:0, borderBottom: i < tables.length-1 ? `1px solid ${C.brd}` : 'none' }}>
            <div style={{ padding:'14px 20px', borderRight:`1px solid ${C.brd}`, display:'flex', alignItems:'center' }}>
              <span style={{ fontFamily:C.mono, fontSize:12, color:accent, fontWeight:600 }}>{name}</span>
            </div>
            <div style={{ padding:'14px 12px', borderRight:`1px solid ${C.brd}`, display:'flex', alignItems:'center' }}>
              <span style={{ fontFamily:C.mono, fontSize:11, color:C.hint }}>{rows}</span>
            </div>
            <div style={{ padding:'14px 20px', display:'flex', alignItems:'center' }}>
              <span style={{ fontFamily:C.sans, fontSize:12, color:C.muted, lineHeight:1.6 }}>{desc}</span>
            </div>
          </div>
        ))}
      </div>

      {/* privacy note */}
      <div style={{ marginTop:20, padding:'20px 24px', borderRadius:2, background:C.grnBg, border:`1px solid ${C.grnBrd}`, display:'flex', gap:16, alignItems:'flex-start' }}>
        <div style={{ width:3, height:'100%', minHeight:40, background:C.green, borderRadius:1, flexShrink:0 }} />
        <div>
          <div style={{ fontFamily:C.mono, fontSize:10, color:C.green, letterSpacing:'0.12em', marginBottom:8, fontWeight:700 }}>PRIVACY BY DESIGN</div>
          <p style={{ fontFamily:C.sans, fontSize:13, color:C.muted, lineHeight:1.7, margin:0 }}>
            No table stores a person's name, address string, or tax ID. The <code style={{ fontFamily:C.mono, fontSize:12, color:C.text, background:C.s3, padding:'1px 5px', borderRadius:2 }}>ref_catastral</code> identifier references parcels, not people. User IDs in <code style={{ fontFamily:C.mono, fontSize:12, color:C.text, background:C.s3, padding:'1px 5px', borderRadius:2 }}>audit_logs</code> are one-way SHA-256 hashes — the plaintext mapping is held only by the system administrator.
          </p>
        </div>
      </div>
    </div>
  );
}

/* ─── About page ─── */
function AboutPage({ onEnter }: { onEnter: () => void }) {
  return (
    <div style={{ maxWidth:880, margin:'0 auto', padding:'56px 0 80px' }}>
      <SectionH n="04 / ABOUT" title="Research context" sub="TrueOccupancy is a master's thesis prototype exploring how open civic data can support housing enforcement without compromising resident privacy." />

      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:20, marginBottom:48 }}>
        {[
          { label:'Thesis title', value:'Privacy-Preserving Housing Occupancy Monitoring Using Open Civic Data: A Barcelona Case Study' },
          { label:'Research question', value:'Can k-anonymous cluster analysis of open administrative data detect housing misuse at a scale useful for municipal enforcement, without exposing individual residents?' },
          { label:'Institution', value:'Universitat de Barcelona · Facultat d\'Economia i Empresa' },
          { label:'Programme', value:'MSc in Business Analytics & Big Data' },
          { label:'Supervisor', value:'Dr. Anna Puig-Domènech · Dept. of Applied Statistics' },
          { label:'Status', value:'Prototype phase — data pipeline complete, dashboard functional, real cadastral integration in progress · 2026' },
        ].map(({ label, value }) => (
          <div key={label} style={{ padding:'20px 22px', background:C.surf, border:`1px solid ${C.brd}`, borderRadius:2 }}>
            <div style={{ fontFamily:C.mono, fontSize:10, color:C.hint, letterSpacing:'0.10em', marginBottom:8 }}>{label.toUpperCase()}</div>
            <p style={{ fontFamily:C.sans, fontSize:13, color:C.muted, lineHeight:1.65, margin:0 }}>{value}</p>
          </div>
        ))}
      </div>

      {/* requirements summary */}
      <div style={{ fontFamily:C.mono, fontSize:10, color:C.hint, letterSpacing:'0.12em', marginBottom:20 }}>REQUIREMENTS IMPLEMENTATION STATUS</div>
      <div style={{ display:'flex', flexDirection:'column', gap:0, marginBottom:48 }}>
        {[
          { cat:'MUST', color:C.accent, items:[
            ['k-anonymity floor (k≥500) enforced at query layer','done'],
            ['Interactive GIS cluster map with real Barcelona polygons','done'],
            ['Four-signal aggregate dashboard (water, listings, cadastre, padrón)','done'],
            ['Inspector decision logging with immutable audit trail','done'],
            ['Data freshness warnings (>35 days stale)','done'],
            ['Query blocking + logging for sub-threshold requests','done'],
          ]},
          { cat:'SHOULD', color:C.amber, items:[
            ['Real cadastral data loaded via ETL pipeline','in progress'],
            ['Inside Airbnb 2024 listings matched to parcels','in progress'],
            ['Automated confidence score recalculation on new data','planned'],
          ]},
          { cat:'COULD', color:C.hint, items:[
            ['Time-series trend view per cluster','planned'],
            ['Inspector notification on new high-confidence clusters','planned'],
            ['Export cluster report as PDF','planned'],
          ]},
        ].map(({ cat, color, items }) => (
          <div key={cat} style={{ marginBottom:24 }}>
            <div style={{ display:'flex', alignItems:'center', gap:10, marginBottom:12 }}>
              <div style={{ width:3, height:14, background:color, borderRadius:1 }} />
              <span style={{ fontFamily:C.mono, fontSize:10, color, letterSpacing:'0.12em', fontWeight:700 }}>{cat} REQUIREMENTS</span>
              <div style={{ flex:1, height:1, background:C.brd }} />
              <span style={{ fontFamily:C.mono, fontSize:10, color:C.hint }}>{items.filter(([,s])=>s==='done').length}/{items.length} complete</span>
            </div>
            <div style={{ background:C.surf, border:`1px solid ${C.brd}`, borderRadius:2, overflow:'hidden' }}>
              {items.map(([text, status], i) => {
                const statusColor = status==='done'?C.green:status==='in progress'?C.amber:C.hint;
                return (
                  <div key={String(text)} style={{ display:'flex', alignItems:'center', gap:14, padding:'12px 18px', borderBottom: i<items.length-1?`1px solid ${C.brd}`:'none', background: status==='done'?'transparent':undefined }}>
                    <div style={{ width:7, height:7, borderRadius:'50%', flexShrink:0, background:statusColor, boxShadow:status==='done'?`0 0 6px ${statusColor}44`:undefined }} />
                    <span style={{ flex:1, fontFamily:C.sans, fontSize:13, color:status==='done'?C.text:C.muted, lineHeight:1.5 }}>{String(text)}</span>
                    <span style={{ fontFamily:C.mono, fontSize:9, color:statusColor, letterSpacing:'0.08em', padding:'3px 7px', borderRadius:2, border:`1px solid ${statusColor}30`, background:`${statusColor}10`, whiteSpace:'nowrap' }}>{String(status).toUpperCase()}</span>
                  </div>
                );
              })}
            </div>
          </div>
        ))}
      </div>

      <button
        onClick={onEnter}
        style={{ padding:'14px 32px', borderRadius:2, border:'none', background:C.accent, color:'#FFF8F4', fontFamily:C.sans, fontSize:14, fontWeight:600, cursor:'pointer' }}
        onMouseEnter={e => { (e.target as HTMLElement).style.background='#C08060'; }}
        onMouseLeave={e => { (e.target as HTMLElement).style.background=C.accent; }}
      >
        Open Inspector Dashboard →
      </button>
    </div>
  );
}

/* ─── Home page ─── */
function ThemeToggle({ theme, setTheme }: { theme: string; setTheme: (t:'dark'|'light') => void }) {
  const dark = theme === 'dark';
  return (
    <button
      onClick={() => setTheme(dark ? 'light' : 'dark')}
      title={`Switch to ${dark ? 'light' : 'dark'} mode`}
      style={{ display:'flex', alignItems:'center', gap:7, padding:'5px 12px', borderRadius:2, border:`1px solid ${C.brd}`, background:C.s2, cursor:'pointer', fontFamily:C.mono, fontSize:10, color:C.muted, letterSpacing:'0.06em', flexShrink:0 }}
    >
      <span style={{ fontSize:12 }}>{dark ? '☀' : '◑'}</span>
      {dark ? 'LIGHT' : 'DARK'}
    </button>
  );
}

function HomePage({ onOpenLogin, theme, setTheme }: { onOpenLogin: () => void; theme: 'dark'|'light'; setTheme: (t:'dark'|'light') => void }) {
  const onEnter = onOpenLogin; // alias for all existing references inside
  const [subPage, setSubPage] = useState<'landing'|'methodology'|'architecture'|'about'|'resources'|'design'>('landing');
  const [tick, setTick] = useState(0);
  useEffect(() => { const id = setInterval(() => setTick(t => t + 1), 1000); return () => clearInterval(id); }, []);
  const now = new Date();
  const timeStr = now.toLocaleTimeString('es-ES', { hour:'2-digit', minute:'2-digit', second:'2-digit' });

  return (
    <div style={{ minHeight:'100vh', background:C.navy, display:'flex', flexDirection:'column' }}>
      {/* top bar */}
      <div style={{ height:42, display:'flex', alignItems:'center', justifyContent:'space-between', padding:'0 32px', borderBottom:`1px solid ${C.brd}` }}>
        <div style={{ display:'flex', alignItems:'center', gap:24 }}>
          <span style={{ fontFamily:C.mono, fontSize:10, color:C.hint, letterSpacing:'0.14em' }}>AJUNTAMENT DE BARCELONA</span>
          <span style={{ width:1, height:14, background:C.brd }} />
          <span style={{ fontFamily:C.mono, fontSize:10, color:C.hint, letterSpacing:'0.10em' }}>HABITATGE I URBANISME</span>
        </div>
        <div style={{ display:'flex', alignItems:'center', gap:20 }}>
          {[['DB',true],['API',true],['ETL',true]].map(([label,ok])=>(
            <div key={String(label)} style={{ display:'flex', alignItems:'center', gap:6 }}>
              <div style={{ width:5, height:5, borderRadius:'50%', background:ok?C.green:C.red, boxShadow:`0 0 5px ${ok?C.green:C.red}` }} />
              <span style={{ fontFamily:C.mono, fontSize:10, color:C.muted }}>{String(label)}</span>
            </div>
          ))}
          <span style={{ width:1, height:14, background:C.brd }} />
          <span style={{ fontFamily:C.mono, fontSize:10, color:C.muted }}>{timeStr}</span>
        </div>
      </div>

      {/* page nav */}
      <div style={{ display:'flex', alignItems:'center', gap:0, padding:'0 32px', borderBottom:`1px solid ${C.brd}`, background:C.surf }}>
        {([
          { id:'landing',      label:'01 — Overview'      },
          { id:'methodology',  label:'02 — Methodology'   },
          { id:'architecture', label:'03 — Architecture'  },
          { id:'about',        label:'04 — About'         },
          { id:'resources',    label:'05 — References'    },
          { id:'design',       label:'06 — Design assets'  },
        ] as const).map(({ id, label }) => {
          const active = subPage === id;
          return (
            <button key={id} onClick={() => setSubPage(id)} style={{ padding:'13px 22px', border:'none', background:'transparent', cursor:'pointer', fontFamily:C.mono, fontSize:11, fontWeight:active?600:400, color:active?C.accent:C.hint, letterSpacing:'0.06em', borderBottom:active?`2px solid ${C.accent}`:'2px solid transparent', transition:'all 0.15s' }}>
              {label}
            </button>
          );
        })}
        <div style={{ marginLeft:'auto', display:'flex', alignItems:'center', gap:16 }}>
          <Ticker inline />
          <ThemeToggle theme={theme} setTheme={setTheme} />
          <button onClick={onEnter} style={{ padding:'7px 18px', borderRadius:2, border:`1px solid ${C.accent}`, background:'transparent', color:C.accent, fontFamily:C.sans, fontSize:12, fontWeight:600, cursor:'pointer', whiteSpace:'nowrap' }}>
            Open Dashboard →
          </button>
        </div>
      </div>

      {/* routed sub-page */}
      {subPage !== 'landing' && (
        <div style={{ flex:1, overflowY:'auto', padding:'0 64px' }}>
          {subPage === 'methodology'  && <MethodologyPage />}
          {subPage === 'architecture' && <ArchitecturePage />}
          {subPage === 'about'        && <AboutPage onEnter={onEnter} />}
          {subPage === 'resources'    && <ResourcesPage />}
          {subPage === 'design'       && <DesignAssetsPage />}
        </div>
      )}

      {/* hero grid — only on landing */}
      {subPage === 'landing' && <></> /* rendered below */}
      {subPage === 'landing' && <>
      {/* hero grid */}
      <div style={{ flex:1, display:'grid', gridTemplateColumns:'1fr auto 1fr', alignItems:'center', gap:0, padding:'48px 64px', minHeight:0 }}>

        {/* left */}
        <div style={{ display:'flex', flexDirection:'column', gap:28, animation:'fade-up 0.6s ease both', animationDelay:'0.05s' }}>
          <div style={{ display:'flex', alignItems:'center', gap:10 }}>
            <div style={{ padding:'4px 10px', borderRadius:2, background:C.acDim, border:`1px solid ${C.acBrd}` }}>
              <span style={{ fontFamily:C.mono, fontSize:10, color:C.accent, letterSpacing:'0.14em', fontWeight:700 }}>PILOT 01</span>
            </div>
            <span style={{ fontFamily:C.mono, fontSize:10, color:C.hint, letterSpacing:'0.08em' }}>/ BARCELONA CITY</span>
          </div>

          <div>
            <h1 style={{ fontFamily:C.sans, fontSize:48, fontWeight:700, color:C.text, lineHeight:1.05, margin:0, letterSpacing:'-0.035em' }}>
              True<span style={{ color:C.accent }}>Occupancy</span>
            </h1>
            <p style={{ fontFamily:C.sans, fontSize:16, color:C.muted, marginTop:14, lineHeight:1.65, maxWidth:360, fontWeight:400 }}>
              Privacy-preserving housing occupancy monitoring for Barcelona's Gràcia and Eixample districts.
            </p>
          </div>

          <div style={{ background:C.surf, border:`1px solid ${C.brd}`, borderRadius:2, overflow:'hidden' }}>
            {[
              { label:'Properties indexed', value:'48,320', color:C.blue },
              { label:'Active clusters',    value:'7 / 31', color:C.green },
              { label:'k-anonymity floor',  value:'k ≥ 500',color:C.accent },
              { label:'Signal sources',     value:'4',       color:C.muted },
            ].map(({ label, value, color }, i, arr) => (
              <div key={label} style={{ display:'flex', alignItems:'center', justifyContent:'space-between', padding:'13px 18px', borderBottom: i<arr.length-1?`1px solid ${C.brd}`:'none' }}>
                <span style={{ fontFamily:C.sans, fontSize:13, color:C.muted }}>{label}</span>
                <span style={{ fontFamily:C.mono, fontSize:14, color, fontWeight:700 }}>{value}</span>
              </div>
            ))}
          </div>

          <button
            onClick={onEnter}
            style={{ alignSelf:'flex-start', padding:'14px 32px', borderRadius:2, border:'none', background:C.accent, color:'#FFF8F4', fontFamily:C.sans, fontSize:14, fontWeight:600, cursor:'pointer', letterSpacing:'-0.01em', transition:'all 0.15s' }}
            onMouseEnter={e => { const el = e.target as HTMLElement; el.style.background='#C08060'; el.style.transform='translateY(-1px)'; }}
            onMouseLeave={e => { const el = e.target as HTMLElement; el.style.background=C.accent; el.style.transform='translateY(0)'; }}
          >
            Open Inspector Dashboard →
          </button>
        </div>

        {/* centre globe */}
        <div style={{ display:'flex', alignItems:'center', justifyContent:'center', padding:'0 16px' }}>
          <SatelliteGlobe />
        </div>

        {/* right — schema */}
        <div style={{ display:'flex', flexDirection:'column', gap:14, alignItems:'flex-end', animation:'fade-up 0.6s ease both', animationDelay:'0.2s' }}>
          <div style={{ fontFamily:C.mono, fontSize:10, color:C.hint, letterSpacing:'0.12em', textAlign:'right', marginBottom:4 }}>DATABASE SCHEMA</div>
          <SchemaCard table="properties" accent={C.blue} fields={[
            { name:'ref_catastral', type:'TEXT PK' },
            { name:'district',      type:'TEXT' },
            { name:'area_m2',       type:'REAL' },
            { name:'built_year',    type:'INT' },
          ]} />
          <SchemaCard table="clusters" accent={C.accent} fields={[
            { name:'cluster_id',   type:'TEXT PK' },
            { name:'prop_count',   type:'INT ≥500' },
            { name:'conf_level',   type:'TEXT' },
            { name:'signal_score', type:'REAL' },
          ]} />
          <SchemaCard table="audit_logs" accent={C.green} fields={[
            { name:'log_id',    type:'TEXT PK' },
            { name:'user_hash', type:'TEXT' },
            { name:'action',    type:'TEXT' },
            { name:'ts',        type:'DATETIME' },
          ]} />

          <div style={{ padding:'12px 16px', borderRadius:2, background:C.grnBg, border:`1px solid ${C.grnBrd}`, maxWidth:220, marginTop:4 }}>
            <div style={{ fontFamily:C.mono, fontSize:9, color:C.green, letterSpacing:'0.12em', marginBottom:6, fontWeight:600 }}>PRIVACY GUARANTEES</div>
            <div style={{ fontFamily:C.sans, fontSize:11, color:C.muted, lineHeight:1.65 }}>
              No individual property data exposed · All queries logged immutably · k-anonymity enforced at query layer
            </div>
          </div>
        </div>
      </div>

      {/* footer */}
      <div style={{ padding:'12px 32px', borderTop:`1px solid ${C.brd}`, display:'flex', alignItems:'center', justifyContent:'space-between' }}>
        <span style={{ fontFamily:C.mono, fontSize:10, color:C.hint }}>TrueOccupancy · Thesis Prototype · Universitat de Barcelona · 2026</span>
        <div style={{ display:'flex', gap:24 }}>
          {['Gràcia','Eixample','Sarrià-Sant Gervasi'].map((d,i) => (
            <span key={d} style={{ fontFamily:C.mono, fontSize:10, color:i===0?C.accent:C.hint }}>{d}</span>
          ))}
        </div>
        <span style={{ fontFamily:C.mono, fontSize:10, color:C.hint }}>v0.1.0-pilot</span>
      </div>
      </>}
    </div>
  );
}

/* ─── TopBar ─── */
/* ─── Shared municipal header strip ─── */
function MunicipalStrip() {
  return (
    <div style={{ height:42, display:'flex', alignItems:'center', justifyContent:'space-between', padding:'0 32px', borderBottom:`1px solid ${C.brd}`, background:C.navy, flexShrink:0 }}>
      <div style={{ display:'flex', alignItems:'center', gap:24 }}>
        <span style={{ fontFamily:C.mono, fontSize:10, color:C.hint, letterSpacing:'0.14em' }}>AJUNTAMENT DE BARCELONA</span>
        <span style={{ width:1, height:14, background:C.brd }} />
        <span style={{ fontFamily:C.mono, fontSize:10, color:C.hint, letterSpacing:'0.10em' }}>HABITATGE I URBANISME</span>
      </div>
      <div style={{ display:'flex', alignItems:'center', gap:20 }}>
        {[['DB',true],['API',true],['ETL',true]].map(([l,ok])=>(
          <div key={String(l)} style={{ display:'flex', alignItems:'center', gap:6 }}>
            <div style={{ width:5, height:5, borderRadius:'50%', background:ok?C.green:C.red, boxShadow:`0 0 5px ${ok?C.green:C.red}` }} />
            <span style={{ fontFamily:C.mono, fontSize:10, color:C.muted }}>{String(l)}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ─── Login page ─── */
function LoginPage({ onLogin, theme, setTheme }: { onLogin: () => void; theme:'dark'|'light'; setTheme:(t:'dark'|'light')=>void }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);

  const inp: React.CSSProperties = { width:'100%', padding:'10px 12px', background:C.s2, border:`1px solid ${C.brd}`, borderRadius:2, color:C.text, fontFamily:C.sans, fontSize:13, outline:'none', boxSizing:'border-box' as const };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setTimeout(() => { setLoading(false); onLogin(); }, 600);
  };

  return (
    <div style={{ minHeight:'100vh', background:C.navy, display:'flex', flexDirection:'column' }}>
      <MunicipalStrip />
      {/* top-right theme toggle */}
      <div style={{ position:'absolute', top:10, right:24, zIndex:10 }}>
        <ThemeToggle theme={theme} setTheme={setTheme} />
      </div>

      <div style={{ flex:1, display:'flex', alignItems:'center', justifyContent:'center', padding:32 }}>
        <div style={{ width:'100%', maxWidth:400 }}>
          {/* Logo mark */}
          <div style={{ textAlign:'center', marginBottom:32 }}>
            <div style={{ display:'inline-flex', alignItems:'center', gap:10, marginBottom:16 }}>
              <div style={{ width:20, height:20, background:C.accent, borderRadius:1 }} />
              <span style={{ fontFamily:C.sans, fontSize:18, fontWeight:700, color:C.text, letterSpacing:'-0.02em' }}>
                True<span style={{ color:C.accent }}>Occupancy</span>
              </span>
              <span style={{ fontFamily:C.mono, fontSize:9, padding:'2px 6px', borderRadius:2, background:C.acDim, color:C.accent, letterSpacing:'0.1em' }}>BCN</span>
            </div>
            <div style={{ fontFamily:C.mono, fontSize:11, color:C.hint, letterSpacing:'0.08em' }}>INSPECTOR PORTAL — RESTRICTED ACCESS</div>
          </div>

          {/* Card */}
          <div style={{ background:C.surf, border:`1px solid ${C.brd}`, borderRadius:2, padding:32 }}>
            <div style={{ fontFamily:C.sans, fontSize:15, fontWeight:600, color:C.text, marginBottom:22, letterSpacing:'-0.01em' }}>Sign in to your account</div>

            <form onSubmit={handleSubmit} style={{ display:'flex', flexDirection:'column', gap:14 }}>
              <div>
                <div style={{ fontFamily:C.mono, fontSize:10, letterSpacing:'0.10em', textTransform:'uppercase' as const, color:C.hint, marginBottom:6 }}>Work email</div>
                <input type="email" placeholder="inspector@bcn.cat" value={email} onChange={e=>setEmail(e.target.value)} style={inp} autoComplete="username" />
              </div>
              <div>
                <div style={{ fontFamily:C.mono, fontSize:10, letterSpacing:'0.10em', textTransform:'uppercase' as const, color:C.hint, marginBottom:6 }}>Password</div>
                <input type="password" placeholder="••••••••" value={password} onChange={e=>setPassword(e.target.value)} style={inp} autoComplete="current-password" />
              </div>

              <button type="submit" disabled={loading} style={{ padding:'11px 0', borderRadius:2, border:'none', background:C.accent, color:'#FFF8F4', fontFamily:C.sans, fontSize:13, fontWeight:600, cursor:'pointer', opacity:loading?0.7:1, marginTop:6, letterSpacing:'0.01em' }}>
                {loading ? 'Signing in…' : 'Sign in →'}
              </button>
            </form>

            <div style={{ margin:'18px 0', display:'flex', alignItems:'center', gap:10 }}>
              <div style={{ flex:1, height:1, background:C.brd }} />
              <span style={{ fontFamily:C.mono, fontSize:10, color:C.hint }}>OR</span>
              <div style={{ flex:1, height:1, background:C.brd }} />
            </div>

            <button onClick={handleSubmit as unknown as React.MouseEventHandler} style={{ width:'100%', padding:'10px 0', borderRadius:2, border:`1px solid ${C.brd}`, background:'transparent', color:C.muted, fontFamily:C.sans, fontSize:12, cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center', gap:8 }}>
              <svg width="14" height="14" viewBox="0 0 16 16" fill="none"><rect x="1" y="1" width="6" height="6" rx="1" fill={C.accent}/><rect x="9" y="1" width="6" height="6" rx="1" fill={C.accent} opacity=".5"/><rect x="1" y="9" width="6" height="6" rx="1" fill={C.accent} opacity=".5"/><rect x="9" y="9" width="6" height="6" rx="1" fill={C.accent}/></svg>
              Sign in with municipal SSO
            </button>

            {/* Privacy notice */}
            <div style={{ marginTop:20, padding:'10px 12px', background:C.s2, border:`1px solid ${C.brd}`, borderRadius:2 }}>
              <div style={{ fontFamily:C.sans, fontSize:11, color:C.hint, lineHeight:1.6 }}>
                Access is logged and audited. By signing in you confirm compliance with the{' '}
                <span style={{ color:C.accent }}>Municipal Data Governance Policy</span>.
                User IDs are stored as one-way hashes — no personal data is retained in this system.
              </div>
            </div>
          </div>

          <div style={{ marginTop:18, textAlign:'center', fontFamily:C.mono, fontSize:10, color:C.hint, letterSpacing:'0.06em' }}>
            DEMO MODE — ANY CREDENTIALS ACCEPTED
          </div>
        </div>
      </div>
    </div>
  );
}

/* ─── Role select page ─── */
const ROLE_HASHES: Record<SessionInfo['role'], string> = {
  inspector: 'a3f7…',
  administrator: 'f2b9…',
};

const ROLE_ACCESS: Record<SessionInfo['role'], ('inspector'|'audit'|'system')[]> = {
  inspector: ['inspector', 'audit'],
  administrator: ['audit', 'system'],
};

function RoleSelectPage({ onSelect }: { onSelect: (role: SessionInfo['role']) => void }) {
  const roles: { id: SessionInfo['role']; title: string; desc: string; pages: string[] }[] = [
    {
      id: 'inspector',
      title: 'Inspector',
      desc: 'Access the cluster Inspector and Audit Log for your own activity. Cannot view system configuration or other users’ audit entries.',
      pages: ['Inspector', 'Audit Log (own entries)'],
    },
    {
      id: 'administrator',
      title: 'Administrator',
      desc: 'Access the full Audit Log (all users) and System configuration. Cannot access the Inspector cluster page.',
      pages: ['Audit Log (all users)', 'System'],
    },
  ];

  return (
    <div style={{ minHeight:'100vh', background:C.navy, display:'flex', flexDirection:'column' }}>
      <MunicipalStrip />
      <div style={{ flex:1, display:'flex', alignItems:'center', justifyContent:'center', padding:32 }}>
        <div style={{ width:'100%', maxWidth:680 }}>
          <div style={{ textAlign:'center', marginBottom:36 }}>
            <div style={{ fontFamily:C.mono, fontSize:10, color:C.hint, letterSpacing:'0.12em', marginBottom:12 }}>DEMO ROLE SELECTION</div>
            <div style={{ fontFamily:C.sans, fontSize:20, fontWeight:700, color:C.text, letterSpacing:'-0.02em' }}>Choose your demo role</div>
            <div style={{ fontFamily:C.sans, fontSize:13, color:C.muted, marginTop:8 }}>Each role has different page access. You can sign out and choose again.</div>
          </div>
          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:16 }}>
            {roles.map(r => (
              <button key={r.id} onClick={() => onSelect(r.id)} style={{ background:C.surf, border:`1px solid ${C.brd}`, borderRadius:2, padding:'28px 28px 24px', cursor:'pointer', textAlign:'left', transition:'border-color 0.15s, box-shadow 0.15s', outline:'none' }}
                onMouseEnter={e => { (e.currentTarget as HTMLElement).style.borderColor = C.accent; (e.currentTarget as HTMLElement).style.boxShadow = `0 0 0 1px ${C.accent}`; }}
                onMouseLeave={e => { (e.currentTarget as HTMLElement).style.borderColor = C.brd; (e.currentTarget as HTMLElement).style.boxShadow = 'none'; }}
              >
                <div style={{ display:'flex', alignItems:'center', gap:10, marginBottom:14 }}>
                  <div style={{ width:10, height:10, borderRadius:'50%', background:C.accent }} />
                  <span style={{ fontFamily:C.mono, fontSize:12, fontWeight:700, color:C.accent, letterSpacing:'0.06em', textTransform:'uppercase' as const }}>{r.title}</span>
                  <span style={{ fontFamily:C.mono, fontSize:10, color:C.hint, marginLeft:'auto' }}>{ROLE_HASHES[r.id]}</span>
                </div>
                <div style={{ fontFamily:C.sans, fontSize:12, color:C.muted, lineHeight:1.65, marginBottom:18 }}>{r.desc}</div>
                <div style={{ display:'flex', flexDirection:'column', gap:6 }}>
                  {r.pages.map(p => (
                    <div key={p} style={{ display:'flex', alignItems:'center', gap:8 }}>
                      <svg width="12" height="12" viewBox="0 0 12 12" fill="none"><path d="M2.5 6l2.5 2.5 4.5-5" stroke={C.green} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/></svg>
                      <span style={{ fontFamily:C.sans, fontSize:11, color:C.muted }}>{p}</span>
                    </div>
                  ))}
                </div>
                <div style={{ marginTop:20, fontFamily:C.sans, fontSize:12, fontWeight:600, color:C.accent }}>Continue as {r.title} →</div>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

/* ─── Inactivity timeout warning modal ─── */
function TimeoutWarningModal({ onStay, onSignOut }: { onStay: () => void; onSignOut: () => void }) {
  return (
    <div style={{ position:'fixed', inset:0, background:'rgba(0,0,0,0.65)', zIndex:9000, display:'flex', alignItems:'center', justifyContent:'center' }}>
      <div style={{ background:C.surf, border:`1px solid ${C.brd}`, borderRadius:2, padding:36, maxWidth:420, width:'100%', boxShadow:'0 24px 60px rgba(0,0,0,0.5)' }}>
        <div style={{ display:'flex', alignItems:'center', gap:12, marginBottom:20 }}>
          <div style={{ width:36, height:36, borderRadius:2, background:C.ambBg, border:`1px solid ${C.ambBrd}`, display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0 }}>
            <svg width="18" height="18" viewBox="0 0 18 18" fill="none"><circle cx="9" cy="9" r="7.5" stroke={C.amber} strokeWidth="1.5"/><path d="M9 5v4.5l2.5 2.5" stroke={C.amber} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/></svg>
          </div>
          <div>
            <div style={{ fontFamily:C.sans, fontSize:14, fontWeight:600, color:C.text, letterSpacing:'-0.01em' }}>Session expiring soon</div>
            <div style={{ fontFamily:C.mono, fontSize:11, color:C.amber, marginTop:3 }}>5 minutes remaining</div>
          </div>
        </div>
        <div style={{ fontFamily:C.sans, fontSize:13, color:C.muted, lineHeight:1.65, marginBottom:24 }}>
          Your session will expire in 5 minutes due to inactivity. All unsaved work will be preserved. Would you like to stay signed in?
        </div>
        <div style={{ display:'flex', gap:10 }}>
          <button onClick={onStay} style={{ flex:1, padding:'10px 0', borderRadius:2, border:'none', background:C.accent, color:'#FFF8F4', fontFamily:C.sans, fontSize:13, fontWeight:600, cursor:'pointer' }}>
            Stay signed in
          </button>
          <button onClick={onSignOut} style={{ padding:'10px 18px', borderRadius:2, border:`1px solid ${C.brd}`, background:'transparent', color:C.muted, fontFamily:C.sans, fontSize:13, cursor:'pointer' }}>
            Sign out
          </button>
        </div>
      </div>
    </div>
  );
}

/* ─── Restricted-by-role placeholder ─── */
function RestrictedPage({ role }: { role: SessionInfo['role'] }) {
  return (
    <div style={{ display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', height:400, textAlign:'center', gap:16 }}>
      <div style={{ width:56, height:56, borderRadius:2, background:C.redBg, border:`1px solid ${C.redBrd}`, display:'flex', alignItems:'center', justifyContent:'center' }}>
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none"><rect x="3" y="11" width="18" height="11" rx="1.5" stroke={C.red} strokeWidth="1.5"/><path d="M7 11V7a5 5 0 0 1 10 0v4" stroke={C.red} strokeWidth="1.5" strokeLinecap="round"/></svg>
      </div>
      <div style={{ fontFamily:C.sans, fontSize:15, fontWeight:600, color:C.text }}>Access restricted</div>
      <div style={{ fontFamily:C.sans, fontSize:13, color:C.muted, maxWidth:340, lineHeight:1.65 }}>
        This page is not available to the <strong style={{ color:C.text }}>{role}</strong> role.
        {role === 'administrator'
          ? ' The Inspector cluster map is restricted to Inspector-role users only.'
          : ' System configuration is restricted to Administrator-role users only.'}
      </div>
    </div>
  );
}

/* ─── TopBar ─── */
function TopBar({
  page, setPage, theme, setTheme, onSignOut, onFastForward,
}: {
  page: string;
  setPage: (p:'inspector'|'audit'|'system') => void;
  theme: 'dark'|'light';
  setTheme: (t:'dark'|'light') => void;
  onSignOut: () => void;
  onFastForward: () => void;
}) {
  const { session } = useAppState();
  const [menuOpen, setMenuOpen] = useState(false);

  const role = session?.role ?? 'inspector';
  const allowedPages = ROLE_ACCESS[role];

  /* Initials from role */
  const initials = role === 'inspector' ? 'IN' : 'AD';

  return (
    <div style={{ height:50, background:C.navy, borderBottom:`1px solid ${C.brd}`, display:'flex', alignItems:'center', padding:'0 24px', gap:8, position:'sticky', top:0, zIndex:50 }}>
      <div style={{ display:'flex', alignItems:'center', gap:10, marginRight:28 }}>
        <div style={{ width:16, height:16, background:C.accent, borderRadius:1, flexShrink:0 }} />
        <span style={{ fontFamily:C.sans, fontSize:14, fontWeight:600, color:C.text, letterSpacing:'-0.02em' }}>
          True<span style={{ color:C.accent }}>Occupancy</span>
        </span>
        <span style={{ fontFamily:C.mono, fontSize:9, padding:'2px 6px', borderRadius:2, background:C.acDim, color:C.accent, letterSpacing:'0.1em' }}>BCN</span>
      </div>

      <nav style={{ display:'flex', gap:2 }}>
        {(['inspector','audit','system'] as const)
          .filter(id => allowedPages.includes(id))
          .map(id => {
            const labels = { inspector:'Inspector', audit:'Audit Log', system:'System' };
            const active = page === id;
            return (
              <button key={id} onClick={()=>setPage(id)} style={{ position:'relative', padding:'6px 16px', borderRadius:2, border:'none', cursor:'pointer', fontFamily:C.sans, fontSize:13, fontWeight:active?600:400, background:active?C.acDim:'transparent', color:active?C.accent:C.muted, transition:'all 0.15s' }}>
                {labels[id]}
                {active && <span style={{ position:'absolute', bottom:0, left:16, right:16, height:2, background:C.accent, borderRadius:2 }} />}
              </button>
            );
          })}
      </nav>

      <div style={{ marginLeft:'auto', display:'flex', alignItems:'center', gap:10 }}>
        {/* Data freshness strip */}
        <div style={{ display:'flex', alignItems:'center', gap:14, padding:'6px 14px', background:C.s2, border:`1px solid ${C.brd}`, borderRadius:2 }}>
          {[['Utility','8 Apr',true],['Listings','25 Apr',true],['Cadastre','12 Mar',false]].map(([l,d,ok])=>(
            <div key={String(l)} style={{ display:'flex', alignItems:'center', gap:6 }}>
              <div style={{ width:5, height:5, borderRadius:'50%', background:ok?C.green:C.red, boxShadow:`0 0 4px ${ok?C.green:C.red}` }} />
              <span style={{ fontFamily:C.mono, fontSize:10, color:C.hint }}>{String(l)}</span>
              <span style={{ fontFamily:C.mono, fontSize:10, color:ok?C.muted:C.red }}>{String(d)}</span>
            </div>
          ))}
        </div>

        {/* User chip + menu */}
        <div style={{ position:'relative' }}>
          <button
            onClick={() => setMenuOpen(v => !v)}
            style={{ display:'flex', alignItems:'center', gap:8, padding:'5px 10px', background:menuOpen?C.s3:C.s2, border:`1px solid ${menuOpen?C.acBrd:C.brd}`, borderRadius:2, cursor:'pointer' }}
          >
            <div style={{ width:24, height:24, borderRadius:2, background:C.accent, color:'#FFF8F4', display:'flex', alignItems:'center', justifyContent:'center', fontSize:10, fontWeight:700, fontFamily:C.sans, flexShrink:0 }}>{initials}</div>
            <span style={{ fontFamily:C.mono, fontSize:9, padding:'2px 6px', borderRadius:2, background:C.acDim, color:C.accent, letterSpacing:'0.06em', fontWeight:600, textTransform:'uppercase' as const }}>{role}</span>
            <svg width="10" height="10" viewBox="0 0 10 10" fill="none"><path d="M2 3.5l3 3 3-3" stroke={C.hint} strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round"/></svg>
          </button>

          {menuOpen && (
            <>
              {/* Backdrop */}
              <div style={{ position:'fixed', inset:0, zIndex:98 }} onClick={() => setMenuOpen(false)} />
              {/* Dropdown */}
              <div style={{ position:'absolute', top:'calc(100% + 6px)', right:0, width:240, background:C.surf, border:`1px solid ${C.brd}`, borderRadius:2, boxShadow:'0 8px 28px rgba(0,0,0,0.3)', zIndex:99, overflow:'hidden' }}>
                {/* Identity section */}
                <div style={{ padding:'14px 16px', borderBottom:`1px solid ${C.brd}` }}>
                  <div style={{ fontFamily:C.mono, fontSize:10, color:C.hint, letterSpacing:'0.08em', marginBottom:6 }}>SIGNED IN AS</div>
                  <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom:4 }}>
                    <Pill t={role === 'inspector' ? 'watch' : 'neutral'}>{role}</Pill>
                  </div>
                  <div style={{ fontFamily:C.mono, fontSize:11, color:C.muted, marginTop:6 }}>
                    User ID: <span style={{ color:C.text }}>{session?.userId ?? '—'}</span>
                  </div>
                </div>
                {/* Actions */}
                <div style={{ padding:'6px 0' }}>
                  <button
                    onClick={() => { setMenuOpen(false); onFastForward(); }}
                    style={{ width:'100%', padding:'8px 16px', background:'none', border:'none', cursor:'pointer', textAlign:'left', fontFamily:C.sans, fontSize:12, color:C.hint, display:'flex', alignItems:'center', gap:10 }}
                    onMouseEnter={e => (e.currentTarget.style.background = C.s2)}
                    onMouseLeave={e => (e.currentTarget.style.background = 'none')}
                  >
                    <svg width="13" height="13" viewBox="0 0 16 16" fill="none"><path d="M3 8h10M10 5l3 3-3 3" stroke={C.hint} strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round"/></svg>
                    Demo: fast-forward session
                  </button>
                  <div style={{ height:1, background:C.brd, margin:'4px 0' }} />
                  <button
                    onClick={() => { setMenuOpen(false); onSignOut(); }}
                    style={{ width:'100%', padding:'8px 16px', background:'none', border:'none', cursor:'pointer', textAlign:'left', fontFamily:C.sans, fontSize:12, color:C.red, display:'flex', alignItems:'center', gap:10 }}
                    onMouseEnter={e => (e.currentTarget.style.background = C.redBg)}
                    onMouseLeave={e => (e.currentTarget.style.background = 'none')}
                  >
                    <svg width="13" height="13" viewBox="0 0 16 16" fill="none"><path d="M6 3H3a1 1 0 0 0-1 1v8a1 1 0 0 0 1 1h3M11 11l3-3-3-3M14 8H6" stroke={C.red} strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round"/></svg>
                    Sign out
                  </button>
                </div>
              </div>
            </>
          )}
        </div>

        <ThemeToggle theme={theme} setTheme={setTheme} />
      </div>
    </div>
  );
}

/* ─── Sidebar ─── */
function Sidebar() {
  const {
    allClusters, pendingQuery, setPendingQuery, runQuery, queryResult,
    useDrawMode, setUseDrawMode, drawnPolygon, inProgressPoints, undoPoint, clearDraw,
  } = useAppState();
  const { misuseType, minConf } = pendingQuery;

  const selStyle: React.CSSProperties = { width:'100%',padding:'7px 10px',background:C.s2,border:`1px solid ${C.brd}`,borderRadius:2,color:C.text,fontFamily:C.sans,fontSize:13,outline:'none' };
  const sec: React.CSSProperties = { padding:'16px 18px',borderBottom:`1px solid ${C.brd}` };

  /* Live preview polygon: prefer finalized, else in-progress if ≥3 pts */
  const previewPolygon: [number, number][] | null =
    drawnPolygon ?? (inProgressPoints.length >= 3 ? inProgressPoints : null);

  /* Live-computed preview */
  const raw = applyFilters(allClusters, pendingQuery, useDrawMode ? previewPolygon : null);
  const subThreshold = raw.filter(c => c.props < 500);
  const valid = raw.filter(c => c.props >= 500);
  const totalProps = valid.reduce((s, c) => s + c.props, 0);

  const drawHasPolygon = useDrawMode && (drawnPolygon !== null || inProgressPoints.length >= 3);
  const drawIncomplete = useDrawMode && !drawnPolygon && inProgressPoints.length < 3;

  const wouldBlock = drawIncomplete
    ? false /* no preview yet — don't block the button label, just disable */
    : raw.length === 0 || subThreshold.length > 0;

  const blockReason = raw.length === 0
    ? (useDrawMode ? 'No clusters inside drawn area' : 'No clusters match')
    : `${subThreshold.length} group(s) below 500-property minimum`;

  const runDisabled = drawIncomplete || wouldBlock;

  const upd = (field: keyof typeof pendingQuery) => (v: string) =>
    setPendingQuery({ ...pendingQuery, [field]: v });

  /* Toggle button style helper */
  const toggleBtn = (active: boolean) => ({
    flex: 1, padding:'7px 0', borderRadius:2, border: active ? `1px solid ${C.accent}` : `1px solid ${C.brd}`,
    background: active ? C.acDim : C.s2, color: active ? C.accent : C.muted,
    fontFamily: C.sans, fontSize: 11, fontWeight: active ? 600 : 400, cursor:'pointer',
    transition:'all 0.12s', letterSpacing:'0.01em',
  } as React.CSSProperties);

  const pointCount = drawnPolygon ? drawnPolygon.length : inProgressPoints.length;
  const canUndo = drawnPolygon ? true : inProgressPoints.length > 0;

  return (
    <div style={{ width:264,flexShrink:0,background:C.surf,borderRight:`1px solid ${C.brd}`,display:'flex',flexDirection:'column',overflowY:'auto' }}>

      {/* Geographic area */}
      <div style={sec}>
        {lbl('Geographic area')}
        {/* Mode toggle */}
        <div style={{ display:'flex',gap:4,marginBottom:10 }}>
          <button style={toggleBtn(!useDrawMode)} onClick={() => setUseDrawMode(false)}>
            Neighbourhood list
          </button>
          <button style={toggleBtn(useDrawMode)} onClick={() => setUseDrawMode(true)}>
            Draw on map
          </button>
        </div>

        {!useDrawMode ? (
          <select value={pendingQuery.area} onChange={e => upd('area')(e.target.value)} style={selStyle}>
            <option value="all">All districts</option>
            <optgroup label="Gràcia">
              <option value="gracia">Gràcia — full district</option>
              <option value="gracia-vila">Gràcia — Vila de Gràcia</option>
              <option value="gracia-grassot">{"Gràcia — Camp d'en Grassot"}</option>
              <option value="gracia-salut">Gràcia — La Salut</option>
              <option value="gracia-coll">Gràcia — El Coll</option>
              <option value="gracia-vallcarca">Gràcia — Vallcarca</option>
            </optgroup>
            <optgroup label="Eixample">
              <option value="eixample">Eixample — full district</option>
              <option value="eixample-esquerra">Eixample — Esquerra</option>
              <option value="eixample-dreta">Eixample — Dreta + Fort Pienc</option>
            </optgroup>
            <optgroup label="Other districts">
              <option value="sants">Sants-Montjuïc</option>
              <option value="ciutatvella">Ciutat Vella</option>
              <option value="sarria">Sarrià-Sant Gervasi ⚠</option>
              <option value="lescorts">Les Corts ⚠</option>
            </optgroup>
          </select>
        ) : (
          /* Draw mode status */
          <div>
            <div style={{ fontFamily:C.mono,fontSize:11,color:drawnPolygon?C.accent:C.muted,marginBottom:8,lineHeight:1.5 }}>
              {drawnPolygon
                ? `Polygon closed · ${drawnPolygon.length} points`
                : inProgressPoints.length === 0
                  ? 'Click the map to start drawing'
                  : inProgressPoints.length < 3
                    ? `${inProgressPoints.length} point${inProgressPoints.length > 1 ? 's' : ''} placed — ${3 - inProgressPoints.length} more to close`
                    : `${inProgressPoints.length} points — dbl-click or click first to close`}
            </div>
            <div style={{ display:'flex',gap:6 }}>
              <button
                onClick={undoPoint}
                disabled={!canUndo}
                style={{ flex:1,padding:'6px 0',borderRadius:2,border:`1px solid ${C.brd}`,background:C.s2,color:canUndo?C.text:C.hint,fontFamily:C.sans,fontSize:11,cursor:canUndo?'pointer':'default',opacity:canUndo?1:0.4 }}
              >
                ↩ Undo
              </button>
              <button
                onClick={clearDraw}
                disabled={pointCount === 0}
                style={{ flex:1,padding:'6px 0',borderRadius:2,border:`1px solid ${C.brd}`,background:C.s2,color:pointCount>0?C.red:C.hint,fontFamily:C.sans,fontSize:11,cursor:pointCount>0?'pointer':'default',opacity:pointCount>0?1:0.4 }}
              >
                ✕ Clear
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Misuse type */}
      <div style={sec}>
        {lbl('Misuse type')}
        <select value={misuseType} onChange={e => upd('misuseType')(e.target.value)} style={selStyle}>
          <option value="all">All types</option>
          <option value="vacancy">Structural vacancy</option>
          <option value="tourist">Illegal tourist use</option>
          <option value="speculative">Speculative withholding</option>
          <option value="office">Illegal office conversion</option>
        </select>
      </div>

      {/* Confidence */}
      <div style={sec}>
        {lbl('Minimum confidence')}
        <div style={{ display:'grid',gridTemplateColumns:'1fr 1fr',gap:6 }}>
          {(['all','medium+','high only','watch'] as const).map(v => {
            const labels: Record<string, string> = { all:'All', 'medium+':'Medium+', 'high only':'High only', watch:'Watch' };
            const active = minConf === v;
            return (
              <button key={v} onClick={() => upd('minConf')(v)} style={{ padding:'8px 4px',borderRadius:2,border:active?`1px solid ${C.accent}`:`1px solid ${C.brd}`,background:active?C.acDim:C.s2,color:active?C.accent:C.muted,fontFamily:C.sans,fontSize:12,fontWeight:active?600:400,cursor:'pointer',transition:'all 0.12s' }}>
                {labels[v]}
              </button>
            );
          })}
        </div>
      </div>

      {/* Live preview */}
      <div style={sec}>
        {lbl('Query preview')}
        <div style={{ display:'flex',alignItems:'baseline',gap:8 }}>
          <span style={{ fontFamily:C.mono,fontSize:30,fontWeight:700,color:drawIncomplete?C.hint:wouldBlock?C.red:C.accent }}>
            {drawIncomplete ? '—' : wouldBlock ? '—' : valid.length}
          </span>
          <span style={{ fontFamily:C.sans,fontSize:13,color:C.muted }}>
            {drawIncomplete ? 'draw a polygon' : wouldBlock ? 'blocked' : 'clusters match'}
          </span>
        </div>
        {!wouldBlock && !drawIncomplete && (
          <div style={{ fontFamily:C.mono,fontSize:10,color:C.hint,marginTop:4 }}>
            {totalProps.toLocaleString()} properties total · min. 500 each
          </div>
        )}
        {wouldBlock && drawHasPolygon && (
          <div style={{ fontFamily:C.mono,fontSize:10,color:C.red,marginTop:4 }}>{blockReason}</div>
        )}
        {wouldBlock && !useDrawMode && raw.length > 0 && (
          <div style={{ fontFamily:C.mono,fontSize:10,color:C.red,marginTop:4 }}>{blockReason}</div>
        )}
      </div>

      {/* Error from last run */}
      {queryResult?.blocked && (
        <div style={{ margin:'10px 16px 0',padding:10,background:C.redBg,border:`1px solid ${C.redBrd}`,borderRadius:2,fontFamily:C.sans,fontSize:11,color:C.red,lineHeight:1.5 }}>
          <strong>Query rejected:</strong> {queryResult.reason}
        </div>
      )}

      <button
        onClick={runQuery}
        disabled={runDisabled}
        style={{ margin:'14px 16px 4px',padding:'10px 12px',borderRadius:2,border:'none',background:C.accent,color:'#FFF8F4',fontFamily:C.sans,fontSize:13,fontWeight:600,cursor:runDisabled?'not-allowed':'pointer',opacity:runDisabled?0.4:1,transition:'opacity 0.15s' }}
      >
        Run query →
      </button>

      <div style={{ margin:'8px 16px 16px',padding:10,background:C.grnBg,border:`1px solid ${C.grnBrd}`,borderRadius:2,display:'flex',gap:8,alignItems:'flex-start' }}>
        <svg width="13" height="13" viewBox="0 0 16 16" fill="none" style={{ flexShrink:0,marginTop:1 }}><path d="M8 1L14 4v5c0 3.3-2.7 5.7-6 6.5C4.7 14.7 2 12.3 2 9V4L8 1z" fill={C.green} opacity="0.7"/><path d="M5.5 8l2 2 3-3" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/></svg>
        <span style={{ fontFamily:C.sans,fontSize:11,color:C.green,lineHeight:1.6 }}>Results shown only for groups of 500+ properties. No individual data accessible.</span>
      </div>
    </div>
  );
}

/* ─── Inspector ─── */
function InspectorPage({ onShowToast }: { onShowToast:(m:string)=>void }) {
  const {
    activeClusters, activeQuery, hasRunQuery, resetFilter, updateCluster,
    useDrawMode, drawnPolygon, inProgressPoints, addDrawPoint, closePolygon,
  } = useAppState();
  const [sel, setSel] = useState<number|null>(null);
  const [fitBoundsKey, setFitBoundsKey] = useState(0);
  const [sortBy, setSortBy]             = useState<'score'|'props'|'conf'|'decision'>('score');
  const [statusFilter, setStatusFilter] = useState<'all'|'awaiting'|'referred'|'dismissed'|'pending'>('all');
  const [hovered, setHovered]           = useState<number|null>(null);
  const [isLoading, setIsLoading]       = useState(false);

  const selRef = useRef<number | null>(null);
  selRef.current = sel;

  // Re-fit map when activeClusters change after a query
  useEffect(() => { if (hasRunQuery) setFitBoundsKey(k => k + 1); }, [activeClusters, hasRunQuery]);
  // Reset selection when results change
  useEffect(() => { setSel(null); }, [activeClusters]);

  // 600 ms loading skeleton after each new query result set
  useEffect(() => {
    if (!hasRunQuery) return;
    setIsLoading(true);
    const t = setTimeout(() => setIsLoading(false), 600);
    return () => clearTimeout(t);
  }, [activeClusters]); // eslint-disable-line react-hooks/exhaustive-deps

  // ↑/↓ keyboard navigation through cluster list
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (selRef.current === null) return;
      if (e.target instanceof HTMLTextAreaElement || e.target instanceof HTMLInputElement) return;
      if (e.key === 'ArrowUp')   { e.preventDefault(); setSel(Math.max(0, selRef.current - 1)); }
      if (e.key === 'ArrowDown') { e.preventDefault(); setSel(Math.min(activeClusters.length - 1, selRef.current + 1)); }
    };
    document.addEventListener('keydown', handler);
    return () => document.removeEventListener('keydown', handler);
  }, [activeClusters.length]);

  const navigate = (dir: 1 | -1) => {
    if (sel === null) return;
    setSel(Math.max(0, Math.min(activeClusters.length - 1, sel + dir)));
  };

  const clusters = activeClusters;

  const filterCounts = {
    all:       clusters.length,
    awaiting:  clusters.filter(c => !c.decision).length,
    referred:  clusters.filter(c => c.decision === 'referred').length,
    dismissed: clusters.filter(c => c.decision === 'dismissed').length,
    pending:   clusters.filter(c => c.decision === 'pending').length,
  };

  const displayItems = clusters
    .map((c, originalIndex) => ({ c, originalIndex }))
    .filter(({ c }) => {
      if (statusFilter === 'awaiting')  return !c.decision;
      if (statusFilter === 'referred')  return c.decision === 'referred';
      if (statusFilter === 'dismissed') return c.decision === 'dismissed';
      if (statusFilter === 'pending')   return c.decision === 'pending';
      return true;
    })
    .sort((a, b) => {
      if (sortBy === 'score')    return b.c.score - a.c.score;
      if (sortBy === 'props')    return b.c.props - a.c.props;
      if (sortBy === 'conf')     { const o: Record<string,number> = { high:0, medium:1, watch:2 }; return (o[a.c.conf]??2)-(o[b.c.conf]??2); }
      if (sortBy === 'decision') return (b.c.audit.length > 0 ? 1 : 0)-(a.c.audit.length > 0 ? 1 : 0);
      return 0;
    });

  const highConf = clusters.filter(c => c.conf === 'high').length;
  const pending = clusters.filter(c => !c.decision).length;
  const total = clusters.reduce((s, c) => s + c.props, 0);

  const today = new Date('2026-04-30');
  const srcs = [
    { name:'Utility',   lastUpdate:'8 Apr',  daysAgo: Math.floor((today.getTime()-new Date('2026-04-08').getTime())/86400000) },
    { name:'Listings',  lastUpdate:'25 Apr', daysAgo: Math.floor((today.getTime()-new Date('2026-04-25').getTime())/86400000) },
    { name:'Cadastre',  lastUpdate:'12 Mar', daysAgo: Math.floor((today.getTime()-new Date('2026-03-12').getTime())/86400000) },
  ];
  const stale = srcs.filter(s => s.daysAgo > 35);

  // Active filter chips (only shown after first successful query)
  const chips: { label: string; field: keyof typeof activeQuery }[] = activeQuery ? [
    ...(activeQuery.area !== 'all'       ? [{ label: AREA_LABELS[activeQuery.area] ?? activeQuery.area, field: 'area' as const }] : []),
    ...(activeQuery.misuseType !== 'all' ? [{ label: TYPE_LABELS[activeQuery.misuseType] ?? activeQuery.misuseType, field: 'misuseType' as const }] : []),
    ...(activeQuery.minConf !== 'all'    ? [{ label: CONF_LABELS[activeQuery.minConf] ?? activeQuery.minConf, field: 'minConf' as const }] : []),
  ] : [];

  const districtLabel = activeQuery && activeQuery.area !== 'all'
    ? (AREA_LABELS[activeQuery.area] ?? activeQuery.area)
    : 'Barcelona — all districts';

  return (
    <div style={{ display:'flex',flexDirection:'column',gap:16 }}>
      {stale.length > 0 && (
        <div style={{ display:'flex',gap:12,alignItems:'flex-start',padding:14,background:C.ambBg,border:`1px solid ${C.ambBrd}`,borderRadius:2 }}>
          <span style={{ fontSize:15,flexShrink:0 }}>⚠</span>
          <div style={{ fontFamily:C.sans,fontSize:13,color:C.amber,lineHeight:1.55 }}>
            <strong>Data freshness warning:</strong> {stale.map(s=>s.name).join(', ')} {stale.length===1?'has':'have'} not been updated in over 35 days.
            <div style={{ marginTop:6,fontFamily:C.mono,fontSize:11,opacity:0.75 }}>{stale.map(s=><div key={s.name}>· {s.name}: last updated {s.lastUpdate} ({s.daysAgo} days ago)</div>)}</div>
          </div>
        </div>
      )}

      {/* Stat cards */}
      <div style={{ display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:12 }}>
        {statCard('Clusters Flagged', clusters.length, districtLabel)}
        {statCard('Properties Covered', total.toLocaleString(), 'across matched clusters')}
        {statCard('High Confidence', highConf, 'clusters', C.red)}
        {statCard('Awaiting Decision', pending, 'clusters', C.amber)}
      </div>

      {/* Map */}
      {panel(<>
        {pHead(
          'Cluster Map',
          `${districtLabel} · ${clusters.length} cluster${clusters.length !== 1 ? 's' : ''}`,
          <span style={{ fontFamily:C.mono,fontSize:10,padding:'4px 10px',background:C.s2,border:`1px solid ${C.brd}`,borderRadius:2,color:C.hint }}>click polygon to inspect</span>,
        )}
        <LeafletClusterMap
          clusters={clusters}
          selectedIndex={sel}
          onSelectCluster={setSel}
          fitBoundsKey={fitBoundsKey}
          hoveredIndex={hovered}
          onHoverCluster={setHovered}
          drawMode={useDrawMode}
          inProgressPoints={inProgressPoints}
          drawnPolygon={drawnPolygon}
          onAddPoint={addDrawPoint}
          onClosePolygon={closePolygon}
        />
      </>)}

      {/* Results + Detail */}
      <div style={{ display:'grid',gridTemplateColumns:'1fr 1fr',gap:16 }}>
        {panel(<>
          {/* Header */}
          <div style={{ borderBottom:`1px solid ${C.brd}` }}>
            {/* Row 1: title + sort */}
            <div style={{ padding:'14px 18px 8px', display:'flex', alignItems:'center', justifyContent:'space-between', gap:8 }}>
              <div style={{ fontFamily:C.sans, fontSize:13, fontWeight:600, color:C.text, letterSpacing:'-0.01em' }}>Query Results</div>
              <div style={{ display:'flex', alignItems:'center', gap:8, flexShrink:0 }}>
                {mono(`${displayItems.length}${displayItems.length !== clusters.length ? `/${clusters.length}` : ''} clusters`, C.muted)}
                <select
                  value={sortBy}
                  onChange={e => setSortBy(e.target.value as typeof sortBy)}
                  style={{ padding:'3px 7px', borderRadius:2, border:`1px solid ${C.brd}`, background:C.s2, color:C.muted, fontFamily:C.mono, fontSize:10, outline:'none', cursor:'pointer' }}
                >
                  <option value="score">Score ↓</option>
                  <option value="props">Properties ↓</option>
                  <option value="conf">Confidence</option>
                  <option value="decision">Decision ↓</option>
                </select>
              </div>
            </div>
            {/* Row 2: status filter tabs */}
            <div style={{ padding:'0 18px 9px', display:'flex', gap:3, flexWrap:'wrap' }}>
              {(['all','awaiting','referred','dismissed','pending'] as const).map(f => {
                const active = statusFilter === f;
                const count  = filterCounts[f];
                const label  = { all:'All', awaiting:'Awaiting', referred:'Referred', dismissed:'Dismissed', pending:'Pending' }[f];
                const fc     = f === 'awaiting' ? C.red : f === 'referred' ? C.blue : f === 'dismissed' ? C.amber : f === 'pending' ? C.green : C.accent;
                const bg     = f === 'all' ? C.acDim : fc + '18';
                const brd    = f === 'all' ? C.acBrd : fc + '55';
                return (
                  <button
                    key={f}
                    onClick={() => setStatusFilter(f)}
                    style={{ display:'inline-flex', alignItems:'center', gap:4, padding:'4px 8px', borderRadius:2, border:`1px solid ${active ? brd : C.brd}`, background:active ? bg : 'transparent', color:active ? fc : C.hint, fontFamily:C.mono, fontSize:10, fontWeight:active ? 600 : 400, cursor:'pointer' }}
                  >
                    {label}
                    <span style={{ fontFamily:C.mono, fontSize:9, opacity:0.75 }}>{count}</span>
                  </button>
                );
              })}
            </div>
            {/* Row 3: active filter chips */}
            {chips.length > 0 && (
              <div style={{ padding:'0 18px 9px', display:'flex', gap:6, flexWrap:'wrap' }}>
                {chips.map(({ label, field }) => (
                  <button key={field} onClick={() => resetFilter(field)} style={{ display:'inline-flex',alignItems:'center',gap:5,padding:'3px 8px',borderRadius:2,border:`1px solid ${C.acBrd}`,background:C.acDim,color:C.accent,fontFamily:C.mono,fontSize:10,fontWeight:600,cursor:'pointer',letterSpacing:'0.04em' }}>
                    {label}
                    <span style={{ fontSize:12,lineHeight:1,marginTop:-1 }}>×</span>
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Cluster list / skeleton / empty state */}
          <div style={{ maxHeight:320, overflowY:'auto' }}>
            {isLoading ? (
              /* 600ms skeleton */
              <>
                {[0,1,2,3].map(i => (
                  <div key={i} style={{ padding:'14px 18px', borderBottom:`1px solid ${C.brd}`, display:'flex', gap:12, alignItems:'flex-start' }}>
                    <div style={{ flex:1, display:'flex', flexDirection:'column', gap:7 }}>
                      <div style={{ width:72, height:11, borderRadius:2, background:C.s3, animation:`skel 1.4s ease-in-out ${i * 0.08}s infinite` }} />
                      <div style={{ width:160, height:9, borderRadius:2, background:C.s3, animation:`skel 1.4s ease-in-out ${i * 0.08 + 0.1}s infinite` }} />
                      <div style={{ width:96, height:3, borderRadius:2, background:C.s3, animation:`skel 1.4s ease-in-out ${i * 0.08 + 0.2}s infinite` }} />
                    </div>
                    <div style={{ width:52, height:22, borderRadius:2, background:C.s3, animation:`skel 1.4s ease-in-out ${i * 0.08 + 0.05}s infinite` }} />
                  </div>
                ))}
              </>
            ) : displayItems.length === 0 ? (
              /* Empty state */
              <div style={{ padding:'40px 24px', textAlign:'center', display:'flex', flexDirection:'column', alignItems:'center', gap:8 }}>
                <svg width="28" height="28" viewBox="0 0 24 24" fill="none">
                  <circle cx="11" cy="11" r="7" stroke={C.hint} strokeWidth="1.5"/>
                  <path d="M17 17l3.5 3.5" stroke={C.hint} strokeWidth="1.5" strokeLinecap="round"/>
                  {clusters.length === 0
                    ? <path d="M8.5 11h5M11 8.5v5" stroke={C.hint} strokeWidth="1.3" strokeLinecap="round"/>
                    : <path d="M8.5 11h5" stroke={C.hint} strokeWidth="1.3" strokeLinecap="round"/>}
                </svg>
                <div style={{ fontFamily:C.sans, fontSize:13, color:C.muted, fontWeight:600 }}>
                  {clusters.length === 0 ? 'No clusters match' : `No ${statusFilter} clusters`}
                </div>
                <div style={{ fontFamily:C.sans, fontSize:12, color:C.hint, maxWidth:230, lineHeight:1.5 }}>
                  {clusters.length === 0
                    ? 'No clusters match — try widening confidence or area'
                    : 'Clear the status filter to see all results'}
                </div>
                {statusFilter !== 'all' && clusters.length > 0 && (
                  <button onClick={() => setStatusFilter('all')} style={{ marginTop:4, padding:'5px 14px', borderRadius:2, border:`1px solid ${C.brd}`, background:C.s2, color:C.muted, fontFamily:C.sans, fontSize:12, cursor:'pointer' }}>Show all</button>
                )}
              </div>
            ) : (
              /* Cluster rows */
              displayItems.map(({ c, originalIndex }) => {
                const active  = sel === originalIndex;
                const isHov   = hovered === originalIndex;
                const bc      = c.conf === 'high' ? C.red : c.conf === 'medium' ? C.amber : C.blue;
                return (
                  <button
                    key={c.id}
                    onClick={() => setSel(originalIndex)}
                    onMouseEnter={() => setHovered(originalIndex)}
                    onMouseLeave={() => setHovered(null)}
                    style={{ width:'100%', padding:'14px 18px', display:'flex', alignItems:'flex-start', justifyContent:'space-between', gap:12, background:active ? C.s2 : isHov ? C.s3 + '88' : 'transparent', cursor:'pointer', border:'none', borderBottom:`1px solid ${C.brd}`, borderLeft:`2px solid ${active ? C.accent : isHov ? C.brd2 : 'transparent'}`, textAlign:'left', transition:'background 0.1s, border-color 0.1s' }}
                  >
                    <div style={{ flex:1, minWidth:0 }}>
                      <div style={{ display:'flex', alignItems:'center', gap:6, marginBottom:4 }}>
                        {mono(c.id, C.text, 13)}
                        <span style={{ color:C.hint }}>·</span>
                        <span style={{ fontFamily:C.sans, fontSize:12, color:C.muted, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{c.type}</span>
                      </div>
                      <div style={{ fontFamily:C.mono, fontSize:10, color:C.hint, marginBottom:8 }}>
                        {c.area} · <span style={{ color:C.muted }}>{c.props.toLocaleString()}</span> props
                      </div>
                      <div style={{ display:'flex', alignItems:'center', gap:8 }}>
                        <div style={{ width:80, height:3, borderRadius:2, background:C.s3, overflow:'hidden' }}>
                          <div style={{ width:`${Math.round(c.score*100)}%`, height:'100%', background:bc, borderRadius:2 }}/>
                        </div>
                        {mono(`${Math.round(c.score*100)}%`, C.muted)}
                      </div>
                    </div>
                    <div style={{ display:'flex', flexDirection:'column', gap:4, flexShrink:0 }}>
                      <Pill t={c.conf as PT}>{c.conf}</Pill>
                      {c.decision && <Pill t={c.decision as PT}>{c.decision}</Pill>}
                    </div>
                  </button>
                );
              })
            )}
          </div>
        </>)}
        <ClusterDetailPanel
          cluster={sel !== null ? clusters[sel] : null}
          selIndex={sel}
          totalClusters={clusters.length}
          onUpdateCluster={u => { if (sel !== null) updateCluster(clusters[sel].id, u); }}
          onShowToast={onShowToast}
          onNavigate={navigate}
        />
      </div>
    </div>
  );
}

/* ─── Signal tooltip component ─── */
function SignalTip({ source, explain }: { source: string; explain: string }) {
  const [show, setShow] = useState(false);
  return (
    <span style={{ position:'relative', display:'inline-flex', verticalAlign:'middle', marginLeft:4 }}>
      <button
        onMouseEnter={() => setShow(true)}
        onMouseLeave={() => setShow(false)}
        style={{ background:'none', border:'none', cursor:'pointer', padding:0, lineHeight:1, color:C.hint, display:'flex', alignItems:'center' }}
      >
        <svg width="13" height="13" viewBox="0 0 14 14" fill="none">
          <circle cx="7" cy="7" r="6.25" stroke={C.hint} strokeWidth="1.1"/>
          <path d="M7 6v4" stroke={C.hint} strokeWidth="1.2" strokeLinecap="round"/>
          <circle cx="7" cy="4.5" r="0.7" fill={C.hint}/>
        </svg>
      </button>
      {show && (
        <div style={{ position:'absolute', bottom:'calc(100% + 6px)', left:'50%', transform:'translateX(-50%)', width:232, padding:'9px 11px', background:C.surf, border:`1px solid ${C.brd2}`, borderRadius:2, zIndex:400, pointerEvents:'none', boxShadow:'0 4px 14px rgba(0,0,0,0.22)' }}>
          <div style={{ fontFamily:C.mono, fontSize:10, color:C.accent, fontWeight:600, marginBottom:5, letterSpacing:'0.06em', textTransform:'uppercase' as const }}>Source</div>
          <div style={{ fontFamily:C.sans, fontSize:11, color:C.muted, marginBottom:7 }}>{source}</div>
          <div style={{ fontFamily:C.sans, fontSize:11, color:C.text, lineHeight:1.55 }}>{explain}</div>
        </div>
      )}
    </span>
  );
}

const SIG_META: Record<'water'|'listings'|'cadastre'|'residents', { label:string; source:string; explain:string }> = {
  water:     { label:'% below 5 L/day (water)',     source:'Utility metering (AGBAR)',              explain:'Share of residential units with daily water consumption under 5 litres — a strong proxy for structural vacancy. Normal occupied homes consume 80–120 L/day.' },
  listings:  { label:'% with active listings',       source:'Short-term rental platforms (scraped)', explain:'Proportion of units appearing in active tourist-let databases in the past 90 days. High values indicate likely illegal tourist use.' },
  cadastre:  { label:'% residential zoning match',   source:'Cadastre (Generalitat de Catalunya)',   explain:'Share of units whose cadastral classification matches residential use. Low values may signal illegal office or commercial conversion.' },
  residents: { label:'% no registered resident',     source:'Municipal Residents Register (Padró)',  explain:'Units with no registered resident. Cross-referenced with low water use and active listings to identify speculative withholding.' },
};

const DISTRICT_AVG: Record<'water'|'listings'|'cadastre'|'residents', number> = {
  water: 48, listings: 31, cadastre: 67, residents: 38,
};

const DATA_SRCS: { name:string; date:Date; label:string }[] = [
  { name:'Utility',  date:new Date('2026-04-08'), label:'8 Apr 2026'  },
  { name:'Listings', date:new Date('2026-04-25'), label:'25 Apr 2026' },
  { name:'Cadastre', date:new Date('2026-03-12'), label:'12 Mar 2026' },
];
const PANEL_TODAY = new Date('2026-04-30');

/* ─── Cluster detail ─── */
function ClusterDetailPanel({
  cluster, selIndex, totalClusters, onUpdateCluster, onShowToast, onNavigate,
}: {
  cluster: Cluster | null;
  selIndex: number | null;
  totalClusters: number;
  onUpdateCluster: (u: Partial<Cluster>) => void;
  onShowToast: (m: string) => void;
  onNavigate: (dir: 1 | -1) => void;
}) {
  const { addAuditEntry, session } = useAppState();
  const [dec, setDec]           = useState<'referred'|'dismissed'|'pending'|null>(null);
  const [notes, setNotes]       = useState('');
  const [followNote, setFollowNote] = useState('');
  const [modal, setModal]       = useState<{ type:string; notes:string; ts:string } | null>(null);

  const sigC: string[] = [C.blue, C.amber, C.green, C.red];
  const sigK: Array<'water'|'listings'|'cadastre'|'residents'> = ['water','listings','cadastre','residents'];

  useEffect(() => { setDec(null); setNotes(''); setFollowNote(''); }, [cluster?.id]);

  if (!cluster) return panel(
    <>
      <div style={{ padding:'14px 20px', borderBottom:`1px solid ${C.brd}` }}>
        <span style={{ fontFamily:C.sans, fontSize:13, fontWeight:600, color:C.text, letterSpacing:'-0.01em' }}>Cluster Details</span>
      </div>
      <div style={{ display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', height:240, padding:32, textAlign:'center' }}>
        <div style={{ width:48, height:48, borderRadius:2, background:C.s2, border:`1px solid ${C.brd}`, display:'flex', alignItems:'center', justifyContent:'center', fontSize:20, marginBottom:14 }}>⬡</div>
        <p style={{ fontFamily:C.sans, fontSize:13, color:C.muted, marginBottom:6 }}>No cluster selected</p>
        <p style={{ fontFamily:C.sans, fontSize:12, color:C.hint, maxWidth:240 }}>Click a cluster on the map or select one from the list to view signal data.</p>
      </div>
    </>
  );

  const nowTs = () => new Date().toLocaleDateString('en-GB').split('/').reverse().join('-') + ' ' + new Date().toTimeString().slice(0,5);
  const activeUser = session?.userId ?? 'a3f7…';

  const logDec = () => {
    if (!dec) return;
    if (dec === 'referred' && notes.trim().length < 20) return;
    const label = dec === 'referred' ? 'Referred for physical inspection' : dec === 'dismissed' ? 'Dismissed — insufficient evidence' : 'Set to pending — monitoring';
    const ts = nowTs();
    const fullAction = notes.trim() ? `${label} — Note: ${notes.trim()}` : label;
    onUpdateCluster({ decision:dec, audit:[...cluster.audit, { user:activeUser, ts, action:fullAction }] });
    addAuditEntry({ id:`DEC-${Date.now()}`, ts, user:activeUser, cluster:cluster.id, qtype:cluster.type, conf:cluster.conf, action:fullAction, status:dec });
    setModal({ type:label, notes:notes.trim(), ts });
    setDec(null); setNotes('');
  };

  const logFollowUp = () => {
    if (followNote.trim().length < 5) return;
    const ts = nowTs();
    const action = `Follow-up note: ${followNote.trim()}`;
    onUpdateCluster({ audit:[...cluster.audit, { user:activeUser, ts, action }] });
    addAuditEntry({ id:`NOTE-${Date.now()}`, ts, user:activeUser, cluster:cluster.id, qtype:cluster.type, conf:cluster.conf, action, status:'pending' });
    setFollowNote('');
    onShowToast('Follow-up note added to audit trail');
  };

  const isDecided = !!cluster.decision;
  const firstEntry = cluster.audit[0];
  const followUps = isDecided ? cluster.audit.slice(1) : [];
  const decisionLabel: Record<string, string> = {
    referred: 'Referred for physical inspection',
    dismissed: 'Dismissed — insufficient evidence',
    pending: 'Set to pending — monitoring',
  };
  let lockNote = '';
  if (firstEntry?.action) {
    const idx = firstEntry.action.indexOf(' — Note: ');
    if (idx !== -1) lockNote = firstEntry.action.slice(idx + 9);
  }

  const noteError = dec === 'referred' && notes.trim().length < 20
    ? `Note required (${notes.trim().length}/20 chars minimum)`
    : null;
  const canLog = !!dec && !noteError;

  const navBtn = (dir: 1 | -1) => {
    const disabled = selIndex === null || (dir === -1 ? selIndex <= 0 : selIndex >= totalClusters - 1);
    return (
      <button
        onClick={() => onNavigate(dir)}
        disabled={disabled}
        title={dir === -1 ? 'Previous cluster (↑)' : 'Next cluster (↓)'}
        style={{ width:24, height:24, border:`1px solid ${C.brd}`, borderRadius:2, background:C.s2, color:disabled ? C.hint : C.text, cursor:disabled ? 'not-allowed' : 'pointer', display:'flex', alignItems:'center', justifyContent:'center', opacity:disabled ? 0.35 : 1, flexShrink:0 }}
      >
        <svg width="10" height="10" viewBox="0 0 10 10" fill="none">
          {dir === -1
            ? <path d="M2 6.5L5 3.5L8 6.5" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"/>
            : <path d="M2 3.5L5 6.5L8 3.5" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"/>}
        </svg>
      </button>
    );
  };

  return (
    <>
      {panel(<>
        {/* Header */}
        <div style={{ padding:'14px 20px', borderBottom:`1px solid ${C.brd}`, display:'flex', alignItems:'flex-start', justifyContent:'space-between', gap:12 }}>
          <div style={{ flex:1, minWidth:0 }}>
            {mono(cluster.id, C.text, 14)}
            <div style={{ fontFamily:C.sans, fontSize:12, color:C.muted, marginTop:3 }}>{cluster.area}</div>
          </div>
          <div style={{ display:'flex', alignItems:'center', gap:5, flexShrink:0 }}>
            {cluster.decision && <Pill t={cluster.decision as PT}>{cluster.decision}</Pill>}
            {navBtn(-1)}
            {navBtn(1)}
          </div>
        </div>

        <div style={{ maxHeight:580, overflowY:'auto' }}>
          {/* Metadata grid */}
          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'0 1px', background:C.brd }}>
            {([
              ['Misuse Type', cluster.type],
              ['Confidence', <Pill t={cluster.conf as PT}>{cluster.conf}</Pill>],
              ['Properties', cluster.props.toLocaleString()],
              ['Score', `${Math.round(cluster.score * 100)}%`],
            ] as Array<[string, unknown]>).map(([l, v]) => (
              <div key={String(l)} style={{ padding:'14px 18px', background:C.surf, borderBottom:`1px solid ${C.brd}` }}>
                {lbl(String(l))}
                <div style={{ fontFamily:typeof v === 'string' ? C.mono : undefined, fontSize:13, fontWeight:600, color:C.text }}>{v}</div>
              </div>
            ))}
          </div>

          {/* Data sources */}
          <div style={{ padding:'11px 18px', borderBottom:`1px solid ${C.brd}` }}>
            {lbl('Data Sources')}
            <div style={{ display:'flex', gap:14, marginTop:6, flexWrap:'wrap' }}>
              {DATA_SRCS.map(s => {
                const daysAgo = Math.floor((PANEL_TODAY.getTime() - s.date.getTime()) / 86400000);
                const stale = daysAgo > 35;
                return (
                  <div key={s.name} style={{ display:'flex', alignItems:'center', gap:5 }}>
                    <span style={{ fontFamily:C.mono, fontSize:10, color:C.hint, letterSpacing:'0.05em' }}>{s.name.toUpperCase()}</span>
                    <span style={{ fontFamily:C.mono, fontSize:11, color:stale ? C.amber : C.muted, fontWeight:stale ? 600 : 400 }}>{s.label}</span>
                    {stale && (
                      <span title="Classification may use outdated data" style={{ display:'inline-flex', alignItems:'center', cursor:'help' }}>
                        <svg width="12" height="12" viewBox="0 0 16 16" fill="none">
                          <path d="M8 2.5L13.5 12.5H2.5L8 2.5Z" stroke={C.amber} strokeWidth="1.3" strokeLinejoin="round"/>
                          <path d="M8 6.5v3" stroke={C.amber} strokeWidth="1.4" strokeLinecap="round"/>
                          <circle cx="8" cy="11.2" r="0.7" fill={C.amber}/>
                        </svg>
                      </span>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Signal profile */}
          <div style={{ padding:'16px 18px', borderBottom:`1px solid ${C.brd}` }}>
            <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:14 }}>
              {lbl('Signal Profile')}
              {mono('aggregated · 500+ props')}
            </div>
            <div style={{ display:'flex', flexDirection:'column', gap:14 }}>
              {sigK.map((key, i) => {
                const meta = SIG_META[key];
                const val  = cluster.signals[key];
                const avg  = DISTRICT_AVG[key];
                return (
                  <div key={key}>
                    <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:5 }}>
                      <span style={{ display:'inline-flex', alignItems:'center', fontFamily:C.sans, fontSize:11, color:C.muted }}>
                        {meta.label}
                        <SignalTip source={meta.source} explain={meta.explain} />
                      </span>
                      <span style={{ fontFamily:C.mono, fontSize:12, fontWeight:700, color:sigC[i] }}>{val}%</span>
                    </div>
                    {/* Bar track with district-average marker */}
                    <div style={{ position:'relative', height:4, borderRadius:2, background:C.s3 }}>
                      <div style={{ width:`${val}%`, height:'100%', background:sigC[i], borderRadius:2, opacity:0.85 }} />
                      <div
                        title={`District avg: ${avg}%`}
                        style={{ position:'absolute', top:-2, bottom:-2, width:2, borderRadius:1, background:C.text, opacity:0.38, left:`${avg}%`, transform:'translateX(-50%)' }}
                      />
                    </div>
                    <div style={{ display:'flex', justifyContent:'flex-end', marginTop:3 }}>
                      <span style={{ fontFamily:C.mono, fontSize:9, color:C.hint }}>district avg {avg}%</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Analysis summary */}
          <div style={{ padding:'14px 18px', borderBottom:`1px solid ${C.brd}` }}>
            {lbl('Analysis Summary')}
            <p style={{ fontFamily:C.sans, fontSize:12, color:C.muted, lineHeight:1.65, margin:0 }}>{cluster.summary}</p>
          </div>

          {/* Audit trail */}
          <div style={{ borderBottom:`1px solid ${C.brd}` }}>
            <div style={{ padding:'10px 18px' }}>{lbl('Audit Trail')}</div>
            {cluster.audit.length > 0 ? cluster.audit.map((e, i) => (
              <div key={i} style={{ display:'flex', alignItems:'center', gap:10, padding:'8px 18px', borderBottom:`1px solid ${C.brd}` }}>
                {mono(e.user, C.accent)}
                <span style={{ flex:1, fontFamily:C.sans, fontSize:11, color:C.muted }}>{e.action}</span>
                {mono(e.ts)}
              </div>
            )) : (
              <div style={{ padding:'8px 18px' }}>{mono('No previous activity.')}</div>
            )}
          </div>

          {/* Decision section — locked or open */}
          {isDecided ? (
            <div style={{ padding:'16px 18px', display:'flex', flexDirection:'column', gap:12 }}>
              {lbl('Decision Record')}
              {/* Locked card */}
              <div style={{ borderRadius:2, border:`1px solid ${C.brd2}`, background:C.s2, overflow:'hidden' }}>
                <div style={{ display:'flex', alignItems:'center', gap:8, padding:'8px 14px', borderBottom:`1px solid ${C.brd}`, background:C.s3 }}>
                  <svg width="13" height="13" viewBox="0 0 16 16" fill="none">
                    <rect x="3" y="7" width="10" height="8" rx="1" stroke={C.hint} strokeWidth="1.3"/>
                    <path d="M5.5 7V5a2.5 2.5 0 015 0v2" stroke={C.hint} strokeWidth="1.3" strokeLinecap="round"/>
                    <circle cx="8" cy="11" r="1" fill={C.hint}/>
                  </svg>
                  <span style={{ fontFamily:C.mono, fontSize:10, color:C.hint, letterSpacing:'0.08em', textTransform:'uppercase' as const }}>Logged — immutable</span>
                </div>
                <div style={{ padding:'12px 14px', display:'flex', flexDirection:'column', gap:7 }}>
                  <div>
                    {lbl('Decision')}
                    <Pill t={cluster.decision as PT}>{decisionLabel[cluster.decision] ?? cluster.decision}</Pill>
                  </div>
                  {firstEntry && (
                    <>
                      <div style={{ fontFamily:C.mono, fontSize:11, color:C.muted }}><span style={{ color:C.hint, fontSize:10 }}>LOGGED BY </span><span style={{ color:C.accent }}>{firstEntry.user}</span></div>
                      <div style={{ fontFamily:C.mono, fontSize:11, color:C.muted }}><span style={{ color:C.hint, fontSize:10 }}>TIMESTAMP </span>{firstEntry.ts}</div>
                    </>
                  )}
                  {lockNote && (
                    <div style={{ marginTop:2, padding:'8px 10px', borderRadius:2, background:C.s3, fontFamily:C.sans, fontSize:11, color:C.muted, fontStyle:'italic', lineHeight:1.55 }}>{lockNote}</div>
                  )}
                </div>
              </div>

              {/* Existing follow-up notes */}
              {followUps.length > 0 && (
                <div>
                  {lbl('Follow-up Notes')}
                  <div style={{ display:'flex', flexDirection:'column', gap:6, marginTop:6 }}>
                    {followUps.map((e, i) => (
                      <div key={i} style={{ padding:'8px 10px', borderRadius:2, background:C.s2, border:`1px solid ${C.brd}` }}>
                        <div style={{ fontFamily:C.mono, fontSize:10, color:C.hint, marginBottom:4 }}>{e.ts} · {e.user}</div>
                        <div style={{ fontFamily:C.sans, fontSize:11, color:C.text, lineHeight:1.5 }}>
                          {e.action.startsWith('Follow-up note: ') ? e.action.slice(16) : e.action}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Add follow-up note form */}
              <div>
                {lbl('Add Follow-up Note')}
                <textarea
                  value={followNote}
                  onChange={e => setFollowNote(e.target.value.slice(0, 500))}
                  placeholder="Add a follow-up observation or note..."
                  rows={3}
                  style={{ width:'100%', padding:'8px 10px', borderRadius:2, border:`1px solid ${C.brd}`, background:C.s2, color:C.text, fontFamily:C.sans, fontSize:12, outline:'none', resize:'none', boxSizing:'border-box', marginTop:6 }}
                />
                <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginTop:6 }}>
                  <span style={{ fontFamily:C.mono, fontSize:10, color:C.hint }}>{followNote.length}/500</span>
                  <button
                    onClick={logFollowUp}
                    disabled={followNote.trim().length < 5}
                    style={{ padding:'7px 16px', borderRadius:2, border:'none', background:C.accent, color:'#FFF8F4', fontFamily:C.sans, fontSize:12, fontWeight:600, cursor:followNote.trim().length >= 5 ? 'pointer' : 'not-allowed', opacity:followNote.trim().length >= 5 ? 1 : 0.4 }}
                  >Add note →</button>
                </div>
              </div>
            </div>
          ) : (
            <div style={{ padding:'16px 18px', display:'flex', flexDirection:'column', gap:12 }}>
              {lbl('Log Decision')}
              <div style={{ display:'flex', gap:6, flexWrap:'wrap' }}>
                {(['referred','dismissed','pending'] as const).map(d => {
                  const active = dec === d;
                  const ac = d === 'dismissed' ? [C.amber,C.ambBg,C.ambBrd] : [C.blue,C.bluBg,C.bluBrd];
                  const ls = { referred:'Refer for inspection', dismissed:'Dismiss', pending:'Pending' };
                  return (
                    <button key={d} onClick={() => setDec(d)} style={{ padding:'7px 14px', borderRadius:2, border:active ? `1px solid ${ac[0]}` : `1px solid ${C.brd}`, background:active ? ac[1] : C.s2, color:active ? ac[0] : C.muted, fontFamily:C.sans, fontSize:12, fontWeight:active ? 600 : 400, cursor:'pointer', transition:'all 0.12s' }}>{ls[d]}</button>
                  );
                })}
              </div>
              <textarea
                value={notes}
                onChange={e => setNotes(e.target.value.slice(0, 500))}
                placeholder={dec === 'referred' ? 'Note required for referral (min. 20 chars)...' : 'Add context, observations, or justification...'}
                rows={3}
                disabled={!dec}
                style={{ width:'100%', padding:'8px 10px', borderRadius:2, border:`1px solid ${noteError ? C.amber : C.brd}`, background:C.s2, color:C.text, fontFamily:C.sans, fontSize:12, outline:'none', resize:'none', boxSizing:'border-box' }}
              />
              <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}>
                <span style={{ fontFamily:C.mono, fontSize:10, color:noteError ? C.amber : C.hint }}>{noteError ?? `${notes.length}/500`}</span>
              </div>
              <div style={{ padding:10, borderRadius:2, background:C.grnBg, border:`1px solid ${C.grnBrd}`, display:'flex', gap:8, alignItems:'flex-start' }}>
                <svg width="13" height="13" viewBox="0 0 16 16" fill="none" style={{ flexShrink:0, marginTop:1 }}>
                  <path d="M8 1L14 4v5c0 3.3-2.7 5.7-6 6.5C4.7 14.7 2 12.3 2 9V4L8 1z" fill={C.green} opacity="0.7"/>
                  <path d="M5.5 8l2 2 3-3" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
                <span style={{ fontFamily:C.sans, fontSize:11, color:C.green, lineHeight:1.55 }}>Decision is logged to the audit trail only. No individual property data is accessed or stored.</span>
              </div>
              <button onClick={logDec} disabled={!canLog} style={{ alignSelf:'flex-start', padding:'8px 18px', borderRadius:2, border:'none', background:C.accent, color:'#FFF8F4', fontFamily:C.sans, fontSize:12, fontWeight:600, cursor:canLog ? 'pointer' : 'not-allowed', opacity:canLog ? 1 : 0.4 }}>Log decision →</button>
            </div>
          )}
        </div>
      </>)}

      {modal && (
        <div style={{ position:'fixed', inset:0, background:'rgba(0,0,0,0.72)', display:'flex', alignItems:'center', justifyContent:'center', zIndex:100 }}>
          <div style={{ background:C.surf, border:`1px solid ${C.brd2}`, borderRadius:3, maxWidth:480, width:'90%', overflow:'hidden' }}>
            <div style={{ padding:'14px 22px', borderBottom:`1px solid ${C.brd}`, display:'flex', alignItems:'center', justifyContent:'space-between' }}>
              <span style={{ fontFamily:C.sans, fontSize:14, fontWeight:600, color:C.text, letterSpacing:'-0.01em' }}>Decision Logged</span>
              <span style={{ width:28, height:28, borderRadius:2, background:C.grnBg, color:C.green, border:`1px solid ${C.grnBrd}`, display:'flex', alignItems:'center', justifyContent:'center', fontSize:13 }}>✓</span>
            </div>
            <div style={{ padding:22, display:'flex', flexDirection:'column', gap:12 }}>
              <div style={{ padding:14, borderRadius:2, background:C.s2, border:`1px solid ${C.brd}` }}>
                {lbl('What was logged')}
                {([
                  ['Cluster', `${cluster.id} — ${cluster.area}`],
                  ['Decision', modal.type],
                  ['Timestamp', modal.ts],
                  ['Inspector', activeUser],
                ] as [string,string][]).map(([k, v]) => (
                  <div key={k} style={{ fontFamily:C.mono, fontSize:11, color:C.muted, marginBottom:4 }}>
                    <span style={{ color:C.hint }}>{k}:</span>{' '}
                    <span style={{ color:k === 'Timestamp' ? C.accent : C.text }}>{v}</span>
                  </div>
                ))}
                {modal.notes && (
                  <div style={{ marginTop:8, padding:8, borderRadius:2, background:C.s3, fontFamily:C.mono, fontSize:11, color:C.muted, fontStyle:'italic' }}>{modal.notes}</div>
                )}
              </div>
              <div style={{ padding:10, borderRadius:2, background:C.ambBg, border:`1px solid ${C.ambBrd}`, fontFamily:C.sans, fontSize:11, color:C.amber }}>
                <strong>⚠ Important:</strong> This decision has been permanently logged and cannot be edited or deleted.
              </div>
            </div>
            <div style={{ padding:'12px 22px', borderTop:`1px solid ${C.brd}`, display:'flex', justifyContent:'flex-end' }}>
              <button onClick={() => { setModal(null); onShowToast('Decision logged to audit trail'); }} style={{ padding:'8px 22px', borderRadius:2, border:'none', background:C.accent, color:'#FFF8F4', fontFamily:C.sans, fontSize:13, fontWeight:600, cursor:'pointer' }}>Close</button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}

/* ─── Audit ─── */
/* ─── Audit helpers ─── */

function parseLogTs(ts: string): Date {
  /* Handles two formats:
     "DD/MM/YYYY HH:MM"  — from context (es-ES locale)
     "YYYY-MM-DD HH:MM"  — from ClusterDetailPanel */
  const [datePart, timePart = '00:00'] = ts.split(' ');
  if (datePart.includes('/')) {
    const [dd, mm, yyyy] = datePart.split('/');
    return new Date(`${yyyy}-${mm}-${dd}T${timePart}:00`);
  }
  return new Date(`${datePart}T${timePart}:00`);
}

function clusterIdOfEntry(e: { cluster: string; clusterIds?: string[] }): string | null {
  /* A "specific cluster" row is one whose cluster field is a bare cluster ID */
  if (/^C-[A-Z0-9]+$/.test(e.cluster)) return e.cluster;
  return null;
}

function downloadCsv(rows: { id: string; ts: string; user: string; cluster: string; qtype: string; conf: string; action: string; status: string }[]) {
  const header = ['Log ID', 'Timestamp', 'User (hashed)', 'Cluster', 'Query type', 'Confidence', 'Action / Decision', 'Status'];
  const escape = (v: string) => `"${v.replace(/"/g, '""')}"`;
  const lines = [
    header.map(escape).join(','),
    ...rows.map(r => [r.id, r.ts, r.user, r.cluster, r.qtype, r.conf, r.action, r.status].map(escape).join(',')),
  ];
  const blob = new Blob([lines.join('\n')], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `audit_log_${new Date().toISOString().slice(0, 10)}.csv`;
  a.click();
  URL.revokeObjectURL(url);
}

/* ─── Cluster audit drawer ─── */
function ClusterAuditDrawer({ clusterId, onClose }: { clusterId: string; onClose: () => void }) {
  const { allClusters, auditLog } = useAppState();
  const cluster = allClusters.find(c => c.id === clusterId) ?? null;

  /* Log entries that mention this cluster */
  const queryEntries = auditLog.filter(e => e.status === 'query' && e.clusterIds?.includes(clusterId));
  const decisionEntries = auditLog.filter(e => e.cluster === clusterId);

  /* Merge and sort by timestamp desc */
  const timeline = [...queryEntries, ...decisionEntries].sort(
    (a, b) => parseLogTs(b.ts).getTime() - parseLogTs(a.ts).getTime(),
  );

  /* Internal notes from ClusterDetailPanel (.audit on cluster) */
  const internalNotes = cluster?.audit ?? [];

  const confColor = cluster
    ? (cluster.conf === 'high' ? C.red : cluster.conf === 'medium' ? C.amber : C.blue)
    : C.muted;

  return (
    <div style={{ width:320,flexShrink:0,background:C.surf,borderLeft:`1px solid ${C.brd}`,display:'flex',flexDirection:'column',height:'100%',overflow:'hidden' }}>
      {/* Header */}
      <div style={{ padding:'14px 18px',borderBottom:`1px solid ${C.brd}`,display:'flex',alignItems:'center',justifyContent:'space-between',flexShrink:0 }}>
        <div>
          <div style={{ fontFamily:C.mono,fontSize:13,fontWeight:700,color:C.text }}>{clusterId}</div>
          {cluster && <div style={{ fontFamily:C.sans,fontSize:11,color:C.muted,marginTop:2 }}>{cluster.area}</div>}
        </div>
        <button onClick={onClose} style={{ background:'none',border:'none',cursor:'pointer',color:C.muted,fontSize:18,lineHeight:1,padding:'2px 6px' }}>×</button>
      </div>

      {cluster && (
        <div style={{ padding:'10px 18px',borderBottom:`1px solid ${C.brd}`,display:'flex',gap:8,alignItems:'center',flexShrink:0 }}>
          <Pill t={cluster.conf as PT}>{cluster.conf}</Pill>
          <span style={{ fontFamily:C.sans,fontSize:11,color:C.muted,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap' }}>{cluster.type}</span>
        </div>
      )}

      <div style={{ flex:1,overflowY:'auto',padding:'14px 18px',display:'flex',flexDirection:'column',gap:20 }}>

        {/* Timeline */}
        <div>
          <div style={{ fontFamily:C.mono,fontSize:10,letterSpacing:'0.10em',textTransform:'uppercase' as const,color:C.hint,fontWeight:600,marginBottom:10 }}>Event timeline</div>
          {timeline.length === 0 ? (
            <div style={{ fontFamily:C.sans,fontSize:12,color:C.hint }}>No events recorded yet.</div>
          ) : (
            <div style={{ display:'flex',flexDirection:'column',gap:0 }}>
              {timeline.map((e, i) => {
                const isQuery = e.status === 'query';
                const dotColor = e.status === 'alert' ? C.red : e.status === 'query' ? C.accent : e.status === 'referred' ? C.blue : e.status === 'dismissed' ? C.amber : C.muted;
                return (
                  <div key={e.id} style={{ display:'flex',gap:10,paddingBottom:i < timeline.length - 1 ? 14 : 0 }}>
                    {/* Timeline rail */}
                    <div style={{ display:'flex',flexDirection:'column',alignItems:'center',flexShrink:0 }}>
                      <div style={{ width:8,height:8,borderRadius:'50%',background:dotColor,flexShrink:0,marginTop:3 }} />
                      {i < timeline.length - 1 && <div style={{ width:1,flex:1,background:C.brd,marginTop:4 }} />}
                    </div>
                    <div style={{ flex:1,minWidth:0 }}>
                      <div style={{ fontFamily:C.mono,fontSize:10,color:C.hint,marginBottom:3 }}>
                        {e.ts} · {e.user}
                      </div>
                      <div style={{ fontFamily:C.sans,fontSize:11,color:isQuery ? C.muted : C.text,lineHeight:1.5 }}>
                        {isQuery
                          ? <><span style={{ color:C.accent,fontWeight:600 }}>Query match</span> — cluster included in result set</>
                          : e.action}
                      </div>
                      <div style={{ marginTop:4 }}><Pill t={e.status === 'alert' ? 'blocked' : isQuery ? 'logged' : e.status as PT}>{e.status}</Pill></div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Internal notes */}
        {internalNotes.length > 0 && (
          <div>
            <div style={{ fontFamily:C.mono,fontSize:10,letterSpacing:'0.10em',textTransform:'uppercase' as const,color:C.hint,fontWeight:600,marginBottom:10 }}>Inspector notes</div>
            <div style={{ display:'flex',flexDirection:'column',gap:8 }}>
              {internalNotes.map((n, i) => (
                <div key={i} style={{ padding:'8px 10px',background:C.s2,borderRadius:2,borderLeft:`2px solid ${confColor}` }}>
                  <div style={{ fontFamily:C.mono,fontSize:10,color:C.hint,marginBottom:4 }}>{n.ts} · {n.user}</div>
                  <div style={{ fontFamily:C.sans,fontSize:11,color:C.text,lineHeight:1.5 }}>{n.action}</div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function AuditPage({ onShowToast: _onShowToast }: { onShowToast:(m:string)=>void }) {
  const { auditLog, session } = useAppState();
  /* Inspector sees only their own entries */
  const visibleLog = session?.role === 'inspector'
    ? auditLog.filter(e => e.user === session.userId)
    : auditLog;
  const [statusFilter, setStatusFilter] = useState('all');
  const [search, setSearch] = useState('');
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');
  const [drawerClusterId, setDrawerClusterId] = useState<string | null>(null);

  const th: React.CSSProperties = { padding:'10px 14px',textAlign:'left',fontFamily:C.mono,fontSize:10,fontWeight:600,letterSpacing:'0.10em',textTransform:'uppercase' as const,color:C.hint,borderBottom:`1px solid ${C.brd}`,whiteSpace:'nowrap' };
  const td: React.CSSProperties = { padding:'10px 14px',borderBottom:`1px solid ${C.brd}` };

  const fromDate = dateFrom ? new Date(dateFrom + 'T00:00:00') : null;
  const toDate   = dateTo   ? new Date(dateTo   + 'T23:59:59') : null;

  const filtered = visibleLog.filter(e => {
    if (statusFilter !== 'all' && e.status !== statusFilter) return false;
    const q = search.trim().toLowerCase();
    if (q) {
      const haystack = [e.id, e.cluster, e.qtype, e.user, e.action, ...(e.clusterIds ?? [])].join(' ').toLowerCase();
      if (!haystack.includes(q)) return false;
    }
    if (fromDate || toDate) {
      const t = parseLogTs(e.ts);
      if (fromDate && t < fromDate) return false;
      if (toDate   && t > toDate)   return false;
    }
    return true;
  });

  const decisionsLogged = visibleLog.filter(e => e.status === 'referred' || e.status === 'dismissed' || e.status === 'pending').length;
  const anomalous = visibleLog.filter(e => e.status === 'alert').length;
  const uniqueUsers = new Set(visibleLog.map(e => e.user)).size;

  const inStyle: React.CSSProperties = { padding:'5px 10px',background:C.s2,border:`1px solid ${C.brd}`,borderRadius:2,color:C.text,fontFamily:C.sans,fontSize:12,outline:'none' };

  return (
    <div style={{ display:'flex',flexDirection:'column',gap:16 }}>
      <div style={{ display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:12 }}>
        {statCard('Total Log Entries', visibleLog.length, session?.role === 'inspector' ? 'your entries only' : 'session + seeded entries')}
        {statCard('Unique Users', uniqueUsers, 'distinct hashed IDs in log')}
        {statCard('Decisions Logged', decisionsLogged, 'referred / dismissed / pending')}
        {statCard('Anomalous Queries', anomalous, 'flagged for review', anomalous > 0 ? C.red : undefined)}
      </div>

      {panel(<>
        {/* Toolbar */}
        <div style={{ padding:'12px 18px',borderBottom:`1px solid ${C.brd}`,display:'flex',alignItems:'center',gap:8,flexWrap:'wrap' }}>
          <span style={{ fontFamily:C.sans,fontSize:13,fontWeight:600,color:C.text,letterSpacing:'-0.01em',marginRight:4 }}>Query and Decision Log</span>
          {/* Text search */}
          <input
            type="text"
            placeholder="Search cluster ID, user, action…"
            value={search}
            onChange={e => setSearch(e.target.value)}
            style={{ ...inStyle, width:220 }}
          />
          {/* Date range */}
          <input type="date" value={dateFrom} onChange={e => setDateFrom(e.target.value)} style={{ ...inStyle, colorScheme:'dark' }} title="From date" />
          <span style={{ fontFamily:C.mono,fontSize:11,color:C.hint }}>→</span>
          <input type="date" value={dateTo}   onChange={e => setDateTo(e.target.value)}   style={{ ...inStyle, colorScheme:'dark' }} title="To date" />
          {/* Status filter */}
          <select value={statusFilter} onChange={e => setStatusFilter(e.target.value)} style={inStyle}>
            <option value="all">All entries</option>
            <option value="query">Queries only</option>
            <option value="referred">Referred</option>
            <option value="dismissed">Dismissed</option>
            <option value="pending">Pending</option>
            <option value="alert">Flagged</option>
          </select>
          {/* CSV export */}
          <button
            onClick={() => downloadCsv(filtered)}
            style={{ ...inStyle, cursor:'pointer', marginLeft:'auto', color:C.accent, border:`1px solid ${C.acBrd}`, background:C.acDim }}
          >
            ↓ Export CSV ({filtered.length})
          </button>
        </div>

        {anomalous > 0 && (
          <div style={{ margin:'10px 16px',padding:10,background:C.redBg,border:`1px solid ${C.redBrd}`,borderRadius:2,display:'flex',gap:10,alignItems:'flex-start' }}>
            <span style={{ fontSize:14,flexShrink:0 }}>⚠</span>
            <div style={{ fontFamily:C.sans,fontSize:12,color:C.red,lineHeight:1.55 }}>
              <strong>{anomalous} anomalous {anomalous === 1 ? 'query' : 'queries'} detected</strong> — {anomalous === 1 ? 'A user' : 'Users'} attempted to query below the 500-property cluster minimum. {anomalous === 1 ? 'Query was' : 'Queries were'} blocked and logged automatically.
            </div>
          </div>
        )}

        {/* Table + optional drawer */}
        <div style={{ display:'flex',minHeight:0 }}>
          <div style={{ flex:1,overflowX:'auto' }}>
            <table style={{ width:'100%',borderCollapse:'collapse' }}>
              <thead>
                <tr style={{ background:C.s2 }}>
                  {['Log ID','Timestamp','User (hashed)','Cluster','Query type','Confidence','Action / Decision','Status'].map(h=>(
                    <th key={h} style={th}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filtered.length === 0 ? (
                  <tr><td colSpan={8} style={{ ...td,textAlign:'center',color:C.hint,fontFamily:C.sans,fontSize:13,padding:'32px 16px' }}>No entries match the current filters.</td></tr>
                ) : filtered.map(e => {
                  const cid = clusterIdOfEntry(e);
                  const isClickable = !!cid;
                  const isActive = drawerClusterId === cid && cid !== null;
                  return (
                    <tr
                      key={e.id}
                      onClick={() => isClickable ? setDrawerClusterId(isActive ? null : cid) : undefined}
                      onMouseEnter={ev => { ev.currentTarget.style.background = C.s2; }}
                      onMouseLeave={ev => { ev.currentTarget.style.background = isActive ? C.acDim : 'transparent'; }}
                      style={{ cursor: isClickable ? 'pointer' : 'default', background: isActive ? C.acDim : 'transparent', borderLeft: isActive ? `2px solid ${C.accent}` : '2px solid transparent' }}
                    >
                      <td style={td}>{mono(e.id)}</td>
                      <td style={td}>{mono(e.ts)}</td>
                      <td style={td}>{mono(e.user)}</td>
                      <td style={{ ...td,fontFamily:C.mono,fontSize:11,color:cid?C.accent:C.muted }}>
                        {cid ? e.cluster : <span style={{ color:C.hint }}>{e.cluster}</span>}
                      </td>
                      <td style={{ ...td,fontFamily:C.sans,fontSize:12,color:C.muted }}>{e.qtype}</td>
                      <td style={{ ...td,fontFamily:C.sans,fontSize:12,color:C.muted }}>{e.conf}</td>
                      <td style={{ ...td,maxWidth:260 }}>
                        {['alert','referred','pending','dismissed'].includes(e.status)
                          ? <Pill t={e.status==='alert'?'high':e.status as PT}>{e.action}</Pill>
                          : <span style={{ fontFamily:C.sans,fontSize:12,color:C.muted,display:'block',overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap' }}>{e.action}</span>}
                      </td>
                      <td style={td}>
                        <Pill t={e.status==='alert'?'blocked':e.status==='query'?'logged':e.status as PT}>
                          {e.status==='alert'?'blocked':e.status}
                        </Pill>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          {drawerClusterId && (
            <ClusterAuditDrawer clusterId={drawerClusterId} onClose={() => setDrawerClusterId(null)} />
          )}
        </div>

        <div style={{ padding:'10px 16px',borderTop:`1px solid ${C.brd}`,display:'flex',justifyContent:'space-between',alignItems:'center' }}>
          {mono(`Showing ${filtered.length} of ${visibleLog.length} entries · sorted by timestamp desc`)}
          {(search || dateFrom || dateTo || statusFilter !== 'all') && (
            <button
              onClick={() => { setSearch(''); setDateFrom(''); setDateTo(''); setStatusFilter('all'); }}
              style={{ fontFamily:C.sans,fontSize:11,color:C.muted,background:'none',border:'none',cursor:'pointer',textDecoration:'underline' }}
            >
              Clear filters
            </button>
          )}
        </div>
      </>)}

      <div style={{ display:'grid',gridTemplateColumns:'1fr 1fr',gap:16 }}>
        {panel(<>{pHead('Data Retention Status')}<div style={{ padding:'16px 18px',display:'flex',flexDirection:'column',gap:16 }}>
          {[{l:'Utility records',u:18,t:24},{l:'Listing records',u:11,t:24},{l:'Audit log entries',u:8,t:24}].map(({l,u,t})=>(
            <div key={l}><div style={{ display:'flex',justifyContent:'space-between',marginBottom:6 }}><span style={{ fontFamily:C.sans,fontSize:12,color:C.muted }}>{l}</span>{mono(`${u} / ${t} months`)}</div><div style={{ height:3,borderRadius:2,background:C.s2,overflow:'hidden' }}><div style={{ width:`${(u/t)*100}%`,height:'100%',background:C.accent,borderRadius:2 }}/></div></div>
          ))}
          {mono('Next purge: 2026-07-01 · No personal identifiers stored')}
        </div></>)}
        {panel(<>{pHead('Access by User Role')}<div style={{ padding:'16px 18px',display:'flex',flexDirection:'column',gap:10 }}>
          <p style={{ fontFamily:C.sans,fontSize:12,color:C.muted,lineHeight:1.65,margin:0 }}>User IDs are stored as one-way hashes. The mapping is held by the system administrator only and is never stored in this database.</p>
          {[['Inspector','Read clusters, audit_logs'],['Pipeline','Read/write all tables'],['Admin','Schema only — no data read']].map(([role,perms],i,arr)=>(
            <div key={role} style={{ display:'flex',justifyContent:'space-between',padding:'8px 0',borderBottom:i<arr.length-1?`1px solid ${C.brd}`:'none' }}>
              {mono(role,C.accent,12)}<span style={{ fontFamily:C.sans,fontSize:12,color:C.muted }}>{perms}</span>
            </div>
          ))}
        </div></>)}
      </div>
    </div>
  );
}

/* ─── System ─── */
function SystemPage() {
  return (
    <div style={{ display:'flex',flexDirection:'column',gap:16 }}>
      <div style={{ display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:12 }}>
        {statCard('Last Full Run','2026-04-08','Jobs 1–6 completed')}
        {statCard('Properties in DB','48,320','Gràcia + Eixample')}
        {statCard('Clusters Generated','31','above 500-property threshold')}
        {statCard('Clusters Suppressed','9','below minimum threshold',C.amber)}
      </div>
      {panel(<>{pHead('Scheduled Job Status')}<div>
        {jobs.map((job,i)=>(
          <div key={i} style={{ display:'flex',alignItems:'center',gap:14,padding:'14px 18px',borderBottom:i<jobs.length-1?`1px solid ${C.brd}`:'none' }}>
            <div style={{ width:36,height:36,borderRadius:2,background:job.status==='warn'?C.ambBg:C.grnBg,border:`1px solid ${job.status==='warn'?C.ambBrd:C.grnBrd}`,display:'flex',alignItems:'center',justifyContent:'center',fontSize:16,flexShrink:0 }}>{job.icon}</div>
            <div style={{ flex:1 }}><div style={{ fontFamily:C.sans,fontSize:13,fontWeight:600,color:C.text,letterSpacing:'-0.01em' }}>{job.name}</div>{mono(`Frequency: ${job.freq}`)}</div>
            <div style={{ textAlign:'right' }}><Pill t={job.status as PT}>{job.statusLabel}</Pill><div style={{ marginTop:5 }}>{mono(`Last run: ${job.last}`)}</div></div>
          </div>
        ))}
      </div></>)}
      <div style={{ display:'grid',gridTemplateColumns:'1fr 1fr',gap:16 }}>
        {panel(<>{pHead('Classification Model')}<div style={{ padding:'14px 18px',display:'flex',flexDirection:'column',gap:2 }}>
          {[['Model version','v2.1.4'],['Structural vacancy — precision','0.81'],['Illegal tourist use — precision','0.77'],['Speculative withholding — precision','0.62'],['Min. signals required','2 sources']].map(([k,v],i,arr)=>(
            <div key={k} style={{ display:'flex',justifyContent:'space-between',padding:'9px 0',borderBottom:i<arr.length-1?`1px solid ${C.brd}`:'none' }}>
              <span style={{ fontFamily:C.sans,fontSize:12,color:C.muted }}>{k}</span>{mono(v,C.text,12)}
            </div>
          ))}
        </div></>)}
        {panel(<>{pHead('Privacy Enforcement Checks')}<div style={{ padding:'14px 18px',display:'flex',flexDirection:'column',gap:2 }}>
          {[['500-property minimum enforced','ok','✓ Active'],['Personal identifiers in schema','ok','✓ None found'],['Inferences table — inspector role','ok','✓ Blocked'],['Audit log — all queries logged','ok','✓ Active'],['Cadastre last updated','warn','⚠ 45 days ago']].map(([l,t,v],i,arr)=>(
            <div key={l} style={{ display:'flex',justifyContent:'space-between',alignItems:'center',padding:'9px 0',borderBottom:i<arr.length-1?`1px solid ${C.brd}`:'none' }}>
              <span style={{ fontFamily:C.sans,fontSize:12,color:C.muted }}>{l}</span><Pill t={t as PT}>{v}</Pill>
            </div>
          ))}
        </div></>)}
      </div>
    </div>
  );
}

/* ─── Root ─── */
function DashboardApp() {
  const { session, setSession, addAuditEntry } = useAppState();
  const [screen, setScreen] = useState<'home'|'login'|'role-select'|'dashboard'>('home');
  const [page, setPage]     = useState<'inspector'|'audit'|'system'>('inspector');
  const [toast, setToast]   = useState('');
  const [showToast, setShow] = useState(false);
  const [theme, setTheme]   = useState<'dark'|'light'>('dark');
  const [timeoutWarning, setTimeoutWarning] = useState(false);

  /* Inactivity tracking — all in refs to avoid re-renders on every mouse move */
  const lastActivityRef = useRef(Date.now());
  const warnedRef       = useRef(false);

  C = theme === 'dark' ? DARK_C : LIGHT_C;
  document.body.style.background = C.navy;
  document.body.style.color = C.text;

  const nowTs = () =>
    new Date().toLocaleString('es-ES', { year:'numeric', month:'2-digit', day:'2-digit', hour:'2-digit', minute:'2-digit', hour12:false }).replace(',','');

  const logEvent = (action: string, status: 'query'|'alert') => {
    addAuditEntry({
      id: `SYS-${Date.now()}`,
      ts: nowTs(),
      user: session?.userId ?? '—',
      cluster: '—',
      qtype: '—',
      conf: '—',
      action,
      status,
    });
  };

  const doSignOut = (reason: 'logout'|'timeout') => {
    if (session) {
      logEvent(reason === 'timeout' ? 'Session timeout — signed out automatically' : 'User signed out', 'query');
    }
    setSession(null);
    setTimeoutWarning(false);
    warnedRef.current = false;
    lastActivityRef.current = Date.now();
    setScreen('login');
    setPage('inspector');
  };

  const handleRoleSelect = (role: SessionInfo['role']) => {
    const userId = ROLE_HASHES[role];
    const newSession: SessionInfo = { role, userId };
    setSession(newSession);
    /* Log login event — session not yet in context ref, pass userId directly */
    addAuditEntry({
      id: `SYS-${Date.now()}`,
      ts: nowTs(),
      user: userId,
      cluster: '—',
      qtype: '—',
      conf: '—',
      action: `Login — role: ${role}`,
      status: 'query',
    });
    /* Set default page for role */
    const defaults: Record<SessionInfo['role'], 'inspector'|'audit'|'system'> = {
      inspector: 'inspector',
      administrator: 'audit',
    };
    setPage(defaults[role]);
    lastActivityRef.current = Date.now();
    warnedRef.current = false;
    setScreen('dashboard');
  };

  /* Inactivity timer — only active when on dashboard */
  useEffect(() => {
    if (screen !== 'dashboard') return;

    const resetActivity = () => {
      lastActivityRef.current = Date.now();
      if (timeoutWarning) setTimeoutWarning(false);
      warnedRef.current = false;
    };

    document.addEventListener('mousemove', resetActivity, { passive: true });
    document.addEventListener('keydown',   resetActivity, { passive: true });
    document.addEventListener('click',     resetActivity, { passive: true });

    const interval = setInterval(() => {
      const elapsed = Date.now() - lastActivityRef.current;
      const WARN_MS    = 55 * 60 * 1000;
      const TIMEOUT_MS = 60 * 60 * 1000;
      if (elapsed >= TIMEOUT_MS) {
        doSignOut('timeout');
      } else if (elapsed >= WARN_MS && !warnedRef.current) {
        warnedRef.current = true;
        setTimeoutWarning(true);
      }
    }, 15_000);

    return () => {
      document.removeEventListener('mousemove', resetActivity);
      document.removeEventListener('keydown',   resetActivity);
      document.removeEventListener('click',     resetActivity);
      clearInterval(interval);
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [screen, timeoutWarning]);

  const fastForwardSession = () => {
    /* Jump last-activity to 56 min ago so the warning fires on the next check */
    lastActivityRef.current = Date.now() - 56 * 60 * 1000;
    warnedRef.current = false;
  };

  const showToastMsg = (msg: string) => { setToast(msg); setShow(true); setTimeout(()=>setShow(false),2500); };

  const navigatePage = (p: 'inspector'|'audit'|'system') => {
    setPage(p);
    lastActivityRef.current = Date.now();
  };

  /* ── Screen routing ── */
  if (screen === 'home') {
    return (
      <>
        <style>{GLOBE_CSS}</style>
        <HomePage onOpenLogin={() => setScreen('login')} theme={theme} setTheme={setTheme} />
      </>
    );
  }

  if (screen === 'login') {
    return (
      <>
        <style>{GLOBE_CSS}</style>
        <LoginPage onLogin={() => setScreen('role-select')} theme={theme} setTheme={setTheme} />
      </>
    );
  }

  if (screen === 'role-select') {
    return (
      <>
        <style>{GLOBE_CSS}</style>
        <RoleSelectPage onSelect={handleRoleSelect} />
      </>
    );
  }

  /* ── Dashboard ── */
  const role = session?.role ?? 'inspector';
  const allowed = ROLE_ACCESS[role];
  const pageAllowed = allowed.includes(page);

  return (
    <div style={{ minHeight:'100vh', display:'flex', flexDirection:'column', background:C.navy, fontFamily:C.sans }}>
      <style>{GLOBE_CSS}</style>
      <TopBar
        page={page}
        setPage={navigatePage}
        theme={theme}
        setTheme={setTheme}
        onSignOut={() => doSignOut('logout')}
        onFastForward={fastForwardSession}
      />
      <div style={{ display:'flex', flex:1, overflow:'hidden' }}>
        {page === 'inspector' && pageAllowed && <Sidebar />}
        <main style={{ flex:1, overflowY:'auto', padding:18 }}>
          {!pageAllowed && <RestrictedPage role={role} />}
          {pageAllowed && page === 'inspector' && <InspectorPage onShowToast={showToastMsg} />}
          {pageAllowed && page === 'audit'     && <AuditPage onShowToast={showToastMsg} />}
          {pageAllowed && page === 'system'    && <SystemPage />}
        </main>
      </div>
      {/* Toast */}
      <div style={{ position:'fixed',bottom:24,right:24,background:C.s3,border:`1px solid ${C.brd2}`,color:C.text,padding:'10px 18px',borderRadius:2,fontFamily:C.sans,fontSize:13,fontWeight:500,zIndex:999,transition:'opacity 0.25s',opacity:showToast?1:0,pointerEvents:showToast?'auto':'none' }}>
        {toast}
      </div>
      {/* Inactivity warning modal */}
      {timeoutWarning && (
        <TimeoutWarningModal
          onStay={() => { lastActivityRef.current = Date.now(); warnedRef.current = false; setTimeoutWarning(false); }}
          onSignOut={() => doSignOut('timeout')}
        />
      )}
    </div>
  );
}

export default function App() {
  return (
    <AppStateProvider>
      <DashboardApp />
    </AppStateProvider>
  );
}
