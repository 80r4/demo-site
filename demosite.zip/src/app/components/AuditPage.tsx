import { useState } from 'react';
import { LogEntry } from '../types';

interface AuditPageProps {
  logEntries: LogEntry[];
  onShowToast: (message: string) => void;
}

const Badge = ({ type, children }: { type: string; children: React.ReactNode }) => {
  const classes = {
    high: 'bg-[#FDEEEC] text-[#C0392B]',
    neutral: 'bg-[#F4F5F7] text-[#6B7280] border border-[#E2E4E8]',
    ok: 'bg-[#EAF4EC] text-[#1D6832]',
    referred: 'bg-[#EBF2FA] text-[#1C3557]',
    pending: 'bg-[#EBF2FA] text-[#2E5496]',
  }[type] || 'bg-[#F4F5F7] text-[#6B7280]';

  return (
    <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-semibold ${classes}`}>
      {children}
    </span>
  );
};

export function AuditPage({ logEntries, onShowToast }: AuditPageProps) {
  const [filter, setFilter] = useState<string>('all');

  const filteredEntries = logEntries.filter((entry) => filter === 'all' || entry.status === filter);

  return (
    <div className="flex flex-col gap-4">
      <div className="grid grid-cols-4 gap-3">
        <div className="bg-white border border-[#E2E4E8] rounded-xl p-3.5">
          <div className="text-[11px] text-[#9CA3AF] mb-1">Total log entries</div>
          <div className="text-[26px] font-semibold leading-none">284</div>
          <div className="text-[11px] text-[#9CA3AF] mt-1">last 24 months</div>
        </div>
        <div className="bg-white border border-[#E2E4E8] rounded-xl p-3.5">
          <div className="text-[11px] text-[#9CA3AF] mb-1">Unique users</div>
          <div className="text-[26px] font-semibold leading-none">6</div>
          <div className="text-[11px] text-[#9CA3AF] mt-1">with inspector access</div>
        </div>
        <div className="bg-white border border-[#E2E4E8] rounded-xl p-3.5">
          <div className="text-[11px] text-[#9CA3AF] mb-1">Decisions logged</div>
          <div className="text-[26px] font-semibold leading-none">47</div>
          <div className="text-[11px] text-[#9CA3AF] mt-1">referred / dismissed / pending</div>
        </div>
        <div className="bg-white border border-[#E2E4E8] rounded-xl p-3.5">
          <div className="text-[11px] text-[#9CA3AF] mb-1">Anomalous queries</div>
          <div className="text-[26px] font-semibold leading-none text-[#C0392B]">1</div>
          <div className="text-[11px] text-[#9CA3AF] mt-1">flagged for review</div>
        </div>
      </div>

      <div className="bg-white border border-[#E2E4E8] rounded-xl overflow-hidden">
        <div className="px-4 py-3 border-b border-[#E2E4E8] flex items-center justify-between">
          <span className="text-[13px] font-semibold">Query and decision log</span>
          <div className="flex gap-2 items-center">
            <select
              value={filter}
              onChange={(e) => setFilter(e.target.value)}
              className="w-35 px-2.5 py-1.5 text-[12px] border border-[#E2E4E8] rounded-lg bg-[#F4F5F7] text-[#1A1A2E] outline-none transition-colors focus:border-[#4A7CB8]"
            >
              <option value="all">All entries</option>
              <option value="referred">Referred</option>
              <option value="dismissed">Dismissed</option>
              <option value="query">Queries only</option>
              <option value="alert">Flagged</option>
            </select>
            <button
              onClick={() => onShowToast('Export downloaded — audit_log_2026-04.csv')}
              className="px-3.5 py-1.5 rounded-lg border border-[#E2E4E8] bg-[#F4F5F7] text-[12px] text-[#6B7280] hover:border-[#4A7CB8] hover:text-[#1A1A2E] transition-all"
            >
              Export CSV
            </button>
          </div>
        </div>

        <div className="mx-4 my-3 bg-[#FDEEEC] border border-[#f0b4b0] rounded-lg p-2.5 text-[12px] text-[#C0392B] flex gap-2 items-start leading-relaxed">
          <span className="text-base">⚠</span>
          <div>
            <strong>Anomalous query detected (2026-04-24 03:17):</strong> User f2a9… attempted to query below the
            500-property cluster minimum. Query was blocked and logged automatically. Review recommended.
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full border-collapse">
            <thead>
              <tr className="bg-[#F4F5F7]">
                <th className="px-3.5 py-2 text-left text-[11px] font-semibold text-[#9CA3AF] border-b border-[#E2E4E8] whitespace-nowrap">
                  Log ID
                </th>
                <th className="px-3.5 py-2 text-left text-[11px] font-semibold text-[#9CA3AF] border-b border-[#E2E4E8] whitespace-nowrap">
                  Timestamp
                </th>
                <th className="px-3.5 py-2 text-left text-[11px] font-semibold text-[#9CA3AF] border-b border-[#E2E4E8] whitespace-nowrap">
                  User (hashed)
                </th>
                <th className="px-3.5 py-2 text-left text-[11px] font-semibold text-[#9CA3AF] border-b border-[#E2E4E8] whitespace-nowrap">
                  Cluster
                </th>
                <th className="px-3.5 py-2 text-left text-[11px] font-semibold text-[#9CA3AF] border-b border-[#E2E4E8] whitespace-nowrap">
                  Query type
                </th>
                <th className="px-3.5 py-2 text-left text-[11px] font-semibold text-[#9CA3AF] border-b border-[#E2E4E8] whitespace-nowrap">
                  Confidence filter
                </th>
                <th className="px-3.5 py-2 text-left text-[11px] font-semibold text-[#9CA3AF] border-b border-[#E2E4E8] whitespace-nowrap">
                  Action / Decision
                </th>
                <th className="px-3.5 py-2 text-left text-[11px] font-semibold text-[#9CA3AF] border-b border-[#E2E4E8] whitespace-nowrap">
                  Status
                </th>
              </tr>
            </thead>
            <tbody>
              {filteredEntries.map((entry) => (
                <tr key={entry.id} className="hover:bg-[#F4F5F7] cursor-pointer">
                  <td className="px-3.5 py-2 border-b border-[#E2E4E8] text-[12px] font-mono text-[#9CA3AF]">
                    {entry.id}
                  </td>
                  <td className="px-3.5 py-2 border-b border-[#E2E4E8] text-[12px] font-mono text-[#9CA3AF]">
                    {entry.ts}
                  </td>
                  <td className="px-3.5 py-2 border-b border-[#E2E4E8] text-[12px] font-mono text-[#9CA3AF]">
                    {entry.user}
                  </td>
                  <td className="px-3.5 py-2 border-b border-[#E2E4E8] text-[12px]">{entry.cluster}</td>
                  <td className="px-3.5 py-2 border-b border-[#E2E4E8] text-[12px]">{entry.qtype}</td>
                  <td className="px-3.5 py-2 border-b border-[#E2E4E8] text-[12px]">{entry.conf}</td>
                  <td className="px-3.5 py-2 border-b border-[#E2E4E8] text-[12px]">
                    {entry.status === 'alert' ? (
                      <Badge type="high">{entry.action}</Badge>
                    ) : entry.status === 'referred' ? (
                      <Badge type="referred">{entry.action}</Badge>
                    ) : entry.status === 'pending' ? (
                      <Badge type="pending">{entry.action}</Badge>
                    ) : (
                      entry.action
                    )}
                  </td>
                  <td className="px-3.5 py-2 border-b border-[#E2E4E8] text-[12px]">
                    <Badge type={entry.status === 'alert' ? 'high' : entry.status === 'query' ? 'neutral' : 'ok'}>
                      {entry.status === 'alert' ? 'blocked' : 'logged'}
                    </Badge>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="px-4 py-3 border-t border-[#E2E4E8] flex justify-end">
          <span className="text-[12px] text-[#9CA3AF]">
            Showing {filteredEntries.length} of 284 entries · Sorted by timestamp desc
          </span>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="bg-white border border-[#E2E4E8] rounded-xl overflow-hidden">
          <div className="px-4 py-3 border-b border-[#E2E4E8]">
            <span className="text-[13px] font-semibold">Data retention status</span>
          </div>
          <div className="p-4">
            <div className="flex justify-between text-[11px] text-[#9CA3AF] mb-1.5">
              <span>Utility records</span>
              <span>18 months used of 24</span>
            </div>
            <div className="h-2 bg-[#F4F5F7] rounded border border-[#E2E4E8] overflow-hidden">
              <div className="h-full rounded bg-[#1C3557]" style={{ width: '75%' }}></div>
            </div>
          </div>
          <div className="px-4 pt-0 pb-4">
            <div className="flex justify-between text-[11px] text-[#9CA3AF] mb-1.5">
              <span>Listing records</span>
              <span>11 months used of 24</span>
            </div>
            <div className="h-2 bg-[#F4F5F7] rounded border border-[#E2E4E8] overflow-hidden">
              <div className="h-full rounded bg-[#1C3557]" style={{ width: '46%' }}></div>
            </div>
          </div>
          <div className="px-4 pt-0 pb-4">
            <div className="flex justify-between text-[11px] text-[#9CA3AF] mb-1.5">
              <span>Audit log entries</span>
              <span>8 months used of 24</span>
            </div>
            <div className="h-2 bg-[#F4F5F7] rounded border border-[#E2E4E8] overflow-hidden">
              <div className="h-full rounded bg-[#1C3557]" style={{ width: '33%' }}></div>
            </div>
          </div>
          <div className="px-4 pb-4">
            <div className="text-[11px] text-[#9CA3AF]">
              Next automatic purge: 2026-07-01 · No personal identifiers stored in any table
            </div>
          </div>
        </div>

        <div className="bg-white border border-[#E2E4E8] rounded-xl overflow-hidden">
          <div className="px-4 py-3 border-b border-[#E2E4E8]">
            <span className="text-[13px] font-semibold">Access by user role</span>
          </div>
          <div className="p-3.5 flex flex-col gap-2.5">
            <div className="text-[12px] text-[#9CA3AF] leading-relaxed">
              User IDs are stored as one-way hashes. The mapping between hash and real user ID is held by the system
              administrator only and is never stored in this database.
            </div>
            <div className="flex justify-between text-[13px] py-2 border-b border-[#E2E4E8]">
              <span className="text-[#6B7280]">Inspector role</span>
              <span>
                Read <code className="text-[11px] bg-[#F4F5F7] px-1 rounded">clusters</code>,{' '}
                <code className="text-[11px] bg-[#F4F5F7] px-1 rounded">audit_logs</code>
              </span>
            </div>
            <div className="flex justify-between text-[13px] py-2 border-b border-[#E2E4E8]">
              <span className="text-[#6B7280]">Pipeline role</span>
              <span>Read/write all tables</span>
            </div>
            <div className="flex justify-between text-[13px] py-2">
              <span className="text-[#6B7280]">Admin role</span>
              <span>Schema only — no data read</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
