import { useState } from 'react';
import { Cluster } from '../types';
import { LeafletClusterMap } from './LeafletClusterMap';
import { ClusterList } from './ClusterList';
import { ClusterDetail } from './ClusterDetail';
import { DataFreshnessWarning } from './DataFreshnessWarning';

interface InspectorPageProps {
  clusters: Cluster[];
  onUpdateCluster: (index: number, updates: Partial<Cluster>) => void;
  onShowToast: (message: string) => void;
}

export function InspectorPage({ clusters, onUpdateCluster, onShowToast }: InspectorPageProps) {
  const [selectedClusterIndex, setSelectedClusterIndex] = useState<number | null>(null);

  const highConfCount = clusters.filter((c) => c.conf === 'high').length;
  const pendingCount = clusters.filter((c) => !c.decision).length;
  const totalProps = clusters.reduce((sum, c) => sum + c.props, 0);

  // NF-05: Data freshness check (>35 days warning)
  const today = new Date('2026-04-30');
  const dataSources = [
    { name: 'Utility', lastUpdate: '8 Apr', daysAgo: Math.floor((today.getTime() - new Date('2026-04-08').getTime()) / (1000 * 60 * 60 * 24)) },
    { name: 'Listings', lastUpdate: '25 Apr', daysAgo: Math.floor((today.getTime() - new Date('2026-04-25').getTime()) / (1000 * 60 * 60 * 24)) },
    { name: 'Cadastre', lastUpdate: '12 Mar', daysAgo: Math.floor((today.getTime() - new Date('2026-03-12').getTime()) / (1000 * 60 * 60 * 24)) },
  ];

  return (
    <div className="flex flex-col gap-4">
      {/* NF-05: Data freshness warning */}
      <DataFreshnessWarning sources={dataSources} />
      <div className="grid grid-cols-4 gap-4">
        <div className="bg-white border border-[#E2E4E8] rounded-xl p-5 shadow-sm hover:shadow-md transition-shadow">
          <div className="text-[12px] font-medium text-[#6B7280] mb-2 uppercase tracking-wide">Clusters Flagged</div>
          <div className="text-[32px] font-bold leading-none text-[#1A1A2E] mb-2">{clusters.length}</div>
          <div className="text-[13px] text-[#9CA3AF]">Gràcia district</div>
        </div>
        <div className="bg-white border border-[#E2E4E8] rounded-xl p-5 shadow-sm hover:shadow-md transition-shadow">
          <div className="text-[12px] font-medium text-[#6B7280] mb-2 uppercase tracking-wide">Properties Covered</div>
          <div className="text-[32px] font-bold leading-none text-[#1A1A2E] mb-2">{totalProps.toLocaleString()}</div>
          <div className="text-[13px] text-[#9CA3AF]">across all clusters</div>
        </div>
        <div className="bg-white border border-[#E2E4E8] rounded-xl p-5 shadow-sm hover:shadow-md transition-shadow">
          <div className="text-[12px] font-medium text-[#6B7280] mb-2 uppercase tracking-wide">High Confidence</div>
          <div className="text-[32px] font-bold leading-none text-[#C0392B] mb-2">{highConfCount}</div>
          <div className="text-[13px] text-[#9CA3AF]">clusters</div>
        </div>
        <div className="bg-white border border-[#E2E4E8] rounded-xl p-5 shadow-sm hover:shadow-md transition-shadow">
          <div className="text-[12px] font-medium text-[#6B7280] mb-2 uppercase tracking-wide">Awaiting Decision</div>
          <div className="text-[32px] font-bold leading-none text-[#8B6000] mb-2">{pendingCount}</div>
          <div className="text-[13px] text-[#9CA3AF]">clusters</div>
        </div>
      </div>

      <div className="bg-white border border-[#E2E4E8] rounded-xl overflow-hidden shadow-sm">
        <div className="px-5 py-4 border-b border-[#E2E4E8] flex items-center justify-between bg-gradient-to-r from-white to-[#F9FAFB]">
          <div>
            <h2 className="text-[15px] font-semibold text-[#1A1A2E] mb-0.5">Cluster Map</h2>
            <p className="text-[12px] text-[#6B7280]">Gràcia district, Barcelona</p>
          </div>
          <span className="text-[12px] text-[#9CA3AF] bg-white px-3 py-1.5 rounded-lg border border-[#E2E4E8]">
            💡 Click to inspect
          </span>
        </div>
        <LeafletClusterMap
          clusters={clusters}
          selectedIndex={selectedClusterIndex}
          onSelectCluster={setSelectedClusterIndex}
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="bg-white border border-[#E2E4E8] rounded-xl overflow-hidden shadow-sm">
          <div className="px-5 py-4 border-b border-[#E2E4E8] bg-gradient-to-r from-white to-[#F9FAFB]">
            <h2 className="text-[15px] font-semibold text-[#1A1A2E] mb-0.5">Query Results</h2>
            <p className="text-[12px] text-[#6B7280]">{clusters.length} clusters match criteria</p>
          </div>
          <ClusterList
            clusters={clusters}
            selectedIndex={selectedClusterIndex}
            onSelectCluster={setSelectedClusterIndex}
          />
        </div>

        <div className="bg-white border border-[#E2E4E8] rounded-xl overflow-hidden">
          <ClusterDetail
            cluster={selectedClusterIndex !== null ? clusters[selectedClusterIndex] : null}
            onUpdateCluster={(updates) => {
              if (selectedClusterIndex !== null) {
                onUpdateCluster(selectedClusterIndex, updates);
              }
            }}
            onShowToast={onShowToast}
          />
        </div>
      </div>
    </div>
  );
}
