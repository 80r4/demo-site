import { useState } from 'react';
import { Cluster } from '../types';

interface ClusterDetailProps {
  cluster: Cluster | null;
  onUpdateCluster: (updates: Partial<Cluster>) => void;
  onShowToast: (message: string) => void;
}

const Badge = ({ type, children }: { type: string; children: React.ReactNode }) => {
  const classes = {
    high: 'bg-[#FDEEEC] text-[#C0392B]',
    medium: 'bg-[#FEF9E7] text-[#8B6000]',
    watch: 'bg-[#EBF2FA] text-[#2E5496]',
    referred: 'bg-[#EBF2FA] text-[#1C3557]',
    dismissed: 'bg-[#FEF9E7] text-[#8B6000]',
    pending: 'bg-[#EBF2FA] text-[#2E5496]',
  }[type];

  return (
    <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-semibold ${classes}`}>
      {children}
    </span>
  );
};

export function ClusterDetail({ cluster, onUpdateCluster, onShowToast }: ClusterDetailProps) {
  const [chosenDecision, setChosenDecision] = useState<'referred' | 'dismissed' | 'pending' | null>(null);
  const [decisionNotes, setDecisionNotes] = useState('');
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [confirmedDecision, setConfirmedDecision] = useState<{
    type: string;
    notes: string;
    timestamp: string;
  } | null>(null);

  if (!cluster) {
    return (
      <>
        <div className="px-5 py-4 border-b border-[#E2E4E8] bg-gradient-to-r from-white to-[#F9FAFB]">
          <h2 className="text-[15px] font-semibold text-[#1A1A2E]">Cluster Details</h2>
        </div>
        <div className="flex flex-col items-center justify-center h-64 p-8 text-center">
          <div className="w-16 h-16 bg-[#F4F5F7] rounded-full flex items-center justify-center mb-4">
            <span className="text-3xl">🔍</span>
          </div>
          <p className="text-[14px] font-medium text-[#6B7280] mb-2">No cluster selected</p>
          <p className="text-[13px] text-[#9CA3AF] max-w-xs">
            Click a cluster on the map or select one from the list to view detailed information.
          </p>
        </div>
      </>
    );
  }

  const sigColors = ['#1F5C99', '#8B6000', '#1D6832', '#C0392B'];
  const sigLabels = [
    '% below 5 L/day (water)',
    '% with active listings',
    '% residential zoning match',
    '% no registered residents',
  ];
  const sigKeys: Array<'water' | 'listings' | 'cadastre' | 'residents'> = ['water', 'listings', 'cadastre', 'residents'];

  const handleLogDecision = () => {
    if (!chosenDecision) return;

    const actionLabel =
      chosenDecision === 'referred'
        ? 'Referred for physical inspection'
        : chosenDecision === 'dismissed'
        ? 'Dismissed — insufficient evidence'
        : 'Set to pending — monitoring';

    const now = new Date();
    const ts = `2026-04-26 ${now.toTimeString().slice(0, 5)}`;

    // Add notes to action if provided
    const fullAction = decisionNotes ? `${actionLabel} — Note: ${decisionNotes}` : actionLabel;

    onUpdateCluster({
      decision: chosenDecision,
      audit: [...cluster.audit, { user: 'E.Martínez', ts, action: fullAction }],
    });

    // Show confirmation modal
    setConfirmedDecision({
      type: actionLabel,
      notes: decisionNotes,
      timestamp: ts,
    });
    setShowConfirmation(true);

    // Reset form
    setChosenDecision(null);
    setDecisionNotes('');
  };

  return (
    <>
      <div className="px-5 py-4 border-b border-[#E2E4E8] bg-gradient-to-r from-white to-[#F9FAFB]">
        <div className="flex items-start justify-between gap-3">
          <div>
            <h2 className="text-[15px] font-semibold text-[#1A1A2E] mb-1">{cluster.id}</h2>
            <p className="text-[13px] text-[#6B7280]">{cluster.area}</p>
          </div>
          {cluster.decision && <Badge type={cluster.decision}>{cluster.decision}</Badge>}
        </div>
      </div>

      <div className="overflow-y-auto max-h-[600px]">
        <div className="grid grid-cols-2 gap-px bg-[#E2E4E8]">
          <div className="px-4 py-4 bg-white">
            <div className="text-[11px] font-medium text-[#9CA3AF] mb-1.5 uppercase tracking-wide">Misuse Type</div>
            <div className="text-[14px] font-semibold text-[#1A1A2E]">{cluster.type}</div>
          </div>
          <div className="px-4 py-4 bg-white">
            <div className="text-[11px] font-medium text-[#9CA3AF] mb-1.5 uppercase tracking-wide">Confidence</div>
            <div className="text-[14px] font-semibold">
              <Badge type={cluster.conf}>{cluster.conf}</Badge>
            </div>
          </div>
          <div className="px-4 py-4 bg-white">
            <div className="text-[11px] font-medium text-[#9CA3AF] mb-1.5 uppercase tracking-wide">Properties</div>
            <div className="text-[14px] font-semibold text-[#1A1A2E]">{cluster.props.toLocaleString()}</div>
          </div>
          <div className="px-4 py-4 bg-white">
            <div className="text-[11px] font-medium text-[#9CA3AF] mb-1.5 uppercase tracking-wide">Score</div>
            <div className="text-[14px] font-semibold text-[#1A1A2E]">{Math.round(cluster.score * 100)}%</div>
          </div>
        </div>

        <div className="px-5 py-4 border-b border-[#E2E4E8] bg-[#F9FAFB]">
          <div className="flex justify-between items-center mb-3">
            <h3 className="text-[13px] font-semibold text-[#1A1A2E]">Signal Profile</h3>
            <span className="text-[10px] text-[#9CA3AF] bg-white px-2 py-1 rounded border border-[#E2E4E8]">
              Aggregated • 500+ properties
            </span>
          </div>
          {sigKeys.map((key, index) => (
            <div key={key} className="mb-3 last:mb-0 bg-white p-3 rounded-lg border border-[#E2E4E8]">
              <div className="flex items-center justify-between mb-2">
                <span className="text-[12px] font-medium text-[#6B7280]">{sigLabels[index]}</span>
                <span className="text-[13px] font-bold" style={{ color: sigColors[index] }}>
                  {cluster.signals[key]}%
                </span>
              </div>
              <div className="h-2 bg-[#F4F5F7] rounded-full overflow-hidden">
                <div
                  className="h-full rounded-full transition-all"
                  style={{ width: `${cluster.signals[key]}%`, backgroundColor: sigColors[index] }}
                ></div>
              </div>
            </div>
          ))}
        </div>

        <div className="border-b border-[#E2E4E8]">
          <div className="px-5 py-3 flex items-center justify-between">
            <h3 className="text-[13px] font-semibold text-[#1A1A2E]">Street View</h3>
            <a
              href={`https://www.google.com/maps/@${cluster.lat},${cluster.lon},3a,75y,90t/data=!3m6!1e1!3m4!1sAF1QipP_placeholder!2e10!7i13312!8i6656`}
              target="_blank"
              rel="noopener noreferrer"
              className="text-[11px] text-[#2E5496] hover:text-[#1C3557] font-medium flex items-center gap-1 transition-colors"
            >
              Open in Maps ↗
            </a>
          </div>
          <div className="relative mx-5 mb-4 rounded-lg overflow-hidden border border-[#E2E4E8]" style={{ height: 180 }}>
            <iframe
              title={`Street view — ${cluster.area}`}
              width="100%"
              height="100%"
              style={{ border: 0, display: 'block' }}
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              src={`https://maps.google.com/maps?q=${cluster.lat},${cluster.lon}&z=17&layer=c&iwloc=&output=svembed`}
            />
            <div className="absolute bottom-0 left-0 right-0 px-2.5 py-1.5 flex items-center gap-1.5" style={{ background: 'rgba(0,0,0,0.55)' }}>
              <svg className="w-3 h-3 text-white flex-shrink-0" viewBox="0 0 16 16" fill="currentColor">
                <circle cx="8" cy="8" r="7" fill="none" stroke="white" strokeWidth="1.5"/>
                <circle cx="8" cy="6" r="2" fill="white"/>
                <path d="M5 13c0-1.7 1.3-3 3-3s3 1.3 3 3" fill="white"/>
              </svg>
              <span className="text-[10px] font-medium" style={{ color: 'rgba(255,255,255,0.85)' }}>
                Google Street View — {cluster.area}
              </span>
              <span className="ml-auto text-[9px]" style={{ color: 'rgba(255,255,255,0.5)' }}>
                {cluster.lat.toFixed(4)}°N, {cluster.lon.toFixed(4)}°E
              </span>
            </div>
          </div>
          <div className="mx-5 mb-3 px-3 py-2 rounded-lg bg-[#EBF2FA] border border-[#c5d8f0] text-[11px] text-[#2E5496] leading-relaxed">
            Street view is an optional visual reference only. It is not used in the algorithmic classification and does not constitute evidence.
          </div>
        </div>

        <div className="px-5 py-4 border-b border-[#E2E4E8]">
          <h3 className="text-[13px] font-semibold text-[#1A1A2E] mb-2">Analysis Summary</h3>
          <p className="text-[13px] text-[#6B7280] leading-relaxed">{cluster.summary}</p>
        </div>

        <div className="border-b border-[#E2E4E8]">
          <div className="px-4 py-2 text-[11px] font-semibold tracking-wider text-[#9CA3AF] uppercase">
            Audit trail
          </div>
          {cluster.audit.length > 0 ? (
            cluster.audit.map((entry, i) => (
              <div key={i} className="flex items-center gap-2 px-4 py-2 border-b border-[#E2E4E8] last:border-b-0 text-[12px]">
                <span className="text-[#6B7280]">{entry.user}</span>
                <span className="flex-1">{entry.action}</span>
                <span className="text-[11px] text-[#9CA3AF]">{entry.ts}</span>
              </div>
            ))
          ) : (
            <div className="px-4 py-2.5 text-[12px] text-[#9CA3AF]">No previous activity on this cluster.</div>
          )}
        </div>

        <div className="p-3.5 flex flex-col gap-2.5">
          <div className="text-[11px] font-semibold tracking-wider text-[#9CA3AF] uppercase">Log decision</div>
          <div className="flex gap-2 flex-wrap">
            <button
              onClick={() => setChosenDecision('referred')}
              className={`px-3.5 py-1.5 rounded-lg border text-[12px] transition-all ${
                chosenDecision === 'referred'
                  ? 'border-[#1C3557] bg-[#EBF2FA] text-[#1C3557] font-semibold'
                  : 'border-[#E2E4E8] bg-[#F4F5F7] text-[#6B7280] hover:border-[#4A7CB8] hover:text-[#1A1A2E]'
              }`}
            >
              Refer for inspection
            </button>
            <button
              onClick={() => setChosenDecision('dismissed')}
              className={`px-3.5 py-1.5 rounded-lg border text-[12px] transition-all ${
                chosenDecision === 'dismissed'
                  ? 'border-[#8B6000] bg-[#FEF9E7] text-[#8B6000] font-semibold'
                  : 'border-[#E2E4E8] bg-[#F4F5F7] text-[#6B7280] hover:border-[#4A7CB8] hover:text-[#1A1A2E]'
              }`}
            >
              Dismiss
            </button>
            <button
              onClick={() => setChosenDecision('pending')}
              className={`px-3.5 py-1.5 rounded-lg border text-[12px] transition-all ${
                chosenDecision === 'pending'
                  ? 'border-[#2E5496] bg-[#EBF2FA] text-[#2E5496] font-semibold'
                  : 'border-[#E2E4E8] bg-[#F4F5F7] text-[#6B7280] hover:border-[#4A7CB8] hover:text-[#1A1A2E]'
              }`}
            >
              Pending
            </button>
          </div>
          {/* S3-03: Decision notes field (max 500 characters) */}
          <div className="flex flex-col gap-1.5">
            <label htmlFor="decision-notes" className="text-[11px] font-semibold tracking-wider text-[#9CA3AF] uppercase">
              Notes (Optional, max 500 characters)
            </label>
            <textarea
              id="decision-notes"
              value={decisionNotes}
              onChange={(e) => setDecisionNotes(e.target.value.slice(0, 500))}
              placeholder="Add context, observations, or justification for this decision..."
              className="w-full px-3 py-2 border border-[#E2E4E8] rounded-lg text-[12px] bg-white text-[#1A1A2E] outline-none transition-colors focus:border-[#4A7CB8] resize-none"
              rows={3}
              disabled={!chosenDecision}
            />
            <div className="text-[10px] text-[#9CA3AF] text-right">
              {decisionNotes.length}/500 characters
            </div>
          </div>

          <div className="p-2.5 bg-[#EAF4EC] border border-[#b0d8bc] rounded-lg text-[11px] text-[#1D6832] flex gap-2 items-start leading-relaxed">
            <svg className="w-4 h-4 flex-shrink-0 mt-0.5" viewBox="0 0 16 16" fill="none">
              <path d="M8 1L14 4v5c0 3.3-2.7 5.7-6 6.5C4.7 14.7 2 12.3 2 9V4L8 1z" fill="#1D6832" />
              <path d="M5.5 8l2 2 3-3" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
            Decision is logged to the audit trail only. No individual property data is accessed or stored.
          </div>
          <button
            onClick={handleLogDecision}
            disabled={!chosenDecision}
            className="self-start px-4 py-1.5 rounded-lg bg-[#1C3557] text-white text-[12px] font-semibold hover:bg-[#2E5496] transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Log decision →
          </button>
        </div>
      </div>

      {/* S3-07: Confirmation modal after decision */}
      {showConfirmation && confirmedDecision && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl shadow-2xl max-w-lg w-full mx-4">
            <div className="px-6 py-4 border-b border-[#E2E4E8] flex items-center justify-between">
              <h3 className="text-[15px] font-semibold">Decision Logged Successfully</h3>
              <span className="text-[24px]">✓</span>
            </div>
            <div className="px-6 py-5 space-y-4">
              <div className="bg-[#EBF2FA] border border-[#4A7CB8]/30 rounded-lg p-4">
                <div className="text-[11px] text-[#9CA3AF] uppercase tracking-wider mb-2">What was logged</div>
                <div className="space-y-2 text-[13px]">
                  <div><strong>Cluster:</strong> {cluster.id} — {cluster.area}</div>
                  <div><strong>Decision:</strong> {confirmedDecision.type}</div>
                  <div><strong>Timestamp:</strong> {confirmedDecision.timestamp}</div>
                  <div><strong>Inspector:</strong> E. Martínez (hashed ID: a3f7…)</div>
                  {confirmedDecision.notes && (
                    <div>
                      <strong>Notes:</strong>
                      <div className="mt-1 p-2 bg-white rounded border border-[#E2E4E8] text-[12px] italic">
                        {confirmedDecision.notes}
                      </div>
                    </div>
                  )}
                </div>
              </div>
              <div className="bg-[#FEF9E7] border border-[#f0c894] rounded-lg p-3 text-[11px] text-[#8B6000]">
                <strong>⚠️ Important:</strong> This decision has been permanently logged to the audit trail.
                It cannot be edited or deleted. All logged decisions are subject to administrative review.
              </div>
            </div>
            <div className="px-6 py-4 border-t border-[#E2E4E8] flex justify-end">
              <button
                onClick={() => {
                  setShowConfirmation(false);
                  setConfirmedDecision(null);
                  onShowToast('Decision logged to audit trail');
                }}
                className="px-5 py-2 rounded-lg bg-[#1C3557] text-white text-[13px] font-semibold hover:bg-[#2E5496] transition-colors"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
