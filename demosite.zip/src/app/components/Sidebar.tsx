import { useState } from 'react';

interface SidebarProps {
  onRunQuery: () => void;
}

export function Sidebar({ onRunQuery }: SidebarProps) {
  const [area, setArea] = useState('Gràcia — full district');
  const [type, setType] = useState('all');
  const [confidence, setConfidence] = useState('medium+');
  const [previewCount, setPreviewCount] = useState(7);
  const [queryError, setQueryError] = useState<string | null>(null);

  const handleConfidenceChange = (conf: string) => {
    setConfidence(conf);
    const newCount = 3 + Math.floor(Math.random() * 5);
    setPreviewCount(newCount);
    // Clear error when filters change
    setQueryError(null);
  };

  const handleAreaChange = (newArea: string) => {
    setArea(newArea);
    setPreviewCount(3 + Math.floor(Math.random() * 5));
    setQueryError(null);
  };

  const handleTypeChange = (newType: string) => {
    setType(newType);
    setPreviewCount(3 + Math.floor(Math.random() * 5));
    setQueryError(null);
  };

  // S1-05: Query validation - reject if insufficient clusters
  const handleRunQuery = () => {
    if (previewCount === 0) {
      setQueryError('No clusters match these criteria. Try adjusting your filters (confidence level, misuse type, or geographic area).');
      return;
    }

    // Note: In production, this would check total property count across clusters
    // For now, we assume each cluster has 500+ properties (privacy requirement)
    const estimatedProperties = previewCount * 750; // Assume avg 750 properties per cluster

    if (estimatedProperties < 500) {
      setQueryError(
        'Query rejected: Results would contain fewer than 500 properties (privacy threshold). ' +
        'This query has been logged. Please select a larger geographic area or broader filters.'
      );
      // In production: log to audit_logs with status='blocked'
      console.warn('[PRIVACY] Query blocked - below 500 property threshold:', {
        area,
        type,
        confidence,
        previewCount,
        estimatedProperties,
        timestamp: new Date().toISOString(),
      });
      return;
    }

    // Query approved
    setQueryError(null);
    onRunQuery();
  };

  return (
    <div className="w-[264px] flex-shrink-0 bg-white border-r border-[#E2E4E8] flex flex-col overflow-y-auto">
      <div className="p-4 border-b border-[#E2E4E8]">
        <div className="text-[10px] font-semibold tracking-wider text-[#9CA3AF] uppercase mb-2">
          Geographic area
        </div>
        <select
          value={area}
          onChange={(e) => handleAreaChange(e.target.value)}
          className="w-full px-2.5 py-1.5 border border-[#E2E4E8] rounded-lg text-[13px] bg-[#F4F5F7] text-[#1A1A2E] outline-none transition-colors focus:border-[#4A7CB8]"
        >
          {/* S1-01: Geographic area selection - expanded neighborhood list */}
          <optgroup label="Gràcia District">
            <option>Gràcia — full district</option>
            <option>Gràcia — Vila de Gràcia</option>
            <option>Gràcia — Camp d'en Grassot</option>
            <option>Gràcia — La Salut</option>
            <option>Gràcia — El Coll</option>
            <option>Gràcia — Vallcarca i els Penitents</option>
          </optgroup>
          <optgroup label="Eixample District">
            <option>Eixample — left (Esquerra)</option>
            <option>Eixample — right (Dreta)</option>
            <option>Eixample — full district</option>
          </optgroup>
          <optgroup label="Other Districts">
            <option>Sarrià-Sant Gervasi</option>
            <option>Ciutat Vella</option>
            <option>Sants-Montjuïc</option>
            <option>Les Corts</option>
          </optgroup>
        </select>
      </div>

      <div className="p-4 border-b border-[#E2E4E8]">
        <div className="text-[10px] font-semibold tracking-wider text-[#9CA3AF] uppercase mb-2">
          Misuse type
        </div>
        <select
          value={type}
          onChange={(e) => handleTypeChange(e.target.value)}
          className="w-full px-2.5 py-1.5 border border-[#E2E4E8] rounded-lg text-[13px] bg-[#F4F5F7] text-[#1A1A2E] outline-none transition-colors focus:border-[#4A7CB8]"
        >
          <option value="all">All types</option>
          <option value="vacancy">Structural vacancy</option>
          <option value="tourist">Illegal tourist use</option>
          <option value="speculative">Speculative withholding</option>
          <option value="office">Illegal office conversion</option>
        </select>
      </div>

      <div className="p-4 border-b border-[#E2E4E8]">
        <div className="text-[10px] font-semibold tracking-wider text-[#9CA3AF] uppercase mb-2">
          Minimum confidence
        </div>
        <div className="grid grid-cols-2 gap-1.5">
          {['Watch', 'Medium+', 'High only', 'All'].map((label) => (
            <button
              key={label}
              onClick={() => handleConfidenceChange(label.toLowerCase())}
              className={`px-1 py-1.5 rounded-lg border text-[12px] text-center transition-all ${
                confidence === label.toLowerCase()
                  ? 'border-[#1C3557] bg-[#EBF2FA] text-[#1C3557] font-semibold'
                  : 'border-[#E2E4E8] bg-[#F4F5F7] text-[#6B7280] hover:border-[#4A7CB8] hover:text-[#1A1A2E]'
              }`}
            >
              {label}
            </button>
          ))}
        </div>
      </div>

      <div className="p-4 border-b border-[#E2E4E8]">
        <div className="text-[10px] font-semibold tracking-wider text-[#9CA3AF] uppercase mb-2">
          Query preview
        </div>
        <div className="flex items-baseline gap-1.5 text-[13px] text-[#6B7280]">
          <span className="text-[20px] font-semibold text-[#1A1A2E]">{previewCount}</span>
          <span>clusters match</span>
        </div>
        <div className="text-[11px] text-[#9CA3AF] mt-0.5">minimum 500 properties each</div>
      </div>

      {/* S1-05: Query error display */}
      {queryError && (
        <div className="mx-4 mt-3 p-2.5 bg-[#FDEEEC] border border-[#f0b4b0] rounded-lg text-[11px] text-[#C0392B] leading-relaxed">
          <strong>Query rejected:</strong> {queryError}
        </div>
      )}

      <button
        onClick={handleRunQuery}
        disabled={previewCount === 0}
        className="mx-4 mt-3.5 mb-0.5 px-2 py-2 rounded-lg bg-[#1C3557] text-white text-[13px] font-semibold hover:bg-[#2E5496] transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
      >
        Run query →
      </button>

      <div className="m-4 mt-3 p-2.5 bg-[#EAF4EC] border border-[#b0d8bc] rounded-lg text-[11px] text-[#1D6832] flex gap-2 items-start leading-relaxed">
        <svg className="w-4 h-4 flex-shrink-0 mt-0.5" viewBox="0 0 16 16" fill="none">
          <path d="M8 1L14 4v5c0 3.3-2.7 5.7-6 6.5C4.7 14.7 2 12.3 2 9V4L8 1z" fill="#1D6832"/>
          <path d="M5.5 8l2 2 3-3" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
        </svg>
        <span>
          Results shown only for groups of 500+ properties. No individual data is accessible from this interface.
        </span>
      </div>
    </div>
  );
}
