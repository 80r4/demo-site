interface TopBarProps {
  currentPage: 'inspector' | 'audit' | 'system';
  onPageChange: (page: 'inspector' | 'audit' | 'system') => void;
}

export function TopBar({ currentPage, onPageChange }: TopBarProps) {
  return (
    <div className="h-12 flex items-center px-5 gap-2 sticky top-0 z-50" style={{ background: 'var(--navy)' }}>
      <div className="font-semibold text-[15px] text-white flex items-center gap-2">
        <div className="w-[22px] h-[22px] rounded-full border-2 flex items-center justify-center" style={{ borderColor: 'var(--gold)' }}>
          <div className="w-2 h-2 rounded-full" style={{ background: 'var(--gold)' }}></div>
        </div>
        TrueOccupancy
      </div>

      <div className="flex gap-0.5 ml-7">
        <button
          onClick={() => onPageChange('inspector')}
          className={`px-3.5 py-1 rounded-lg text-[13px] transition-all ${
            currentPage === 'inspector'
              ? 'bg-white/15 text-white font-medium'
              : 'bg-transparent text-white/65 hover:bg-white/10 hover:text-white'
          }`}
        >
          Inspector
        </button>
        <button
          onClick={() => onPageChange('audit')}
          className={`px-3.5 py-1 rounded-lg text-[13px] transition-all ${
            currentPage === 'audit'
              ? 'bg-white/15 text-white font-medium'
              : 'bg-transparent text-white/65 hover:bg-white/10 hover:text-white'
          }`}
        >
          Audit log
        </button>
        <button
          onClick={() => onPageChange('system')}
          className={`px-3.5 py-1 rounded-lg text-[13px] transition-all ${
            currentPage === 'system'
              ? 'bg-white/15 text-white font-medium'
              : 'bg-transparent text-white/65 hover:bg-white/10 hover:text-white'
          }`}
        >
          System
        </button>
      </div>

      <div className="flex items-center gap-2.5 ml-auto">
        <div className="flex gap-3 px-3 py-1 rounded-lg bg-white/[0.08] text-[11px] text-white/60">
          <div className="flex items-center gap-1.5">
            <div className="w-1.5 h-1.5 rounded-full bg-green-400"></div>
            Utility: 8 Apr
          </div>
          <div className="flex items-center gap-1.5">
            <div className="w-1.5 h-1.5 rounded-full bg-green-400"></div>
            Listings: 25 Apr
          </div>
          <div className="flex items-center gap-1.5">
            <div className="w-1.5 h-1.5 rounded-full bg-red-400"></div>
            Cadastre: 12 Mar
          </div>
        </div>

        <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-white/[0.12] text-[12px] text-white/85">
          <div className="w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold" style={{ background: 'var(--gold)', color: 'var(--navy)' }}>
            EM
          </div>
          E. Martínez
          <span className="text-[10px] px-1.5 py-0.5 rounded-full font-semibold" style={{ background: 'rgba(244, 200, 66, 0.25)', color: 'var(--gold)' }}>
            Inspector
          </span>
        </div>
      </div>
    </div>
  );
}
