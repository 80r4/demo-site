import { Job } from '../types';

interface SystemPageProps {
  jobs: Job[];
}

const Badge = ({ type, children }: { type: string; children: React.ReactNode }) => {
  const classes = {
    ok: 'bg-[#EAF4EC] text-[#1D6832]',
    warn: 'bg-[#FEF9E7] text-[#8B6000]',
    run: 'bg-[#EBF2FA] text-[#2E5496]',
  }[type];

  return (
    <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-semibold ${classes}`}>
      {children}
    </span>
  );
};

export function SystemPage({ jobs }: SystemPageProps) {
  return (
    <div className="flex flex-col gap-4">
      <div className="grid grid-cols-4 gap-3">
        <div className="bg-white border border-[#E2E4E8] rounded-xl p-3.5">
          <div className="text-[11px] text-[#9CA3AF] mb-1">Last full run</div>
          <div className="text-[18px] font-semibold leading-none">2026-04-08</div>
          <div className="text-[11px] text-[#9CA3AF] mt-1">Jobs 1–6 completed</div>
        </div>
        <div className="bg-white border border-[#E2E4E8] rounded-xl p-3.5">
          <div className="text-[11px] text-[#9CA3AF] mb-1">Properties in DB</div>
          <div className="text-[26px] font-semibold leading-none">48,320</div>
          <div className="text-[11px] text-[#9CA3AF] mt-1">Gràcia + Eixample</div>
        </div>
        <div className="bg-white border border-[#E2E4E8] rounded-xl p-3.5">
          <div className="text-[11px] text-[#9CA3AF] mb-1">Clusters generated</div>
          <div className="text-[26px] font-semibold leading-none">31</div>
          <div className="text-[11px] text-[#9CA3AF] mt-1">above 500-property threshold</div>
        </div>
        <div className="bg-white border border-[#E2E4E8] rounded-xl p-3.5">
          <div className="text-[11px] text-[#9CA3AF] mb-1">Clusters suppressed</div>
          <div className="text-[26px] font-semibold leading-none text-[#8B6000]">9</div>
          <div className="text-[11px] text-[#9CA3AF] mt-1">below minimum threshold</div>
        </div>
      </div>

      <div className="bg-white border border-[#E2E4E8] rounded-xl overflow-hidden">
        <div className="px-4 py-3 border-b border-[#E2E4E8]">
          <span className="text-[13px] font-semibold">Scheduled job status</span>
        </div>
        <div>
          {jobs.map((job, index) => (
            <div
              key={index}
              className="flex items-center gap-3 px-4 py-3 border-b border-[#E2E4E8] last:border-b-0"
            >
              <div
                className={`w-[34px] h-[34px] rounded-lg flex items-center justify-center text-base flex-shrink-0 ${
                  job.status === 'warn' ? 'bg-[#FEF9E7]' : 'bg-[#EAF4EC]'
                }`}
              >
                {job.icon}
              </div>
              <div className="flex-1">
                <div className="text-[13px] font-semibold">{job.name}</div>
                <div className="text-[11px] text-[#9CA3AF] mt-0.5">Frequency: {job.freq}</div>
              </div>
              <div className="text-right">
                <Badge type={job.status}>{job.statusLabel}</Badge>
                <div className="text-[11px] text-[#9CA3AF] mt-0.5">Last run: {job.last}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="bg-white border border-[#E2E4E8] rounded-xl overflow-hidden">
          <div className="px-4 py-3 border-b border-[#E2E4E8]">
            <span className="text-[13px] font-semibold">Classification model</span>
          </div>
          <div className="p-3.5 flex flex-col gap-2.5">
            <div className="flex justify-between text-[13px] py-1.5 border-b border-[#E2E4E8]">
              <span className="text-[#6B7280]">Model version</span>
              <span>v2.1.4</span>
            </div>
            <div className="flex justify-between text-[13px] py-1.5 border-b border-[#E2E4E8]">
              <span className="text-[#6B7280]">Structural vacancy — precision</span>
              <span>0.81</span>
            </div>
            <div className="flex justify-between text-[13px] py-1.5 border-b border-[#E2E4E8]">
              <span className="text-[#6B7280]">Illegal tourist use — precision</span>
              <span>0.77</span>
            </div>
            <div className="flex justify-between text-[13px] py-1.5 border-b border-[#E2E4E8]">
              <span className="text-[#6B7280]">Speculative withholding — precision</span>
              <span>0.62</span>
            </div>
            <div className="flex justify-between text-[13px] py-1.5">
              <span className="text-[#6B7280]">Min. signals required for classification</span>
              <span>2 sources</span>
            </div>
          </div>
        </div>

        <div className="bg-white border border-[#E2E4E8] rounded-xl overflow-hidden">
          <div className="px-4 py-3 border-b border-[#E2E4E8]">
            <span className="text-[13px] font-semibold">Privacy enforcement checks</span>
          </div>
          <div className="p-3.5 flex flex-col gap-2">
            <div className="flex justify-between items-center text-[13px] py-1.5 border-b border-[#E2E4E8]">
              <span className="text-[#6B7280]">500-property minimum enforced</span>
              <Badge type="ok">✓ Active</Badge>
            </div>
            <div className="flex justify-between items-center text-[13px] py-1.5 border-b border-[#E2E4E8]">
              <span className="text-[#6B7280]">Personal identifiers in schema</span>
              <Badge type="ok">✓ None found</Badge>
            </div>
            <div className="flex justify-between items-center text-[13px] py-1.5 border-b border-[#E2E4E8]">
              <span className="text-[#6B7280]">Inferences table access — inspector role</span>
              <Badge type="ok">✓ Blocked</Badge>
            </div>
            <div className="flex justify-between items-center text-[13px] py-1.5 border-b border-[#E2E4E8]">
              <span className="text-[#6B7280]">Audit log — all queries logged</span>
              <Badge type="ok">✓ Active</Badge>
            </div>
            <div className="flex justify-between items-center text-[13px] py-1.5">
              <span className="text-[#6B7280]">Cadastre last updated</span>
              <span className="bg-[#FEF9E7] text-[#8B6000] px-2 py-0.5 rounded-full text-[11px] font-semibold">
                ⚠ 45 days ago
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
