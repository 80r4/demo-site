import { Cluster } from '../types';

interface ClusterListProps {
  clusters: Cluster[];
  selectedIndex: number | null;
  onSelectCluster: (index: number) => void;
}

const Badge = ({ type, children }: { type: string; children: React.ReactNode }) => {
  const classes = {
    high: 'bg-[#FDEEEC] text-[#C0392B]',
    medium: 'bg-[#FEF9E7] text-[#8B6000]',
    watch: 'bg-[#EBF2FA] text-[#2E5496]',
    referred: 'bg-[#EBF2FA] text-[#1C3557]',
    dismissed: 'bg-[#FEF9E7] text-[#8B6000]',
    pending: 'bg-[#EBF2FA] text-[#2E5496]',
  }[type];

  return (
    <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-semibold whitespace-nowrap ${classes}`}>
      {children}
    </span>
  );
};

export function ClusterList({ clusters, selectedIndex, onSelectCluster }: ClusterListProps) {
  const getScoreColor = (conf: string) => {
    switch (conf) {
      case 'high':
        return 'bg-[#C0392B]';
      case 'medium':
        return 'bg-[#8B6000]';
      case 'watch':
        return 'bg-[#2E5496]';
      default:
        return 'bg-gray-400';
    }
  };

  return (
    <div className="max-h-[280px] overflow-y-auto">
      {clusters.map((cluster, index) => (
        <button
          key={cluster.id}
          onClick={() => onSelectCluster(index)}
          className={`w-full px-5 py-4 border-b border-[#E2E4E8] last:border-b-0 cursor-pointer flex items-start justify-between gap-3 transition-all text-left ${
            selectedIndex === index
              ? 'bg-[#EBF2FA] border-l-4 border-l-[#2E5496]'
              : 'hover:bg-[#F9FAFB] border-l-4 border-l-transparent'
          }`}
        >
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1.5">
              <span className="text-[14px] font-semibold text-[#1A1A2E]">{cluster.id}</span>
              <span className="text-[13px] text-[#6B7280]">·</span>
              <span className="text-[13px] text-[#6B7280] truncate">{cluster.type}</span>
            </div>
            <div className="text-[12px] text-[#9CA3AF] mb-2">
              {cluster.area} · <strong className="text-[#6B7280]">{cluster.props.toLocaleString()}</strong> properties
            </div>
            <div className="flex items-center gap-2">
              <div className="w-24 h-1.5 bg-[#E2E4E8] rounded-full overflow-hidden">
                <div
                  className={`h-full rounded-full ${getScoreColor(cluster.conf)}`}
                  style={{ width: `${Math.round(cluster.score * 100)}%` }}
                ></div>
              </div>
              <span className="text-[11px] font-medium text-[#6B7280]">{Math.round(cluster.score * 100)}%</span>
            </div>
          </div>
          <div className="flex flex-col items-end gap-1.5 flex-shrink-0">
            <Badge type={cluster.conf}>{cluster.conf}</Badge>
            {cluster.decision && <Badge type={cluster.decision}>{cluster.decision}</Badge>}
          </div>
        </button>
      ))}
    </div>
  );
}
