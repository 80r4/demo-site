interface DataSource {
  name: string;
  lastUpdate: string; // Date string like "8 Apr" or "12 Mar"
  daysAgo: number;
}

interface DataFreshnessWarningProps {
  sources: DataSource[];
}

export function DataFreshnessWarning({ sources }: DataFreshnessWarningProps) {
  const staleSources = sources.filter(s => s.daysAgo > 35);

  if (staleSources.length === 0) return null;

  return (
    <div className="bg-[#FEF9E7] border border-[#f0c894] rounded-lg p-3 flex gap-3 items-start">
      <span className="text-xl flex-shrink-0">⚠️</span>
      <div className="flex-1 text-[13px] text-[#8B6000] leading-relaxed">
        <strong>Data freshness warning:</strong>{' '}
        {staleSources.map(s => s.name).join(', ')} {staleSources.length === 1 ? 'has' : 'have'} not been updated in over 35 days.
        Classifications may be based on outdated information. Contact system administrator to review data pipeline status.
        <div className="mt-2 text-[11px]">
          {staleSources.map(s => (
            <div key={s.name}>• {s.name}: Last updated {s.lastUpdate} ({s.daysAgo} days ago)</div>
          ))}
        </div>
      </div>
    </div>
  );
}
