import { useEffect, useRef, useCallback } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { Cluster } from '../types';
import { clusterGeoJSON, GRACIA_CENTER, INITIAL_ZOOM } from '../cluster-geojson';

interface LeafletClusterMapProps {
  clusters: Cluster[];
  selectedIndex: number | null;
  onSelectCluster: (index: number) => void;
  fitBoundsKey?: number;
  /* Hover sync */
  hoveredIndex?: number | null;
  onHoverCluster?: (i: number | null) => void;
  /* Draw mode */
  drawMode?: boolean;
  inProgressPoints?: [number, number][];
  drawnPolygon?: [number, number][] | null;
  onAddPoint?: (lat: number, lng: number) => void;
  onClosePolygon?: () => void;
}

const CONF_COLOR: Record<string, string> = {
  high: '#C0392B',
  medium: '#8B6000',
  watch: '#2E5496',
};

/* Snap distance in pixels to close polygon by clicking near first point */
const SNAP_PX = 20;

export function LeafletClusterMap({
  clusters,
  selectedIndex,
  onSelectCluster,
  fitBoundsKey,
  hoveredIndex = null,
  onHoverCluster,
  drawMode = false,
  inProgressPoints = [],
  drawnPolygon = null,
  onAddPoint,
  onClosePolygon,
}: LeafletClusterMapProps) {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<L.Map | null>(null);
  const polygonsRef = useRef<Map<string, L.Polygon>>(new Map());

  /* Draw layer refs */
  const drawGroupRef = useRef<L.FeatureGroup | null>(null);
  const hoverLineRef = useRef<L.Polyline | null>(null);

  /* Keep callbacks stable in event handlers without stale closures */
  const onAddPointRef = useRef(onAddPoint);
  const onClosePolygonRef = useRef(onClosePolygon);
  const onHoverClusterRef = useRef(onHoverCluster);
  const inProgressRef = useRef(inProgressPoints);
  const drawModeRef = useRef(drawMode);

  onAddPointRef.current = onAddPoint;
  onClosePolygonRef.current = onClosePolygon;
  onHoverClusterRef.current = onHoverCluster;
  inProgressRef.current = inProgressPoints;
  drawModeRef.current = drawMode;

  /* ── Initialize map once ── */
  useEffect(() => {
    if (!mapContainerRef.current || mapRef.current) return;

    const map = L.map(mapContainerRef.current, {
      center: GRACIA_CENTER,
      zoom: INITIAL_ZOOM,
      zoomControl: true,
      attributionControl: true,
    });

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
      maxZoom: 19,
      minZoom: 11,
    }).addTo(map);

    const drawGroup = L.featureGroup().addTo(map);
    drawGroupRef.current = drawGroup;

    mapRef.current = map;

    return () => {
      if (mapRef.current) {
        mapRef.current.remove();
        mapRef.current = null;
        drawGroupRef.current = null;
        hoverLineRef.current = null;
      }
    };
  }, []);

  /* ── Map click handler — draw mode ── */
  const handleMapClick = useCallback((e: L.LeafletMouseEvent) => {
    if (!drawModeRef.current || !mapRef.current) return;
    const pts = inProgressRef.current;
    if (pts.length >= 3) {
      /* Check proximity to first point */
      const firstLatLng = L.latLng(pts[0][0], pts[0][1]);
      const firstPx = mapRef.current.latLngToContainerPoint(firstLatLng);
      const clickPx = mapRef.current.latLngToContainerPoint(e.latlng);
      const dist = firstPx.distanceTo(clickPx);
      if (dist <= SNAP_PX) {
        onClosePolygonRef.current?.();
        return;
      }
    }
    onAddPointRef.current?.(e.latlng.lat, e.latlng.lng);
  }, []);

  /* ── Map dblclick handler — close polygon ── */
  const handleMapDblClick = useCallback((e: L.LeafletMouseEvent) => {
    if (!drawModeRef.current) return;
    L.DomEvent.stopPropagation(e);
    if (inProgressRef.current.length >= 3) {
      onClosePolygonRef.current?.();
    }
  }, []);

  /* ── Mousemove — hover line from last point to cursor ── */
  const handleMouseMove = useCallback((e: L.LeafletMouseEvent) => {
    if (!drawModeRef.current || !mapRef.current) return;
    const pts = inProgressRef.current;
    if (pts.length === 0 || !drawGroupRef.current) return;

    const last = pts[pts.length - 1];
    const lineCoords: [number, number][] = [[last[0], last[1]], [e.latlng.lat, e.latlng.lng]];

    if (!hoverLineRef.current) {
      hoverLineRef.current = L.polyline(lineCoords, {
        color: '#5096CC',
        weight: 1.5,
        opacity: 0.7,
        dashArray: '4 4',
        interactive: false,
      }).addTo(drawGroupRef.current);
    } else {
      hoverLineRef.current.setLatLngs(lineCoords);
    }
  }, []);

  /* ── Wire/unwire map events based on drawMode ── */
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;

    if (drawMode) {
      map.doubleClickZoom.disable();
      map.getContainer().style.cursor = 'crosshair';
      map.on('click', handleMapClick);
      map.on('dblclick', handleMapDblClick);
      map.on('mousemove', handleMouseMove);
    } else {
      map.doubleClickZoom.enable();
      map.getContainer().style.cursor = '';
      map.off('click', handleMapClick);
      map.off('dblclick', handleMapDblClick);
      map.off('mousemove', handleMouseMove);
      /* Remove hover line */
      if (hoverLineRef.current) {
        hoverLineRef.current.remove();
        hoverLineRef.current = null;
      }
    }
  }, [drawMode, handleMapClick, handleMapDblClick, handleMouseMove]);

  /* ── Render draw layer (in-progress + finalized polygon) ── */
  useEffect(() => {
    const group = drawGroupRef.current;
    if (!group) return;

    /* Remove everything except the hover line */
    group.eachLayer(layer => {
      if (layer !== hoverLineRef.current) group.removeLayer(layer);
    });

    if (drawnPolygon && drawnPolygon.length >= 3) {
      /* Finalized polygon — filled */
      L.polygon(drawnPolygon, {
        color: '#5096CC',
        fillColor: '#5096CC',
        fillOpacity: 0.12,
        weight: 2,
        opacity: 0.8,
        dashArray: undefined,
        interactive: false,
      }).addTo(group);

      /* Vertex markers */
      drawnPolygon.forEach((pt, i) => {
        L.circleMarker([pt[0], pt[1]], {
          radius: 5,
          color: '#5096CC',
          fillColor: '#fff',
          fillOpacity: 1,
          weight: 2,
          interactive: false,
        }).addTo(group);
        if (i === 0) {
          /* Slightly larger for first point */
          L.circleMarker([pt[0], pt[1]], {
            radius: 7,
            color: '#5096CC',
            fillColor: '#5096CC',
            fillOpacity: 0.3,
            weight: 1.5,
            interactive: false,
          }).addTo(group);
        }
      });
    } else if (inProgressPoints.length > 0) {
      /* Dashed polyline connecting placed points */
      if (inProgressPoints.length >= 2) {
        L.polyline(inProgressPoints, {
          color: '#5096CC',
          weight: 2,
          opacity: 0.9,
          dashArray: '6 4',
          interactive: false,
        }).addTo(group);
      }

      /* Vertex markers */
      inProgressPoints.forEach((pt, i) => {
        const r = i === 0 ? 7 : 5;
        L.circleMarker([pt[0], pt[1]], {
          radius: r,
          color: '#5096CC',
          fillColor: i === 0 ? '#5096CC' : '#fff',
          fillOpacity: i === 0 ? 0.4 : 1,
          weight: 2,
          interactive: false,
        }).addTo(group);
      });

      /* Closing dashed line from last → first (if ≥3 pts) */
      if (inProgressPoints.length >= 3) {
        const last = inProgressPoints[inProgressPoints.length - 1];
        const first = inProgressPoints[0];
        L.polyline([last, first], {
          color: '#5096CC',
          weight: 1.5,
          opacity: 0.35,
          dashArray: '3 5',
          interactive: false,
        }).addTo(group);
      }
    }
  }, [inProgressPoints, drawnPolygon]);

  /* ── Update cluster polygons when clusters or selection changes ── */
  useEffect(() => {
    if (!mapRef.current) return;

    polygonsRef.current.forEach(p => p.remove());
    polygonsRef.current.clear();

    clusters.forEach((cluster, index) => {
      const geoData = clusterGeoJSON.find(g => g.id === cluster.id);
      if (!geoData || !mapRef.current) return;

      const latLngs = geoData.polygon[0].map(([lng, lat]) => [lat, lng] as [number, number]);
      const color = CONF_COLOR[cluster.conf] ?? '#999999';
      const isSelected = selectedIndex === index;

      const polygon = L.polygon(latLngs, {
        color,
        fillColor: color,
        fillOpacity: isSelected ? 0.45 : 0.22,
        weight: isSelected ? 3 : 1.5,
        opacity: isSelected ? 1 : 0.75,
      }).addTo(mapRef.current);

      polygon.bindPopup(
        `<div style="font-family:-apple-system,sans-serif;font-size:13px;min-width:210px;padding:4px">
          <div style="font-weight:600;font-size:14px;color:#1A1A2E;border-bottom:1px solid #E2E4E8;padding-bottom:6px;margin-bottom:8px">
            ${cluster.id} — ${cluster.area}
          </div>
          <div style="margin-bottom:4px"><strong>Type:</strong> ${cluster.type}</div>
          <div style="margin-bottom:4px"><strong>Properties:</strong> ${cluster.props.toLocaleString()}</div>
          <div style="margin-bottom:8px"><strong>Score:</strong> ${Math.round(cluster.score * 100)}%</div>
          ${cluster.decision ? `<div style="color:${color};font-weight:600;font-size:11px">Status: ${cluster.decision}</div>` : '<div style="font-size:11px;color:#6B7280">Click polygon to view details</div>'}
        </div>`,
        { maxWidth: 260, closeButton: true },
      );

      /* In draw mode polygon clicks add points — don't intercept for cluster selection */
      if (!drawMode) {
        polygon.on('click', () => onSelectCluster(index));
        polygon.on('mouseover', function (this: L.Polygon) {
          onHoverClusterRef.current?.(index);
          if (selectedIndex !== index) this.setStyle({ fillOpacity: 0.38, weight: 2.5, opacity: 0.95 });
          this.bringToFront();
        });
        polygon.on('mouseout', function (this: L.Polygon) {
          onHoverClusterRef.current?.(null);
          if (selectedIndex !== index) this.setStyle({ fillOpacity: 0.22, weight: 1.5, opacity: 0.75 });
        });
      }

      polygonsRef.current.set(cluster.id, polygon);
    });

    if (selectedIndex !== null && clusters[selectedIndex]) {
      polygonsRef.current.get(clusters[selectedIndex].id)?.bringToFront();
    }
  }, [clusters, selectedIndex, onSelectCluster, drawMode]);

  /* ── List → map hover: apply highlight when hoveredIndex changes ── */
  useEffect(() => {
    polygonsRef.current.forEach((polygon, clusterId) => {
      const idx = clusters.findIndex(c => c.id === clusterId);
      if (idx === -1) return;
      const isSelected = selectedIndex === idx;
      const isHovered  = hoveredIndex === idx;
      if (!isSelected) {
        polygon.setStyle({
          fillOpacity: isHovered ? 0.38 : 0.22,
          weight:      isHovered ? 2.5  : 1.5,
          opacity:     isHovered ? 0.95 : 0.75,
        });
        if (isHovered) polygon.bringToFront();
      }
    });
  }, [hoveredIndex, selectedIndex, clusters]);

  /* ── Fit bounds when fitBoundsKey changes (triggered by "Run query") ── */
  useEffect(() => {
    if (!mapRef.current || fitBoundsKey === undefined || polygonsRef.current.size === 0) return;
    const allLatLngs: L.LatLng[] = [];
    polygonsRef.current.forEach(p => {
      (p.getLatLngs() as L.LatLng[][]).flat().forEach(ll => allLatLngs.push(ll));
    });
    if (allLatLngs.length > 0) {
      mapRef.current.fitBounds(L.latLngBounds(allLatLngs), { padding: [32, 32], maxZoom: 16 });
    }
  }, [fitBoundsKey]);

  return (
    <div className="relative h-64 w-full">
      <div ref={mapContainerRef} className="absolute inset-0 z-0"></div>

      {/* Draw mode banner */}
      {drawMode && (
        <div className="absolute top-2 left-1/2 -translate-x-1/2 z-[1000] pointer-events-none" style={{ whiteSpace: 'nowrap' }}>
          <div style={{ background: 'rgba(80,150,204,0.92)', color: '#fff', fontFamily: "'Inter',sans-serif", fontSize: 11, fontWeight: 600, padding: '5px 12px', borderRadius: 2, letterSpacing: '0.03em' }}>
            {drawnPolygon
              ? 'Polygon closed — run query or undo'
              : inProgressPoints.length === 0
                ? 'Click to place first point'
                : inProgressPoints.length < 3
                  ? `${inProgressPoints.length} point${inProgressPoints.length > 1 ? 's' : ''} — need ${3 - inProgressPoints.length} more to close`
                  : 'Double-click or click first point to close · click to add more points'}
          </div>
        </div>
      )}

      {/* Colour legend */}
      <div style={{ position:'absolute', bottom:12, right:12, background:'rgba(255,255,255,0.97)', border:'1px solid rgba(0,0,0,0.10)', borderRadius:3, padding:'8px 10px', zIndex:1000, pointerEvents:'none', boxShadow:'0 1px 6px rgba(0,0,0,0.10)', display:'flex', flexDirection:'column', gap:5 }}>
        <div style={{ fontFamily:"'JetBrains Mono',monospace", fontSize:9, fontWeight:600, letterSpacing:'0.08em', color:'#9CA3AF', textTransform:'uppercase', marginBottom:2 }}>Confidence</div>
        {[
          { color: '#C0392B', label: 'High' },
          { color: '#8B6000', label: 'Medium' },
          { color: '#2E5496', label: 'Watch' },
        ].map(({ color, label }) => (
          <div key={label} style={{ display:'flex', alignItems:'center', gap:7, fontFamily:"'Inter',sans-serif", fontSize:11, color:'#4B5563' }}>
            <div style={{ width:13, height:13, borderRadius:2, border:`2px solid ${color}`, background:`${color}40`, flexShrink:0 }} />
            {label}
          </div>
        ))}
      </div>

      {/* District label */}
      <div className="absolute top-2 left-2 bg-white/90 px-2.5 py-1 rounded text-[10px] text-[#6B7280] shadow z-[1000] pointer-events-none font-medium">
        📍 Barcelona — {clusters.length} cluster{clusters.length !== 1 ? 's' : ''}
      </div>
    </div>
  );
}
