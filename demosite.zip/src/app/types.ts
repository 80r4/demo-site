export interface Cluster {
  id: string;
  conf: 'high' | 'medium' | 'watch';
  type: string;
  props: number;
  score: number;
  area: string;
  district: string; // area key for filter matching
  lat: number;
  lon: number;
  signals: {
    water: number;
    listings: number;
    cadastre: number;
    residents: number;
  };
  summary: string;
  decision: 'referred' | 'dismissed' | 'pending' | null;
  audit: AuditEntry[];
}

export interface AuditEntry {
  user: string;
  ts: string;
  action: string;
}

export interface LogEntry {
  id: string;
  ts: string;
  user: string;
  cluster: string;
  qtype: string;
  conf: string;
  action: string;
  status: 'query' | 'referred' | 'pending' | 'dismissed' | 'alert';
  /** IDs of clusters returned by this query (only on status='query' entries) */
  clusterIds?: string[];
}

export interface Job {
  icon: string;
  name: string;
  freq: string;
  last: string;
  status: 'ok' | 'warn' | 'run';
  statusLabel: string;
}

export interface ActiveQuery {
  area: string;
  misuseType: string;
  minConf: string;
}
