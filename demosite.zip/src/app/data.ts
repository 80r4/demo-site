import { Cluster, LogEntry, Job } from './types';

export const allClustersData: Cluster[] = [
  // ─── Gràcia district ───
  {
    id: 'C-001', conf: 'high', type: 'Structural vacancy', props: 912, score: 0.81,
    area: 'Vila de Gràcia N', district: 'gracia-vila', lat: 41.4042, lon: 2.1559,
    signals: { water: 88, listings: 12, cadastre: 71, residents: 94 },
    summary: '88% of properties have water below 5 L/day (90-day rolling avg). 94% have no registered residents. Near-zero electricity baseline on 79% of properties.',
    decision: null,
    audit: [
      { user: 'J.Puig', ts: '2026-04-22 09:14', action: 'Queried — all types, medium+' },
      { user: 'E.Martínez', ts: '2026-04-25 14:32', action: 'Queried — vacancy, high only' },
    ],
  },
  {
    id: 'C-002', conf: 'high', type: 'Illegal tourist use', props: 743, score: 0.77,
    area: "Camp d'en Grassot W", district: 'gracia-grassot', lat: 41.4081, lon: 2.1682,
    signals: { water: 62, listings: 81, cadastre: 90, residents: 55 },
    summary: '81% have active multi-platform listings (Airbnb + Booking.com). Average booking days: 74/year. 90% have residential zoning with no tourist licence.',
    decision: 'referred',
    audit: [
      { user: 'J.Puig', ts: '2026-04-20 11:00', action: 'Referred for physical inspection' },
    ],
  },
  {
    id: 'C-003', conf: 'medium', type: 'Speculative withholding', props: 621, score: 0.62,
    area: 'Gràcia Centre', district: 'gracia-vila', lat: 41.4016, lon: 2.1608,
    signals: { water: 44, listings: 31, cadastre: 58, residents: 38 },
    summary: 'Irregular consumption pattern. 8 properties flagged under the same company entity. Listings priced 4.2 SD above neighbourhood median — never booked.',
    decision: null,
    audit: [
      { user: 'E.Martínez', ts: '2026-04-24 16:55', action: 'Queried — speculative, medium+' },
    ],
  },
  {
    id: 'C-004', conf: 'high', type: 'Structural vacancy', props: 887, score: 0.79,
    area: 'La Salut', district: 'gracia-salut', lat: 41.4148, lon: 2.1541,
    signals: { water: 91, listings: 8, cadastre: 83, residents: 97 },
    summary: '91% below 5 L/day threshold. 97% have no registered residents. Near-zero electricity on 89% of properties for 6+ consecutive months.',
    decision: null,
    audit: [],
  },
  {
    id: 'C-005', conf: 'medium', type: 'Illegal tourist use', props: 534, score: 0.69,
    area: 'El Coll border', district: 'gracia-coll', lat: 41.4193, lon: 2.1487,
    signals: { water: 51, listings: 67, cadastre: 74, residents: 42 },
    summary: '67% have active listings. Average booking days 58/year. Single-platform presence only — confidence is medium, not high.',
    decision: null,
    audit: [
      { user: 'R.Solà', ts: '2026-04-23 10:18', action: 'Queried — tourist, medium+' },
    ],
  },
  {
    id: 'C-006', conf: 'watch', type: 'Speculative withholding', props: 502, score: 0.41,
    area: 'Vallcarca S', district: 'gracia-vallcarca', lat: 41.4218, lon: 2.1435,
    signals: { water: 29, listings: 18, cadastre: 34, residents: 22 },
    summary: 'One signal only — irregular consumption pattern. Insufficient evidence for medium confidence. Monitoring recommended.',
    decision: 'pending',
    audit: [
      { user: 'E.Martínez', ts: '2026-04-21 13:44', action: 'Set to pending — monitoring' },
    ],
  },
  {
    id: 'C-007', conf: 'medium', type: 'Illegal office conversion', props: 678, score: 0.71,
    area: 'Gràcia S', district: 'gracia-grassot', lat: 41.3978, lon: 2.1627,
    signals: { water: 73, listings: 5, cadastre: 81, residents: 68 },
    summary: '24/7 flat electricity baseline on 61% of properties. Water at commercial levels (~200 L/day). No rental listings. Residential zoning — commercial use mismatch.',
    decision: null,
    audit: [],
  },

  // ─── Eixample district ───
  {
    id: 'C-008', conf: 'high', type: 'Illegal tourist use', props: 1102, score: 0.79,
    area: 'Eixample Esquerra N', district: 'eixample-esquerra', lat: 41.3920, lon: 2.1520,
    signals: { water: 65, listings: 84, cadastre: 91, residents: 58 },
    summary: '84% have active multi-platform listings. 91% have residential zoning without tourist licence. Average booking density 4.7× the district median.',
    decision: null,
    audit: [
      { user: 'R.Solà', ts: '2026-04-28 10:22', action: 'Referred for physical inspection' },
    ],
  },
  {
    id: 'C-009', conf: 'medium', type: 'Structural vacancy', props: 876, score: 0.64,
    area: 'Eixample Dreta NW', district: 'eixample-dreta', lat: 41.3920, lon: 2.1710,
    signals: { water: 82, listings: 11, cadastre: 74, residents: 88 },
    summary: '82% water below 5 L/day threshold. 88% no registered residents. Near-zero electricity on 71% for 4+ consecutive months.',
    decision: null,
    audit: [],
  },
  {
    id: 'C-010', conf: 'medium', type: 'Speculative withholding', props: 945, score: 0.58,
    area: 'Eixample Esquerra S', district: 'eixample-esquerra', lat: 41.3840, lon: 2.1480,
    signals: { water: 38, listings: 28, cadastre: 52, residents: 31 },
    summary: 'Single-entity portfolio owns 13 properties in block. Listings priced 3.8 SD above median — zero bookings for 8 months. Two signals only; medium confidence.',
    decision: null,
    audit: [],
  },
  {
    id: 'C-011', conf: 'medium', type: 'Illegal tourist use', props: 723, score: 0.67,
    area: 'Eixample Dreta SW', district: 'eixample-dreta', lat: 41.3860, lon: 2.1720,
    signals: { water: 71, listings: 79, cadastre: 87, residents: 64 },
    summary: '79% active listing presence on 2+ platforms. 87% residential zoning mismatch. Average booking days 68/year across this cluster.',
    decision: null,
    audit: [],
  },
  {
    id: 'C-012', conf: 'watch', type: 'Structural vacancy', props: 518, score: 0.38,
    area: 'Fort Pienc', district: 'fort-pienc', lat: 41.3910, lon: 2.1840,
    signals: { water: 24, listings: 15, cadastre: 41, residents: 29 },
    summary: 'Water below 5 L/day on 24% — marginal signal. One corroborating source so far. Monitoring for additional evidence before elevating confidence.',
    decision: null,
    audit: [],
  },

  // ─── Sants-Montjuïc district ───
  {
    id: 'C-013', conf: 'medium', type: 'Structural vacancy', props: 667, score: 0.66,
    area: 'Sants Centre', district: 'sants', lat: 41.3740, lon: 2.1400,
    signals: { water: 78, listings: 9, cadastre: 69, residents: 81 },
    summary: '78% below 5 L/day threshold. 81% no registered residents. Electricity near-zero on 73% for 5+ consecutive months.',
    decision: null,
    audit: [],
  },
  {
    id: 'C-014', conf: 'high', type: 'Illegal tourist use', props: 891, score: 0.75,
    area: 'Hostafrancs', district: 'sants', lat: 41.3722, lon: 2.1468,
    signals: { water: 61, listings: 76, cadastre: 88, residents: 53 },
    summary: '76% active listings. Average booking days 61/year. 88% have residential zoning without HUTB tourist licence. Strongly corroborated by cadastral mismatch.',
    decision: null,
    audit: [],
  },
  {
    id: 'C-015', conf: 'medium', type: 'Speculative withholding', props: 754, score: 0.60,
    area: 'La Bordeta', district: 'sants', lat: 41.3688, lon: 2.1355,
    signals: { water: 42, listings: 33, cadastre: 55, residents: 37 },
    summary: 'Irregular consumption on 42% of properties. Portfolio entity owns 17 units. Listings present but overpriced with no completed bookings in 6 months.',
    decision: null,
    audit: [],
  },

  // ─── Ciutat Vella district ───
  {
    id: 'C-016', conf: 'high', type: 'Illegal tourist use', props: 1198, score: 0.84,
    area: 'Barri Gòtic N', district: 'ciutatvella', lat: 41.3837, lon: 2.1766,
    signals: { water: 72, listings: 91, cadastre: 95, residents: 68 },
    summary: '91% active multi-platform listings. 95% residential zoning without tourist licence. Highest listing density in the pilot — 4-district analysis.',
    decision: null,
    audit: [
      { user: 'J.Puig', ts: '2026-04-27 14:15', action: 'Queried — tourist, high only' },
    ],
  },
  {
    id: 'C-017', conf: 'high', type: 'Structural vacancy', props: 843, score: 0.80,
    area: 'El Raval S', district: 'ciutatvella', lat: 41.3783, lon: 2.1680,
    signals: { water: 86, listings: 7, cadastre: 77, residents: 93 },
    summary: '86% below 5 L/day. 93% no registered residents. Near-zero electricity on 81% for 7+ consecutive months.',
    decision: null,
    audit: [],
  },
  {
    id: 'C-018', conf: 'high', type: 'Illegal tourist use', props: 712, score: 0.82,
    area: 'La Barceloneta', district: 'ciutatvella', lat: 41.3796, lon: 2.1895,
    signals: { water: 68, listings: 88, cadastre: 92, residents: 61 },
    summary: '88% active listings on 3+ platforms. Average booking days 81/year. Entire block shows commercial consumption pattern with residential zoning.',
    decision: null,
    audit: [],
  },
  {
    id: 'C-019', conf: 'watch', type: 'Speculative withholding', props: 602, score: 0.43,
    area: 'Sant Pere', district: 'ciutatvella', lat: 41.3869, lon: 2.1815,
    signals: { water: 31, listings: 22, cadastre: 47, residents: 26 },
    summary: 'One confirmed signal — irregular consumption pattern. Listing presence partial. Insufficient evidence for medium confidence. Watching.',
    decision: null,
    audit: [],
  },

  // ─── Sub-500 groups (never shown — only trigger blocking logic) ───
  {
    id: 'C-X01', conf: 'medium', type: 'Illegal tourist use', props: 312, score: 0.61,
    area: 'Sarrià', district: 'sarria', lat: 41.4040, lon: 2.1190,
    signals: { water: 58, listings: 73, cadastre: 84, residents: 51 },
    summary: 'Below 500-property threshold — suppressed.',
    decision: null,
    audit: [],
  },
  {
    id: 'C-X02', conf: 'medium', type: 'Structural vacancy', props: 467, score: 0.58,
    area: 'Sant Gervasi', district: 'sarria', lat: 41.4098, lon: 2.1268,
    signals: { water: 79, listings: 8, cadastre: 66, residents: 84 },
    summary: 'Below 500-property threshold — suppressed.',
    decision: null,
    audit: [],
  },
  {
    id: 'C-X03', conf: 'watch', type: 'Speculative withholding', props: 244, score: 0.39,
    area: 'Les Corts centre', district: 'lescorts', lat: 41.3842, lon: 2.1310,
    signals: { water: 33, listings: 19, cadastre: 44, residents: 28 },
    summary: 'Below 500-property threshold — suppressed.',
    decision: null,
    audit: [],
  },
];

export const logEntries: LogEntry[] = [
  { id: 'AL-284', ts: '2026-04-28 10:22', user: 'c9a1…', cluster: 'C-008', qtype: 'Tourist', conf: 'high', action: 'Referred for inspection', status: 'referred' },
  { id: 'AL-283', ts: '2026-04-27 14:15', user: 'b8c2…', cluster: 'C-016', qtype: 'Tourist', conf: 'high', action: 'Queried', status: 'query' },
  { id: 'AL-282', ts: '2026-04-26 11:42', user: 'a3f7…', cluster: 'C-003', qtype: 'Speculative', conf: 'medium+', action: 'Queried', status: 'query' },
  { id: 'AL-281', ts: '2026-04-26 09:17', user: 'a3f7…', cluster: 'C-001', qtype: 'All types', conf: 'high', action: 'Queried', status: 'query' },
  { id: 'AL-280', ts: '2026-04-25 16:30', user: 'b8c2…', cluster: 'C-005', qtype: 'Tourist', conf: 'medium+', action: 'Queried', status: 'query' },
  { id: 'AL-279', ts: '2026-04-25 14:32', user: 'a3f7…', cluster: 'C-001', qtype: 'Vacancy', conf: 'high', action: 'Queried', status: 'query' },
  { id: 'AL-278', ts: '2026-04-25 11:05', user: 'e1d4…', cluster: 'C-002', qtype: 'Tourist', conf: 'high', action: 'Referred for inspection', status: 'referred' },
  { id: 'AL-277', ts: '2026-04-24 16:55', user: 'a3f7…', cluster: 'C-003', qtype: 'Speculative', conf: 'medium+', action: 'Queried', status: 'query' },
  { id: 'AL-276', ts: '2026-04-24 03:17', user: 'f2a9…', cluster: '—', qtype: 'All types', conf: '<500 props', action: 'BLOCKED — below threshold', status: 'alert' },
  { id: 'AL-275', ts: '2026-04-23 10:18', user: 'c9a1…', cluster: 'C-005', qtype: 'Tourist', conf: 'medium+', action: 'Queried', status: 'query' },
  { id: 'AL-274', ts: '2026-04-22 09:14', user: 'b8c2…', cluster: 'C-001', qtype: 'All types', conf: 'medium+', action: 'Queried', status: 'query' },
  { id: 'AL-273', ts: '2026-04-21 13:44', user: 'a3f7…', cluster: 'C-006', qtype: 'Speculative', conf: 'watch', action: 'Set to pending', status: 'pending' },
  { id: 'AL-272', ts: '2026-04-20 11:00', user: 'e1d4…', cluster: 'C-002', qtype: 'Tourist', conf: 'high', action: 'Referred for inspection', status: 'referred' },
  { id: 'AL-271', ts: '2026-04-19 15:22', user: 'b8c2…', cluster: 'C-007', qtype: 'Office', conf: 'medium+', action: 'Queried', status: 'query' },
];

export const jobs: Job[] = [
  { icon: '🗂', name: 'Job 1 — Cadastral update', freq: 'Monthly', last: '2026-03-12', status: 'warn', statusLabel: 'Overdue — 45 days' },
  { icon: '⚡', name: 'Job 2 — Utility ingestion', freq: 'Monthly (+7 days)', last: '2026-04-08', status: 'ok', statusLabel: 'Complete' },
  { icon: '🌐', name: 'Job 3 — Web listing scrape', freq: 'Weekly', last: '2026-04-25', status: 'ok', statusLabel: 'Complete' },
  { icon: '🧠', name: 'Job 4 — Classification run', freq: 'Monthly (after Jobs 1–3)', last: '2026-04-08', status: 'ok', statusLabel: 'Complete — v2.1.4' },
  { icon: '🔒', name: 'Job 5 — Cluster generation', freq: 'Monthly (after Job 4)', last: '2026-04-08', status: 'ok', statusLabel: '31 clusters — 9 suppressed' },
  { icon: '🗑', name: 'Job 6 — Retention purge', freq: 'Quarterly', last: '2026-01-01', status: 'ok', statusLabel: 'Next: 2026-07-01' },
];
