export interface ClusterGeoJSON {
  id: string;
  polygon: number[][][];
  centroid: [number, number]; // [lng, lat]
}

// Bounding box helper: [lng_min, lat_min] to [lng_max, lat_max]
const box = (lngMin: number, latMin: number, lngMax: number, latMax: number): number[][][] => [[
  [lngMin, latMax], [lngMax, latMax], [lngMax, latMin], [lngMin, latMin], [lngMin, latMax],
]];

export const clusterGeoJSON: ClusterGeoJSON[] = [
  // ─── Gràcia ───
  { id: 'C-001', centroid: [2.1559, 41.4042], polygon: box(2.1534, 41.4025, 2.1584, 41.4059) },
  { id: 'C-002', centroid: [2.1682, 41.4081], polygon: box(2.1655, 41.4063, 2.1709, 41.4099) },
  { id: 'C-003', centroid: [2.1608, 41.4016], polygon: box(2.1582, 41.3999, 2.1634, 41.4033) },
  { id: 'C-004', centroid: [2.1541, 41.4148], polygon: box(2.1514, 41.4131, 2.1568, 41.4165) },
  { id: 'C-005', centroid: [2.1487, 41.4193], polygon: box(2.1460, 41.4176, 2.1514, 41.4210) },
  { id: 'C-006', centroid: [2.1435, 41.4218], polygon: box(2.1408, 41.4201, 2.1462, 41.4235) },
  { id: 'C-007', centroid: [2.1627, 41.3978], polygon: box(2.1600, 41.3961, 2.1654, 41.3995) },

  // ─── Eixample ───
  { id: 'C-008', centroid: [2.1520, 41.3920], polygon: box(2.1492, 41.3902, 2.1548, 41.3938) },
  { id: 'C-009', centroid: [2.1710, 41.3920], polygon: box(2.1682, 41.3902, 2.1738, 41.3938) },
  { id: 'C-010', centroid: [2.1480, 41.3840], polygon: box(2.1452, 41.3822, 2.1508, 41.3858) },
  { id: 'C-011', centroid: [2.1720, 41.3860], polygon: box(2.1692, 41.3842, 2.1748, 41.3878) },
  { id: 'C-012', centroid: [2.1840, 41.3910], polygon: box(2.1812, 41.3892, 2.1868, 41.3928) },

  // ─── Sants-Montjuïc ───
  { id: 'C-013', centroid: [2.1400, 41.3740], polygon: box(2.1372, 41.3722, 2.1428, 41.3758) },
  { id: 'C-014', centroid: [2.1468, 41.3722], polygon: box(2.1440, 41.3704, 2.1496, 41.3740) },
  { id: 'C-015', centroid: [2.1355, 41.3688], polygon: box(2.1327, 41.3670, 2.1383, 41.3706) },

  // ─── Ciutat Vella ───
  { id: 'C-016', centroid: [2.1766, 41.3837], polygon: box(2.1738, 41.3819, 2.1794, 41.3855) },
  { id: 'C-017', centroid: [2.1680, 41.3783], polygon: box(2.1652, 41.3765, 2.1708, 41.3801) },
  { id: 'C-018', centroid: [2.1895, 41.3796], polygon: box(2.1867, 41.3778, 2.1923, 41.3814) },
  { id: 'C-019', centroid: [2.1815, 41.3869], polygon: box(2.1787, 41.3851, 2.1843, 41.3887) },

  // ─── Sub-500 groups (only for blocking logic — never rendered on map) ───
  { id: 'C-X01', centroid: [2.1190, 41.4040], polygon: box(2.1162, 41.4022, 2.1218, 41.4058) },
  { id: 'C-X02', centroid: [2.1268, 41.4098], polygon: box(2.1240, 41.4080, 2.1296, 41.4116) },
  { id: 'C-X03', centroid: [2.1310, 41.3842], polygon: box(2.1282, 41.3824, 2.1338, 41.3860) },
];

// Multi-district center — shows Gràcia + Eixample + Sants + Ciutat Vella
export const GRACIA_CENTER: [number, number] = [41.390, 2.162];
export const INITIAL_ZOOM = 13;
