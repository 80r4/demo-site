import { createContext, useContext, useState, useRef, ReactNode } from 'react';
import { Cluster, LogEntry, ActiveQuery } from '../types';
import { allClustersData, logEntries as seedLog } from '../data';

/* ─── Filter helpers ─────────────────────────────────────────────────────── */

export const matchesArea = (cluster: Cluster, area: string): boolean => {
  if (area === 'all') return true;
  if (area === 'gracia') return cluster.district.startsWith('gracia');
  if (area === 'eixample') return cluster.district.startsWith('eixample') || cluster.district === 'fort-pienc';
  if (area === 'eixample-dreta') return cluster.district === 'eixample-dreta' || cluster.district === 'fort-pienc';
  return cluster.district === area;
};

export const matchesMisuseType = (cluster: Cluster, type: string): boolean => {
  if (type === 'all') return true;
  const map: Record<string, string> = {
    vacancy: 'Structural vacancy',
    tourist: 'Illegal tourist use',
    speculative: 'Speculative withholding',
    office: 'Illegal office conversion',
  };
  return cluster.type === (map[type] ?? type);
};

export const matchesConf = (cluster: Cluster, conf: string): boolean => {
  if (conf === 'all' || conf === 'watch') return true;
  if (conf === 'medium+') return cluster.conf === 'high' || cluster.conf === 'medium';
  if (conf === 'high only') return cluster.conf === 'high';
  return true;
};

/* Ray-casting point-in-polygon. point = [lat, lng], polygon = [[lat, lng], ...] */
export function pointInPolygon(point: [number, number], polygon: [number, number][]): boolean {
  const [py, px] = point;
  let inside = false;
  for (let i = 0, j = polygon.length - 1; i < polygon.length; j = i++) {
    const [yi, xi] = polygon[i];
    const [yj, xj] = polygon[j];
    if ((yi > py) !== (yj > py) && px < ((xj - xi) * (py - yi)) / (yj - yi) + xi) {
      inside = !inside;
    }
  }
  return inside;
}

export const applyFilters = (
  clusters: Cluster[],
  q: ActiveQuery,
  polygon?: [number, number][] | null,
): Cluster[] => {
  const byType = clusters.filter(
    c => matchesMisuseType(c, q.misuseType) && matchesConf(c, q.minConf),
  );
  if (polygon && polygon.length >= 3) {
    return byType.filter(c => pointInPolygon([c.lat, c.lon], polygon));
  }
  return byType.filter(c => matchesArea(c, q.area));
};

export const AREA_LABELS: Record<string, string> = {
  all: 'All districts',
  gracia: 'Gràcia — full district',
  'gracia-vila': 'Gràcia — Vila de Gràcia',
  'gracia-grassot': "Gràcia — Camp d'en Grassot",
  'gracia-salut': 'Gràcia — La Salut',
  'gracia-coll': 'Gràcia — El Coll',
  'gracia-vallcarca': 'Gràcia — Vallcarca',
  eixample: 'Eixample — full district',
  'eixample-esquerra': 'Eixample — Esquerra',
  'eixample-dreta': 'Eixample — Dreta + Fort Pienc',
  sants: 'Sants-Montjuïc',
  ciutatvella: 'Ciutat Vella',
  sarria: 'Sarrià-Sant Gervasi',
  lescorts: 'Les Corts',
};

export const TYPE_LABELS: Record<string, string> = {
  all: 'All types',
  vacancy: 'Structural vacancy',
  tourist: 'Illegal tourist use',
  speculative: 'Speculative withholding',
  office: 'Illegal office conversion',
};

export const CONF_LABELS: Record<string, string> = {
  all: 'All confidence',
  watch: 'Watch +',
  'medium+': 'Medium +',
  'high only': 'High only',
};

export const DEFAULT_QUERY: ActiveQuery = { area: 'all', misuseType: 'all', minConf: 'all' };

/* ─── Context shape ──────────────────────────────────────────────────────── */

interface QueryResult {
  blocked: boolean;
  reason?: string;
}

export interface SessionInfo {
  role: 'inspector' | 'administrator';
  userId: string; // hashed
}

interface AppStateCtx {
  allClusters: Cluster[];
  activeClusters: Cluster[];
  pendingQuery: ActiveQuery;
  activeQuery: ActiveQuery | null;
  hasRunQuery: boolean;
  queryResult: QueryResult | null;
  auditLog: LogEntry[];
  /* Draw mode */
  useDrawMode: boolean;
  drawnPolygon: [number, number][] | null;
  inProgressPoints: [number, number][];
  /* Session */
  session: SessionInfo | null;
  setPendingQuery: (q: ActiveQuery) => void;
  runQuery: () => void;
  resetFilter: (field: keyof ActiveQuery) => void;
  updateCluster: (id: string, update: Partial<Cluster>) => void;
  addAuditEntry: (entry: LogEntry) => void;
  setUseDrawMode: (v: boolean) => void;
  addDrawPoint: (lat: number, lng: number) => void;
  undoPoint: () => void;
  clearDraw: () => void;
  closePolygon: () => void;
  setSession: (s: SessionInfo | null) => void;
}

const AppStateContext = createContext<AppStateCtx | null>(null);

export function useAppState(): AppStateCtx {
  const ctx = useContext(AppStateContext);
  if (!ctx) throw new Error('useAppState must be used inside AppStateProvider');
  return ctx;
}

/* ─── Provider ───────────────────────────────────────────────────────────── */

export function AppStateProvider({ children }: { children: ReactNode }) {
  const [allClusters, setAllClusters] = useState<Cluster[]>(allClustersData);
  const [activeClusters, setActiveClusters] = useState<Cluster[]>(
    allClustersData.filter(c => c.props >= 500),
  );
  const [pendingQuery, setPendingQuery] = useState<ActiveQuery>(DEFAULT_QUERY);
  const [activeQuery, setActiveQuery] = useState<ActiveQuery | null>(null);
  const [hasRunQuery, setHasRunQuery] = useState(false);
  const [queryResult, setQueryResult] = useState<QueryResult | null>(null);
  const [auditLog, setAuditLog] = useState<LogEntry[]>(seedLog);
  const logCounterRef = useRef(285);

  /* Draw mode state */
  const [useDrawMode, setUseDrawModeState] = useState(false);
  const [drawnPolygon, setDrawnPolygon] = useState<[number, number][] | null>(null);
  const [inProgressPoints, setInProgressPoints] = useState<[number, number][]>([]);

  /* Session */
  const [session, setSession] = useState<SessionInfo | null>(null);
  const sessionRef = useRef<SessionInfo | null>(null);
  sessionRef.current = session;

  const nextLogId = () => {
    const id = `AL-${logCounterRef.current}`;
    logCounterRef.current += 1;
    return id;
  };

  const nowTs = () =>
    new Date().toLocaleString('es-ES', {
      year: 'numeric', month: '2-digit', day: '2-digit',
      hour: '2-digit', minute: '2-digit', hour12: false,
    }).replace(',', '');

  const MOCK_USER = sessionRef.current?.userId ?? 'a3f7…';

  const executeQuery = (q: ActiveQuery, polygon?: [number, number][] | null) => {
    const raw = applyFilters(allClusters, q, polygon);
    const subThreshold = raw.filter(c => c.props < 500);
    const valid = raw.filter(c => c.props >= 500);
    const ts = nowTs();

    if (raw.length === 0) {
      const entry: LogEntry = {
        id: nextLogId(), ts, user: MOCK_USER,
        cluster: '—',
        qtype: TYPE_LABELS[q.misuseType] ?? q.misuseType,
        conf: CONF_LABELS[q.minConf] ?? q.minConf,
        action: polygon ? 'BLOCKED — no clusters inside drawn area' : 'BLOCKED — no clusters match',
        status: 'alert',
      };
      setAuditLog(prev => [entry, ...prev]);
      setQueryResult({ blocked: true, reason: polygon ? 'No clusters fall within the drawn area.' : 'No clusters match the selected filters.' });
      return;
    }

    if (subThreshold.length > 0) {
      const entry: LogEntry = {
        id: nextLogId(), ts, user: MOCK_USER,
        cluster: '—',
        qtype: TYPE_LABELS[q.misuseType] ?? q.misuseType,
        conf: CONF_LABELS[q.minConf] ?? q.minConf,
        action: `BLOCKED — ${subThreshold.length} group(s) below 500-property minimum`,
        status: 'alert',
      };
      setAuditLog(prev => [entry, ...prev]);
      setQueryResult({
        blocked: true,
        reason: `${subThreshold.length} group(s) in this area have fewer than 500 properties. Query blocked to preserve k-anonymity.`,
      });
      return;
    }

    const totalProps = valid.reduce((s, c) => s + c.props, 0);
    const areaDesc = polygon ? 'drawn area' : (AREA_LABELS[q.area] ?? q.area);
    const entry: LogEntry = {
      id: nextLogId(), ts, user: MOCK_USER,
      cluster: `${valid.length} clusters`,
      qtype: TYPE_LABELS[q.misuseType] ?? q.misuseType,
      conf: CONF_LABELS[q.minConf] ?? q.minConf,
      action: `Queried — ${valid.length} clusters in ${areaDesc} (${totalProps.toLocaleString()} properties)`,
      status: 'query',
      clusterIds: valid.map(c => c.id),
    };
    setAuditLog(prev => [entry, ...prev]);
    setActiveClusters(valid);
    setActiveQuery(q);
    setHasRunQuery(true);
    setQueryResult({ blocked: false });
  };

  const runQuery = () => executeQuery(pendingQuery, useDrawMode ? drawnPolygon : null);

  const resetFilter = (field: keyof ActiveQuery) => {
    const updated: ActiveQuery = { ...(activeQuery ?? DEFAULT_QUERY), [field]: DEFAULT_QUERY[field] };
    setPendingQuery(updated);
    executeQuery(updated, useDrawMode ? drawnPolygon : null);
  };

  const updateCluster = (id: string, update: Partial<Cluster>) => {
    const updater = (list: Cluster[]) =>
      list.map(c => (c.id === id ? { ...c, ...update } : c));
    setAllClusters(updater);
    setActiveClusters(updater);
  };

  const addAuditEntry = (entry: LogEntry) => setAuditLog(prev => [entry, ...prev]);

  /* Draw mode actions */
  const setUseDrawMode = (v: boolean) => {
    setUseDrawModeState(v);
    if (!v) {
      setDrawnPolygon(null);
      setInProgressPoints([]);
    }
  };

  const addDrawPoint = (lat: number, lng: number) => {
    setInProgressPoints(prev => [...prev, [lat, lng]]);
  };

  const undoPoint = () => {
    if (drawnPolygon) {
      setDrawnPolygon(null);
      setInProgressPoints(drawnPolygon.slice(0, -1) as [number, number][]);
    } else {
      setInProgressPoints(prev => prev.slice(0, -1));
    }
  };

  const clearDraw = () => {
    setDrawnPolygon(null);
    setInProgressPoints([]);
    setQueryResult(null);
  };

  const closePolygon = () => {
    if (inProgressPoints.length < 3) return;
    setDrawnPolygon([...inProgressPoints]);
    setInProgressPoints([]);
  };

  return (
    <AppStateContext.Provider
      value={{
        allClusters, activeClusters, pendingQuery, activeQuery,
        hasRunQuery, queryResult, auditLog,
        useDrawMode, drawnPolygon, inProgressPoints,
        session,
        setPendingQuery, runQuery, resetFilter, updateCluster, addAuditEntry,
        setUseDrawMode, addDrawPoint, undoPoint, clearDraw, closePolygon,
        setSession,
      }}
    >
      {children}
    </AppStateContext.Provider>
  );
}
